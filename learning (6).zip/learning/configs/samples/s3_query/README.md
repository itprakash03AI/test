# Phase 134-P — s3_query sample configs

Copy-paste these into your per-task JSON config and fill in the
`REPLACE_ME` values.  The polling row's `sql_query_path` column
points at the JSON; the step class reads it via
`S3BaseStep._load_and_validate_config`.

| Step class | Sample file | What it does |
|---|---|---|
| `S3IcebergQueryExtract`   | `s3_iceberg_query_extract.example.json`   | Iceberg → NFS file (CSV/Parquet/JSON) |
| `S3ParquetQueryExtract`   | `s3_parquet_query_extract.example.json`   | S3 parquet → NFS file |
| `S3IcebergQueryToOracle`  | `s3_iceberg_query_to_oracle.example.json` | Iceberg → Oracle (JDBC) |
| `S3ParquetQueryToOracle`  | `s3_parquet_query_to_oracle.example.json` | S3 parquet → Oracle (JDBC) |

## Placeholders honoured everywhere

These get substituted at run time by `S3BaseStep._parameterize_query`
in `query`, `s3_prefix`, and `output_path`:

| Placeholder | Source |
|---|---|
| `{BUSINESSDATE}` | `task['business_date']` (from the polling row) |
| `{SYSTEM_ENTITY}` | `task['system_entity']` |
| `{EventCode}` | `task['eventcode']` |

## File-sink delivery chain

`*_extract.example.json` produces a single file at `output_path`.  Three
task-dict aliases are set so the existing delivery steps chain naturally:

| Set by Extract step | Read by |
|---|---|
| `task['output_file']` | s3_query Extract step's own output |
| `task['consolidated_file']` | `CompressFiles` + `CreateCTLFile` |
| `task['downloaded_files']` | `ConsolidateFiles` (5-step legacy pipeline) |

Recommended chain (skips redundant `ConsolidateFiles` — the Spark output
is already a single file):

```
S3{Iceberg|Parquet}QueryExtract → CompressFiles → CreateCTLFile → DeliverFiles
```

5-step legacy chain (still works — the consolidate is a single-file
pass-through):

```
S3{Iceberg|Parquet}QueryExtract → ConsolidateFiles → CompressFiles → CreateCTLFile → DeliverFiles
```

## Triggering

| Trigger | Path |
|---|---|
| **Airflow** | `s3_query_entity_runner` DAG → `SparkSubmitOperator` → `s3_query_standalone.py` |
| **Polling service** | `OTG_DAG_ID` containing `s3_query` → `_infer_dag_type` → `WORKER_REGISTRY['s3_query']` → `S3QueryWorker` |

Both paths poll `Vw_otg_dag_task` for SEQ-ordered rows and dispatch
each row's `TASK_TYPE` to the matching step class via
`step_mapping.yaml`'s `s3_query:` section.

## Time-travel (iceberg only)

Both iceberg step variants expose two optional config keys:

| Key | Type | Effect |
|---|---|---|
| `snapshot_id` | int | Read this exact snapshot (skip current) |
| `as_of_timestamp_ms` | int | Read the latest snapshot ≤ this Unix ms timestamp |

Mutually exclusive — set at most one.  Both null/omitted = current
snapshot (default).  Threaded through `spark.read.format("iceberg")
.option("snapshot-id", X)` / `.option("as-of-timestamp", X)`.

## Supplement-based file pruning (iceberg only, opt-in)

QueryStudio populates an `iceberg_column_stats_supplement_v2` table
keyed on `(bucket, table_prefix, snapshot_id, file_path,
column_name)` with file-level min/max bounds for columns the iceberg
writer didn't track in manifest stats.  Enable this in your config
to bypass Spark+Iceberg's reader and use the supplement-augmented
file list directly:

```json
"use_supplement_pruning":             true,
"querystudio_db_connection_string":   "user/pw@//qs-db.internal:1521/QSDB"
```

### Supported

* Identity-transform partitions (the default — `PARTITIONED BY
  (region, business_date)`)
* All snapshot types EXCEPT those with delete files (see refusals)
* Simple WHERE predicates: `=`, `!=`, `<`, `<=`, `>`, `>=`,
  `BETWEEN`, `IN (literals)`
* Multi-column `AND`
* Time-travel (`snapshot_id` / `as_of_timestamp_ms`)

### Automatic refusals — fall back to standard Spark+Iceberg path

The pruned path refuses (without raising) when:

| Refusal reason | Why | What happens |
|---|---|---|
| Non-Identity partition transform (`bucket`, `truncate`, `year`, `month`, `day`, `hour`) | Pruned `read.parquet([files])` can't apply transforms — correctness gap | Standard Spark+Iceberg reader runs |
| Snapshot has delete files (equality or position) | `read.parquet()` doesn't apply deletes — would return tombstoned rows | Standard Spark+Iceberg reader runs |
| WHERE has only non-extractable predicates (OR, function call, subquery) | Pruning would be a no-op | Standard Spark+Iceberg reader runs |
| `use_supplement_pruning: false` or no `querystudio_db_connection_string` | Opt-out / misconfig | Standard Spark+Iceberg reader runs |
| `pyiceberg` / `sqlglot` / `oracledb` not importable | Missing deps | Standard Spark+Iceberg reader runs (warning logged) |

Every refusal logs the reason at INFO so operators can debug why
supplement pruning isn't kicking in.

### Not yet supported (subsequent sessions)

* Position-delete-aware reads (would need row-level exclusion)
* Non-Identity transforms (would need `Transform.project()` mirror)
* Postgres / SQLite as the supplement DB (currently Oracle-only via
  `oracledb`)

