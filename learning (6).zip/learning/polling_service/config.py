"""
Configuration loader for the ETL Background Polling Service.

Resolution order (highest wins):
  1. Environment variables (BG_POLL_INTERVAL, BG_MAX_CONCURRENT, etc.)
  2. polling_service_config.yaml
  3. Hard-coded defaults
"""
import logging
import os
from dataclasses import dataclass
from typing import Optional

import yaml


@dataclass
class PollingServiceConfig:
    # Polling behaviour
    interval_seconds: int = 30
    max_concurrent_runs: int = 5
    thread_pool_workers: int = 16
    worker_id: str = "bg_poller_1"

    # BF-595 (2026-05-30) — lightweight (no-Spark) mode.
    # When True, dispatcher routes createJob runs to step_mapping.yaml
    # `createJob_light` section which uses direct trino-python-client +
    # oracledb instead of PySpark.  Default True for the polling
    # service pod (workloads < 500K rows).  Set False to use the
    # legacy Spark path (requires Spark image + JARs + PVC mount).
    use_lightweight_steps: bool = True

    # BF-595 — per-run hard timeout (SERIOUS #4).  A run wedged longer
    # than this is cancelled and STATUS flipped to FAILED so the slot
    # frees up.  Default 2 hours.  Set 0 to disable.
    max_run_seconds: int = 7200

    # BF-595 — graceful-shutdown wait cap (SERIOUS #6).  On SIGTERM the
    # poller waits up to this many seconds for in-flight runs to drain
    # then cancels stragglers.  Default 60s, matches the K8s
    # terminationGracePeriodSeconds typical value.
    shutdown_timeout_seconds: int = 60

    # BF-595 — polling query LIMIT (SERIOUS #5).  Caps the number of
    # rows the bg_polling_query returns per cycle so a 1000-START-row
    # spike doesn't slow every poll to a crawl.  Computed at runtime
    # from max_concurrent_runs × this multiplier so the polling query
    # always returns enough rows to keep the slot pipeline full.
    polling_query_limit_multiplier: int = 20

    # Oracle connection strings
    etl_connection_string: str = ""
    dest_connection_string: str = ""

    # File paths (resolved at load time)
    queries_path: str = "config/etl_polling_task_query.yaml"
    step_mapping_path: str = "config/step_mapping.yaml"

    # Logging — defaults to the shared ``log_config.get_log_dir()``
    # resolution (ETL_LOG_DIR env > polling YAML > legacy PVC path).
    # Use ``dataclasses.field(default_factory=...)`` so the call
    # happens at instance-construction time, not at class-definition
    # time (avoids freezing the cache before env vars are set).
    log_dir: str = ""
    log_level: str = "INFO"

    # Loaded SQL (not from YAML directly — loaded by config loader)
    bg_polling_sql: str = ""


def load_config(config_path: Optional[str] = None) -> PollingServiceConfig:
    """Load config from YAML file + environment variable overrides.

    Args:
        config_path: Path to polling_service_config.yaml.
                     Falls back to CONFIG_PATH env var, then
                     <ETL_DIR>/config/polling_service_config.yaml.
    """
    cfg = PollingServiceConfig()

    # Resolve config file path
    if not config_path:
        config_path = os.environ.get(
            "CONFIG_PATH",
            os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "config",
                "polling_service_config.yaml",
            ),
        )

    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            raw = yaml.safe_load(f) or {}

        polling = raw.get("polling", {})
        oracle = raw.get("oracle", {})
        logging_cfg = raw.get("logging", {})

        cfg.interval_seconds = int(polling.get("interval_seconds", cfg.interval_seconds))
        cfg.max_concurrent_runs = int(polling.get("max_concurrent_runs", cfg.max_concurrent_runs))
        cfg.thread_pool_workers = int(polling.get("thread_pool_workers", cfg.thread_pool_workers))
        cfg.worker_id = str(polling.get("worker_id", cfg.worker_id))
        # BF-595
        cfg.use_lightweight_steps = bool(
            polling.get("use_lightweight_steps", cfg.use_lightweight_steps)
        )
        cfg.max_run_seconds = int(polling.get("max_run_seconds", cfg.max_run_seconds))
        cfg.shutdown_timeout_seconds = int(
            polling.get("shutdown_timeout_seconds", cfg.shutdown_timeout_seconds)
        )
        cfg.polling_query_limit_multiplier = int(
            polling.get(
                "polling_query_limit_multiplier",
                cfg.polling_query_limit_multiplier,
            )
        )

        cfg.etl_connection_string = str(oracle.get("etl_connection_string", cfg.etl_connection_string))
        cfg.dest_connection_string = str(oracle.get("dest_connection_string", cfg.dest_connection_string))
        cfg.queries_path = str(oracle.get("queries_path", cfg.queries_path))
        cfg.step_mapping_path = str(oracle.get("step_mapping_path", cfg.step_mapping_path))

        cfg.log_dir = str(logging_cfg.get("dir", cfg.log_dir))
        cfg.log_level = str(logging_cfg.get("level", cfg.log_level)).upper()
    else:
        logging.warning(f"Config file not found: {config_path} — using defaults + env vars")

    # Environment variable overrides (highest priority)
    cfg.interval_seconds = int(os.environ.get("BG_POLL_INTERVAL", cfg.interval_seconds))
    cfg.max_concurrent_runs = int(os.environ.get("BG_MAX_CONCURRENT", cfg.max_concurrent_runs))
    cfg.thread_pool_workers = int(os.environ.get("BG_THREAD_WORKERS", cfg.thread_pool_workers))
    cfg.worker_id = os.environ.get("BG_WORKER_ID", cfg.worker_id)
    cfg.etl_connection_string = os.environ.get("ETL_ORACLE_CONN", cfg.etl_connection_string)
    cfg.dest_connection_string = os.environ.get("DEST_ORACLE_CONN", cfg.dest_connection_string)
    # BF-595 env overrides
    if "BG_USE_LIGHTWEIGHT" in os.environ:
        cfg.use_lightweight_steps = os.environ["BG_USE_LIGHTWEIGHT"].lower() in ("1", "true", "yes", "on")
    cfg.max_run_seconds = int(os.environ.get("BG_MAX_RUN_SECONDS", cfg.max_run_seconds))
    cfg.shutdown_timeout_seconds = int(os.environ.get("BG_SHUTDOWN_TIMEOUT", cfg.shutdown_timeout_seconds))
    cfg.polling_query_limit_multiplier = int(
        os.environ.get("BG_POLL_LIMIT_MULT", cfg.polling_query_limit_multiplier)
    )

    # Resolve log_dir last via the shared resolver so ETL_LOG_DIR env
    # var wins over polling YAML, and polling YAML wins over the
    # legacy hardcoded PVC path.  Only call the shared resolver when
    # the YAML+env didn't already provide a value (preserves explicit
    # operator intent).
    if not cfg.log_dir:
        try:
            etl_root_for_logs = os.path.dirname(
                os.path.dirname(os.path.abspath(__file__))
            )
            if etl_root_for_logs not in os.sys.path:
                os.sys.path.insert(0, etl_root_for_logs)
            from log_config import get_log_dir as _shared_log_dir
            cfg.log_dir = _shared_log_dir()
        except Exception:
            cfg.log_dir = "/usr/local/spark/nfs/bcp/batch/logs"

    # Resolve paths relative to ETL root if not absolute
    etl_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if not os.path.isabs(cfg.queries_path):
        cfg.queries_path = os.path.join(etl_root, cfg.queries_path)
    if not os.path.isabs(cfg.step_mapping_path):
        cfg.step_mapping_path = os.path.join(etl_root, cfg.step_mapping_path)

    # Load the background polling SQL from queries YAML
    cfg.bg_polling_sql = _load_bg_polling_sql(cfg.queries_path)

    return cfg


def _load_bg_polling_sql(queries_path: str) -> str:
    """Load bg_polling_query from the queries YAML file."""
    if not os.path.exists(queries_path):
        raise FileNotFoundError(f"Queries file not found: {queries_path}")
    with open(queries_path, "r") as f:
        queries = yaml.safe_load(f) or {}
    if "bg_polling_query" not in queries:
        raise ValueError(
            f"'bg_polling_query' not found in {queries_path}. "
            "Add the query to etl_polling_task_query.yaml."
        )
    return str(queries["bg_polling_query"]).strip()
