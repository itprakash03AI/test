"""
FastAPI health/status/control API for the ETL Background Polling Service.

Endpoints (port 9000):
  GET  /health         → 200 {"status": "ok", "active_runs": N, "paused": bool}
  GET  /health/ready   → 200 if Oracle reachable, else 503
  GET  /status         → stats dict (polls, dispatched, completed, failed, active_runs, paused)
  POST /pause          → pause polling (in-flight runs complete normally)
  POST /resume         → resume polling
"""
import asyncio
import logging
from typing import TYPE_CHECKING

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

if TYPE_CHECKING:
    from polling_service.poller import BackgroundPoller
    from managers.oracle_metadata_manager import OracleMetadataManager

# Child of "bg_poller" — propagates to the root logger configured in main.py
# so health endpoint logs reach the same console + file as the rest of the service.
# getLogger(__name__) = "polling_service.health" would propagate to root only,
# which has no handlers until main.py runs → INFO logs silently lost.
logger = logging.getLogger("bg_poller.health")

app = FastAPI(title="ETL Background Polling Service", version="1.0.0")

# Injected at startup by main.py
_poller: "BackgroundPoller | None" = None
_oracle_manager: "OracleMetadataManager | None" = None
_etl_conn_str: str = ""


def init_health(poller: "BackgroundPoller", oracle_manager: "OracleMetadataManager", etl_conn_str: str) -> None:
    """Inject dependencies. Called once from main.py before serving."""
    global _poller, _oracle_manager, _etl_conn_str
    _poller = poller
    _oracle_manager = oracle_manager
    _etl_conn_str = etl_conn_str


@app.get("/health")
async def health() -> JSONResponse:
    """Liveness check — always 200 if the process is running."""
    if _poller is None:
        return JSONResponse(status_code=503, content={"status": "not_initialized"})
    return JSONResponse(content={
        "status": "ok",
        "active_runs": len(_poller.active_runs),
        "paused": _poller.paused,
        "worker_id": _poller.config.worker_id,
    })


@app.get("/health/ready")
async def health_ready() -> JSONResponse:
    """Readiness check — 503 if Oracle is unreachable."""
    if _poller is None or _oracle_manager is None:
        return JSONResponse(status_code=503, content={"status": "not_initialized"})
    try:
        ok = await _oracle_check()
        if ok:
            return JSONResponse(content={"status": "ready"})
        return JSONResponse(status_code=503, content={"status": "oracle_unreachable"})
    except Exception as e:
        logger.warning(f"Readiness check failed: {e}")
        return JSONResponse(status_code=503, content={"status": "error", "detail": str(e)})


@app.get("/status")
async def status() -> JSONResponse:
    """Full stats snapshot."""
    if _poller is None:
        return JSONResponse(status_code=503, content={"status": "not_initialized"})
    return JSONResponse(content={
        **_poller.stats,
        "active_runs": len(_poller.active_runs),
        "active_run_ids": list(_poller.active_runs.keys()),
        "paused": _poller.paused,
        "worker_id": _poller.config.worker_id,
        "interval_seconds": _poller.config.interval_seconds,
        "max_concurrent_runs": _poller.config.max_concurrent_runs,
    })


@app.post("/pause")
async def pause() -> JSONResponse:
    """Pause polling — in-flight runs complete normally."""
    if _poller is None:
        raise HTTPException(status_code=503, detail="Poller not initialized")
    _poller.pause()
    return JSONResponse(content={"status": "paused", "active_runs": len(_poller.active_runs)})


@app.post("/resume")
async def resume() -> JSONResponse:
    """Resume polling after a pause."""
    if _poller is None:
        raise HTTPException(status_code=503, detail="Poller not initialized")
    _poller.resume()
    return JSONResponse(content={"status": "resumed"})


async def _oracle_check() -> bool:
    """Lightweight Oracle connectivity check (async). Fail-open — returns False on any error."""
    try:
        result = await asyncio.wait_for(
            asyncio.to_thread(_oracle_manager.health_check),
            timeout=10.0,
        )
        return bool(result)
    except asyncio.TimeoutError:
        logger.warning("Oracle readiness check timed out (10s)")
        return False
    except Exception as e:
        logger.warning(f"Oracle readiness check failed: {e}")
        return False
