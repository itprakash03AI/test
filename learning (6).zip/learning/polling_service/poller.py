"""
Core poll loop for the ETL Background Polling Service.

Responsibilities:
  - Poll Oracle every `interval_seconds` for STATUS='START' tasks
    (LIMIT'd via config.polling_query_limit_multiplier — BF-595)
  - Group rows by RUN_ID → one asyncio.Task per run
  - Cap concurrent asyncio Tasks at `max_concurrent_runs`
  - In-memory `active_runs` dict prevents the same pod from double-
    dispatching
  - BF-595: cross-pod DBMS_LOCK claim via ``try_claim_run`` so two
    polling pods (or polling + standalone DAG operator) never both
    grab the same RUN_ID
  - BF-595: per-run hard timeout via ``config.max_run_seconds`` —
    wedged runs are cancelled + flipped to STATUS=FAILED so the slot
    frees up instead of being pinned until pod restart
  - BF-595: graceful shutdown waits up to
    ``config.shutdown_timeout_seconds`` for in-flight runs to drain,
    then cancels stragglers — K8s grace period no longer SIGKILLs
    mid-step
  - Expose pause/resume for operational control via health API
  - Track stats (polls, dispatched, completed, failed, skipped_cross_pod,
    timed_out) for /status endpoint
"""
import asyncio
import logging
import socket
from typing import TYPE_CHECKING, Dict

if TYPE_CHECKING:
    from polling_service.config import PollingServiceConfig
    from polling_service.dispatcher import Dispatcher
    from managers.oracle_metadata_manager import OracleMetadataManager


class BackgroundPoller:
    """Poll Oracle for START tasks and dispatch each RUN_ID as an asyncio.Task."""

    def __init__(
        self,
        config: "PollingServiceConfig",
        oracle_manager: "OracleMetadataManager",
        dispatcher: "Dispatcher",
        logger: logging.Logger,
    ):
        self.config = config
        self.oracle_manager = oracle_manager
        self.dispatcher = dispatcher
        self.logger = logger

        # run_id → asyncio.Task — prevents double-dispatch within this pod's lifetime
        self.active_runs: Dict[int, asyncio.Task] = {}

        self.stop_event = asyncio.Event()
        self.paused = False
        self.stats = {
            "polls": 0,
            "dispatched": 0,
            "completed": 0,
            "failed": 0,
            # BF-595 new counters
            "skipped_cross_pod": 0,
            "timed_out": 0,
        }
        # BF-595: stable claimer ID for DBMS_LOCK audit log line.
        # hostname:pid uniquely identifies a polling pod / process.
        try:
            self._claimer_id = f"{socket.gethostname()}:{__import__('os').getpid()}"
        except Exception:
            self._claimer_id = config.worker_id

    async def run(self) -> None:
        """Main loop — runs until stop_event is set.

        Stop behaviour:
          stop() sets stop_event → asyncio.wait_for(stop_event.wait()) returns
          immediately without raising TimeoutError → while condition is False
          → exits loop → gathers all in-flight runs to completion.
        """
        self.logger.info(
            f"Background poller started (worker_id={self.config.worker_id}, "
            f"interval={self.config.interval_seconds}s, "
            f"max_concurrent_runs={self.config.max_concurrent_runs})"
        )
        while not self.stop_event.is_set():
            if not self.paused:
                try:
                    await self._poll_once()
                except Exception as e:
                    self.logger.error(f"Poll cycle error: {e}", exc_info=True)
            # Sleep for interval_seconds, but wake immediately if stop_event fires.
            # TimeoutError means normal interval elapsed; no exception means stop was requested.
            try:
                await asyncio.wait_for(
                    asyncio.shield(self.stop_event.wait()),
                    timeout=self.config.interval_seconds,
                )
                # stop_event was set — exit the while on next condition check
            except asyncio.TimeoutError:
                pass  # Normal — interval elapsed, loop again

        # BF-595 (SERIOUS #6): graceful shutdown waits up to
        # ``config.shutdown_timeout_seconds`` for in-flight runs to drain,
        # then cancels stragglers.  Previously this was unbounded — a
        # multi-hour Spark job would block SIGTERM until K8s SIGKILL'd
        # the pod, losing the run mid-step.
        if self.active_runs:
            timeout = max(0, int(self.config.shutdown_timeout_seconds))
            self.logger.info(
                f"Background poller stopped — waiting up to {timeout}s for "
                f"{len(self.active_runs)} active run(s) to finish"
            )
            pending = list(self.active_runs.values())
            try:
                await asyncio.wait_for(
                    asyncio.gather(*pending, return_exceptions=True),
                    timeout=timeout if timeout > 0 else None,
                )
                self.logger.info("All active runs finished cleanly — poller exiting")
            except asyncio.TimeoutError:
                stragglers = [t for t in pending if not t.done()]
                self.logger.warning(
                    f"Shutdown timeout reached — cancelling {len(stragglers)} "
                    f"straggler run(s) to free the pod"
                )
                for t in stragglers:
                    t.cancel()
                # Give cancellation a brief chance to clean up.
                await asyncio.gather(*stragglers, return_exceptions=True)
                self.logger.info("Stragglers cancelled — poller exiting")
        else:
            self.logger.info("Background poller stopped — no active runs, exiting")

    def stop(self) -> None:
        """Signal the poll loop to stop after the current cycle."""
        self.stop_event.set()

    def pause(self) -> None:
        """Pause polling — in-flight runs continue to completion."""
        self.paused = True
        self.logger.info("Polling paused (in-flight runs continue)")

    def resume(self) -> None:
        """Resume polling after a pause."""
        self.paused = False
        self.logger.info("Polling resumed")

    async def _poll_once(self) -> None:
        """Execute one poll cycle: query Oracle → group → dispatch new runs.

        BF-595 (SERIOUS #5): the polling query is now LIMIT'd via
        ``row_limit = max_concurrent_runs × polling_query_limit_multiplier``
        (default 5 × 20 = 100) — bounds query time even when a SOD
        spike piles up thousands of START rows.
        """
        self.stats["polls"] += 1
        poll_num = self.stats["polls"]
        self.logger.debug(f"Poll cycle #{poll_num} starting")

        # BF-595: compute row limit from config.  Over-fetch a multiple
        # of max_concurrent_runs so cross-pod losses + already-active
        # runs don't starve the slot pipeline.
        row_limit = max(
            self.config.max_concurrent_runs,
            self.config.max_concurrent_runs * self.config.polling_query_limit_multiplier,
        )
        all_tasks = await self.oracle_manager.get_all_start_tasks(
            self.config.etl_connection_string,
            self.config.bg_polling_sql,
            row_limit=row_limit,
        )

        if not all_tasks:
            self.logger.debug(f"Poll cycle #{poll_num}: no STATUS='START' tasks found")
            return

        # Group by RUN_ID — rows already sorted RUN_ID ASC, SEQ ASC from query
        runs: Dict[int, list] = {}
        for row in all_tasks:
            run_id = row.get("run_id")
            if run_id is not None:
                runs.setdefault(run_id, []).append(row)

        self.logger.info(
            f"Poll cycle #{poll_num}: found {len(all_tasks)} task row(s) "
            f"across {len(runs)} run(s) (limit={row_limit})"
        )

        dispatched_this_cycle = 0
        deferred = 0
        cross_pod_skipped = 0

        for run_id, tasks in runs.items():
            if run_id in self.active_runs:
                # Already running in this pod — skip silently
                continue

            # asyncio is single-threaded: no await between loop iterations means
            # no task completion (active_runs.pop) can interleave here UNTIL
            # we hit ``await try_claim_run(...)`` below.  After that await,
            # other tasks can run — but the capacity check + cross-pod claim
            # both happen atomically per run_id below, so we never over-dispatch.
            if len(self.active_runs) >= self.config.max_concurrent_runs:
                deferred += 1
                continue  # Slot full — will be picked up next cycle

            # BF-595 (BLOCKER #1): cross-pod safety via DBMS_LOCK.
            # Two polling pods (or polling pod + standalone DAG operator)
            # can both fetch the same START row in the small window
            # before BaseStep flips STATUS=INPROGRESS — without the claim
            # they'd both dispatch and race on output files.  Each
            # session holds the lock for its connection lifetime; the
            # OracleMetadataManager reuses its connection across calls.
            try:
                claimed = await self.oracle_manager.try_claim_run(
                    int(run_id),
                    self._claimer_id,
                    self.config.etl_connection_string,
                )
            except Exception as claim_exc:
                self.logger.warning(
                    f"run_id={run_id}: try_claim_run raised {claim_exc!r} — "
                    f"proceeding WITHOUT claim (degraded cross-pod safety)"
                )
                claimed = True  # fail-open
            if not claimed:
                cross_pod_skipped += 1
                self.stats["skipped_cross_pod"] += 1
                self.logger.info(
                    f"run_id={run_id}: claimed by another pod — skipping"
                )
                continue

            dag_type = _infer_dag_type(tasks[0])
            self.stats["dispatched"] += 1
            dispatched_this_cycle += 1
            self.logger.info(
                f"Dispatching run_id={run_id} dag_type={dag_type} "
                f"steps={len(tasks)} "
                f"({len(self.active_runs) + 1}/{self.config.max_concurrent_runs} slots)"
            )

            task = asyncio.create_task(
                self._execute_run(run_id, tasks, dag_type),
                name=f"run_{run_id}",
            )
            self.active_runs[run_id] = task

        if deferred:
            self.logger.info(
                f"Poll cycle #{poll_num}: {deferred} run(s) deferred "
                f"(at capacity {self.config.max_concurrent_runs})"
            )
        if cross_pod_skipped:
            self.logger.info(
                f"Poll cycle #{poll_num}: {cross_pod_skipped} run(s) skipped "
                f"(claimed by another pod)"
            )
        self.logger.debug(
            f"Poll cycle #{poll_num}: dispatched {dispatched_this_cycle} new run(s), "
            f"{len(self.active_runs)} total active"
        )

    async def _execute_run(self, run_id: int, tasks: list, dag_type: str) -> None:
        """Execute all steps for a single RUN_ID, then remove from active_runs.

        BF-595 (SERIOUS #4): wrapped in ``asyncio.wait_for`` with
        ``config.max_run_seconds`` so a wedged run can't pin its slot
        indefinitely.  On timeout: cancel + log + flip STATUS=FAILED so
        the row doesn't get re-dispatched on the next poll cycle.
        """
        max_secs = int(self.config.max_run_seconds)
        try:
            coro = self.dispatcher.execute(
                run_id,
                tasks,
                dag_type,
                self.config.etl_connection_string,
                self.config.dest_connection_string,
            )
            if max_secs > 0:
                await asyncio.wait_for(coro, timeout=max_secs)
            else:
                await coro
            self.stats["completed"] += 1
            self.logger.info(f"run_id={run_id} completed successfully")
        except asyncio.TimeoutError:
            self.stats["timed_out"] += 1
            self.logger.error(
                f"run_id={run_id} TIMED OUT after {max_secs}s — "
                f"cancelling and flipping STATUS=FAILED"
            )
            # Best-effort flip — the run's own BaseStep error handler
            # may also fire; double-flip to FAILED is idempotent.
            first_task = tasks[0] if tasks else {}
            try:
                await self.oracle_manager.update_otg_etl_batch_status(
                    int(run_id),
                    int(first_task.get("run_detail_id", 0)),
                    "FAILED",
                    str(first_task.get("task_steps", "TIMEOUT")),
                    0,
                    f"BF-595 timeout: run exceeded {max_secs}s",
                    self.config.etl_connection_string,
                )
            except Exception as flip_exc:
                self.logger.warning(
                    f"run_id={run_id}: status-flip-to-FAILED after timeout "
                    f"raised {flip_exc!r}"
                )
        except Exception as e:
            self.stats["failed"] += 1
            self.logger.error(f"run_id={run_id} failed: {e}", exc_info=True)
        finally:
            self.active_runs.pop(run_id, None)


def _infer_dag_type(first_task: dict) -> str:
    """Infer pipeline dag_type from Oracle task metadata.

    Reads OTG_DAG_ID prefix (most reliable — set by Oracle pipeline config)
    then falls back to DB_CONNECTION field.
    Maps to step_mapping.yaml section names: createJob, file, sap_odata,
    s3_query, etc.  New pipeline types added via WORKER_REGISTRY in
    dispatcher.py — keep this function in sync.

    Phase 134-P — ``s3_query`` matched BEFORE the looser ``file``
    branch so an OTG_DAG_ID like ``S3_QUERY_FILE_RUNNER`` routes to
    s3_query (Spark-backed) rather than the legacy file workflow.
    """
    dag_id = (first_task.get("otg_dag_id") or "").lower()
    if "sap" in dag_id:
        return "sap_odata"
    if "s3_query" in dag_id or "s3query" in dag_id:
        return "s3_query"
    if "file" in dag_id:
        return "file"

    # Fallback: DB_CONNECTION field
    db_conn = (first_task.get("db_connection") or "").upper()
    if "SAP" in db_conn:
        return "sap_odata"
    if "S3_QUERY" in db_conn or "S3QUERY" in db_conn:
        return "s3_query"
    if "FILE" in db_conn:
        return "file"

    return "createJob"  # default for Oracle/Starburst pipelines
