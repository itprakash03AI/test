import asyncio
from datetime import datetime
import importlib
import logging
import os
import yaml
from managers.oracle_metadata_manager import OracleMetadataManager
from workers.base_worker import BaseWorker
from managers.step_executor import StepExecutor
from typing import Any, Callable, Dict, List

logger = logging.getLogger(__name__)


class OracleWorker(BaseWorker):
    """Worker for Oracle-related tasks."""

    def __init__(self, starburst_clients: Dict[str, Any], oracle_data_manager: OracleMetadataManager, logger: logging.Logger = None):
        super().__init__(starburst_clients, oracle_data_manager, logger)
        self.step_mapping = self.load_step_mapping('createJob')

    def load_step_mapping(self, workflow: str) -> Dict[str, Callable]:
        """Load step mapping from YAML and dynamically import classes.

        Steps that fail to import are logged as warnings and skipped —
        they will fail at execution time with a clear 'Unsupported step' error.
        """
        mapping_path = "/usr/local/spark/pvc/code/configs/step_mapping.yaml"
        if not os.path.exists(mapping_path):
            raise FileNotFoundError(f"Step mapping file not found: {mapping_path}")
        with open(mapping_path, "r") as f:
            mappings = yaml.safe_load(f)
        if workflow not in mappings:
            raise ValueError(f"No mapping found for workflow: {workflow}")
        step_mapping = {}
        for step_name, details in mappings[workflow].items():
            try:
                module = importlib.import_module(details["module"])
                step_class = getattr(module, details["class"])
                step_mapping[step_name] = step_class
            except (ImportError, AttributeError) as e:
                self.logger.warning(f"Step {step_name} not available (will fail if invoked): {e}")
        self.logger.info(f"Loaded step mapping for {workflow}: {list(step_mapping.keys())}")
        return step_mapping

    async def execute_step(self, task: Dict, worker_connection_string: str, dest_connection_string: str, step_name: str) -> None:
        """Execute a single Oracle task step with retry logic."""
        task_id = task.get("run_id")
        logger.info(f"execute_step started executing step {step_name}")
        if not task_id or not worker_connection_string or not dest_connection_string or not step_name:
            raise ValueError("run_id, worker_connection_string, dest_connection_string, and step_name are required")
        step_executor = StepExecutor(self, self.logger)

        if step_name not in self.step_mapping:
            raise ValueError(f"Unsupported step name: {step_name}")
        step_class = self.step_mapping[step_name]
        try:
            logger.info(f"Executing step {step_name} for task {task_id} with DAG_ID: {task.get('fk_dag_id')} and FK_REPORT_ID: {task.get('fk_report_id')} (SEQ: {task.get('seq')})")
            await step_executor.execute_step_with_retry(
                step_class, task, worker_connection_string, dest_connection_string,
                step_name, event_id=str(task["seq"]),
                dag_run_id=task.get("dag_run_id", f"run_{task['run_id']}"),
                fk_report_id=task.get("fk_report_id"),
            )
        except Exception as ex:
            logger.error(f"Step {step_name} for task {task_id} failed after retries: {str(ex)}")
            raise  # Let the manager handle the failure and halt


