"""Phase 134-P — Worker for the s3_query pipeline.

Loads the ``s3_query`` workflow section from ``step_mapping.yaml``,
resolves each step row's ``TASK_TYPE`` to a Python class, and runs
through the shared ``StepExecutor`` (retry-aware).

Mirrors ``SapOdataWorker`` — no Starburst dependency (Spark talks
direct to S3 / Iceberg / Oracle).
"""
from __future__ import annotations

import importlib
import logging
import os
from typing import Any, Callable, Dict

import yaml

from workers.base_worker import BaseWorker
from managers.step_executor import StepExecutor


logger = logging.getLogger(__name__)


class S3QueryWorker(BaseWorker):
    """Worker for the ``s3_query`` ETL workflow."""

    DEFAULT_MAPPING_PATH = "/usr/local/spark/pvc/code/configs/step_mapping.yaml"

    def __init__(
        self,
        oracle_data_manager: Any,
        logger: logging.Logger = None,
        mapping_path: str = None,
    ):
        super().__init__(
            starburst_clients={},
            oracle_data_manager=oracle_data_manager,
            logger=logger,
        )
        self._mapping_path = mapping_path or self.DEFAULT_MAPPING_PATH
        self.step_mapping = self.load_step_mapping("s3_query")

    def load_step_mapping(self, workflow: str) -> Dict[str, Callable]:
        """Load step mapping from YAML and dynamically import classes.

        Fails-OPEN per individual step: if ``s3_iceberg_query_extract``
        module is missing in this build (e.g. running on a node
        without the Spark deps), other steps in the workflow stay
        executable.  The dispatcher only complains at run time when
        the missing step's TASK_TYPE is actually requested.
        """
        if not os.path.exists(self._mapping_path):
            raise FileNotFoundError(
                f"Step mapping file not found: {self._mapping_path}"
            )
        with open(self._mapping_path, "r") as f:
            mappings = yaml.safe_load(f)
        if workflow not in mappings:
            raise ValueError(
                f"No mapping found for workflow: {workflow!r}"
            )

        step_mapping: Dict[str, Callable] = {}
        for step_name, details in mappings[workflow].items():
            try:
                module = importlib.import_module(details["module"])
                step_class = getattr(module, details["class"])
                step_mapping[step_name] = step_class
            except (ImportError, AttributeError) as exc:
                self.logger.warning(
                    f"Step {step_name} not available in this build: {exc}"
                )

        self.logger.info(
            f"Loaded step mapping for {workflow}: {list(step_mapping.keys())}"
        )
        return step_mapping

    async def execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
    ) -> None:
        """Execute a single pipeline step (retry-aware)."""
        task_id = task.get("run_id")
        self.logger.info(f"Executing step {step_name} for task {task_id}")

        if step_name not in self.step_mapping:
            raise ValueError(
                f"Unsupported step name for s3_query workflow: "
                f"{step_name!r}.  Known: {list(self.step_mapping)}"
            )

        step_class = self.step_mapping[step_name]
        step_executor = StepExecutor(self, self.logger)

        await step_executor.execute_step_with_retry(
            step_class, task, worker_connection_string, dest_connection_string,
            step_name,
            event_id=str(task.get("seq", 0)),
            dag_run_id=task.get("dag_run_id", f"run_{task.get('run_id', 'unknown')}"),
            fk_report_id=task.get("fk_report_id"),
        )
