# SAP OData pipeline -- operator reference

Six steps run in `SEQ` order against the SAP MEBAL endpoint:

```
SapOdataDownload -> SapConsolidateFiles -> SapCompressFiles
   -> SapCheckCompleteness -> SapCreateCTLFile -> SapDeliverFiles
```

Each step is a separate row in `Vw_otg_dag_task` with its own task dict;
state crosses step boundaries via the **sidecar** (see below).


## Quick reference -- knobs

All sourced from the SQL polling query (constants today, promote to
real `Vw_otg_dag_task` columns when needed):

| Polling-row column     | Config key             | Default       | Effect |
| ---------------------- | ---------------------- | ------------- | ------ |
| `SAPU`                 | `sap_username`         | -             | Basic-Auth user |
| `SAPP`                 | `sap_password`         | -             | Basic-Auth password |
| `SAP_COMPANY_API`      | `sap_company_api`      | -             | Company-code roster URL |
| `SAP_ME_BALANCE_API`   | `sap_me_balance_api`   | -             | Data URL with `{min}`/`{max}` placeholders |
| `P_GJAHR`/`P_POPER`    | (read directly)        | -             | Fiscal year + period |
| `RUN_TIMESTAMP`        | `run_timestamp`        | live UTC      | `{TIMESTAMP}` placeholder |
| `OUTPUT_DIR`           | `output_dir`           | data-root     | Base output dir |
| `OUTPUT_FORMAT`        | `output_format`        | `csv`         | `csv` \| `parquet` \| `csv,parquet` |
| `PAGE_SIZE`            | `page_size`            | 50000         | Rows per page (`$top`).  Hard cap `MAX_TOP=50000` |
| `PAGE_TIMEOUT_SECONDS` | `timeout_seconds`      | 120           | Per-page HTTP timeout |
| `CODES_PER_GROUP`      | `codes_per_group`      | 100           | Group ceiling -> `ceil(total_codes / N)` buckets |
| `MAX_PARALLEL_GROUPS`  | `max_parallel_groups`  | 5             | Groups concurrent |
| `INTRA_GROUP_PARALLEL` | `intra_group_parallel` | 2             | Page-fetch threads per group |
| `VERIFY_SSL`           | `verify_ssl`           | `True`        | `'FALSE'` disables ALL cert validation |
| `CA_BUNDLE_PATH`       | `ca_bundle_path`       | -             | Corporate CA bundle (ignored if verify_ssl=False) |
| `PROXY_URL`            | `proxy_url`            | -             | HTTPS proxy |
| `SEND_EMAIL`           | `send_email`           | `False`       | Email start+finish notifications |
| `SMTP_*`/`EMAIL_*`     | -                      | -             | SMTP host/port/from/to/subject |


## Architecture

### Count-driven streaming

```
1. GET /Data/$count                       -> full_count
2. For each group (5 concurrent):
     a. GET /Data/$count?$filter=(...)    -> group expected_count
     b. parallel page fetch (2 threads):
        GET /Data?$filter=(...)&$top=50000&$skip=0
        GET /Data?$filter=(...)&$top=50000&$skip=50000
        ...
     c. write each page to CSV/Parquet sink
     d. Reconcile actual == expected_count
3. Reconcile Sum(per-group $count) == full_count
4. Reconcile Sum(actual rows) == full_count
```

`Sum` = Σ (sigma).  We avoid the unicode char in logs so Windows terminals
don't crash.

### Per-group reconcile with retry

If a group's streamed rows != `$count`, the group retries up to
`group_max_retries` (default 3) with exponential backoff (5s, 10s, 20s).
Each retry **deletes the partial file** then refetches `$count` (so a
SAP race between attempts is visible) and restreams from page 0.

If all retries exhausted, the group's checkpoint is NOT saved -- on a
later outer-pipeline restart the group starts fresh.

### Group failure isolation (parallel mode)

When one group fails in a parallel run, the in-flight groups drain
completely (their checkpoints save) before the failure re-raises.  The
log emits a status ledger (`SUCCEEDED [list] / FAILED [list]`) so an
operator sees the full picture, not just the first stack trace.


## Memory

```
peak per group     = (intra_group_parallel + 1) * PAGE_SIZE * ~1.9KB/row
peak overall       = max_parallel_groups * peak_per_group
```

With defaults (5 x 2 x 50000):
- Per group:  (2+1) * 50000 * 1900 / 1e6  = ~285 MB
- Overall:    5 * 285                       = ~1.4 GB peak

The fetcher is **bounded** -- never more than `intra_group_parallel`
futures in flight per group at any moment, even if the sink (main
thread) falls behind.  No unbounded pile-up.

**To reduce memory:**
- `PAGE_SIZE=10000` -> ~57 MB/group -> ~285 MB overall
- `INTRA_GROUP_PARALLEL=1` (serial within group) -> ~190 MB/group
- `MAX_PARALLEL_GROUPS=2` -> two groups instead of five

**To go faster:**
- `MAX_PARALLEL_GROUPS=10`, `INTRA_GROUP_PARALLEL=3` -> 30 in flight
- `OUTPUT_FORMAT=parquet` -> 5-10x faster serialization vs CSV
- Bump `RATE_LIMIT_RPS=20` if SAP can handle it


## Restart / resume

### Per-group retry within same run
- Partial file `os.remove`'d before next attempt -> fresh streaming
- Inside `_download_group`, no state leakage between attempts

### Whole-step restart of same RUN_ID
- Sidecar (`<base>/_sap_state_<RUN_ID>.json`) carries `run_subdir`
- `_resolve_output_dir` reads sidecar first -> REUSES the same subdir
- Per-group checkpoint inside the subdir lets completed groups SKIP
- Only failed groups re-download

### Brand-new RUN_ID
- Fresh timestamped subdir under base
- Prior run's data untouched (no auto-cleanup -- manual `rm -rf`)


## Cross-step state handoff

Each polling row produces its own task dict, so direct sharing
(`task['downloaded_files']`) doesn't work across steps.  Bridge:

**Sidecar JSON file** keyed by `RUN_ID`:

```
<OUTPUT_DIR>/_sap_state_<run_id>.json
```

Contains:
- `run_subdir`
- `downloaded_files`
- `consolidated_file`/`consolidated_files`
- `compressed_file`
- `ctl_file`
- `p_gjahr`/`p_poper`
- `output_format`/`output_formats`
- `full_count`/`per_group_counts`/`totalcount`
- `checksum`/`compressed_size`/`uncompressed_size`

Each step calls `_hydrate_from_sidecar` on entry and `_save_sidecar` on
exit.  Atomic write (`.tmp` -> `os.replace`).


## Planning artefacts (always-on)

Before any per-group HTTPS call, the download step dumps:

| File                           | Contents |
| ------------------------------ | -------- |
| `company_codes.csv`            | One row per code, sorted, deduped |
| `groups.csv`                   | One row per (group, code) with `group_min`, `group_max`, `group_size` |

`grep '8120' groups.csv` shows exactly which group's `$filter` covers
that code.


## Run report (always written, success OR failure)

In `output_dir/`:

| File              | Use |
| ----------------- | --- |
| `run_report.html` | Browser-friendly: status, ledger, group table, URLs, output files |
| `run_report.txt`  | Grep-friendly text version |

Written in the `finally:` block so a crash mid-download still produces
a partial report.  Updated in three points:
1. After fiscal-period resolved (START state, partial knobs)
2. After download success (full state, completeness ledger green)
3. After exception (FAILED state, error block)


## Email

Local-dev: leave `SEND_EMAIL=FALSE` -- nothing leaves the pod, report
still on disk.

Prod: `SEND_EMAIL=TRUE` + SMTP knobs.  Sends:
- **START** email after fiscal period resolves
- **FINISH** email in `finally:` (success: green status; failure: red
  with error block)

Email send failure is logged WARN, never raises.


## Completeness gates

| Gate | Where | What |
| ---- | ----- | ---- |
| G1 full `$count`         | Download pre-flight                 | Source of truth |
| G2 Sum(per-group `$count`) | Download summation reconcile        | `== G1` or company-code partitioning incomplete |
| G3 Sum(actual rows)        | Download summation reconcile        | `== G1` or paging gap |
| G4 actual `==` per-group `$count` | Download per-group reconcile | retried up to 3x |
| G5 negative `$count`     | `_fetch_odata_count`                | Refuses to proceed |
| G6 consolidated `== G1`  | Consolidate row-count guard         | catches merge bugs |
| G7 final `totalcount == G1` | SapCheckCompleteness             | end-of-pipeline gate |
| G8 file exists + non-empty | SapCheckCompleteness              | guards against missing payload |

All gates raise `ValueError` unless `allow_count_mismatch=true` --
operator escape hatch when SAP data is intentionally drifting.


## Failure-scenario matrix

| # | Scenario | Detection / Outcome |
| - | -------- | ------------------- |
| 1 | Per-group `$count` != streamed   | Retried up to 3x; if exhausted, raise (checkpoint not saved -> outer restart re-tries fresh) |
| 2 | Sum(per-group) != full           | Raised by `_reconcile_full_vs_sum` -- company-code partitioning incomplete |
| 3 | Sum(actual) != full              | Same method, different message |
| 4 | One group fails in parallel mode | Other in-flight groups drain; status ledger logged; first error re-raised |
| 5 | Pod crashes mid-group            | Per-group checkpoint not saved; on restart, same `run_subdir` reused via sidecar; group re-streams |
| 6 | Pod crashes between steps        | Sidecar persists state; next step hydrates from disk |
| 7 | `$count` returns negative        | `_fetch_odata_count` refuses -> raise |
| 8 | `$count`=0 but data exists       | Documented limitation; can't auto-detect without `$top=1` probe |
| 9 | Checkpoint stale (codes changed) | Codes-fingerprint check wipes stale file + re-downloads |
| 10 | Consolidate drops rows          | `total_rows != download_total` -> raise |
| 11 | `totalcount != full_count`      | CheckCompleteness raises |
| 12 | Network timeout mid-stream      | urllib3 retry adapter handles 5xx/429; 4xx + connection-drop -> group retry |
| 13 | Empty output file               | CheckCompleteness file-size guard |
| 14 | Unicode in SAP value            | UTF-8 file handler; stdout `errors='replace'`; ASCII-only log messages |
| 15 | HTTPS pool exhaustion           | Pool auto-scales: `2 * (max_parallel * intra_parallel + max_parallel)` |
| 16 | Stale `ca_bundle_path`          | `verify_ssl=False` overrides everything; missing CA bundle logs WARN, falls back to system CA |
| 17 | OUTPUT_DIR confused with run_subdir | `_resolve_output_dir` refuses bare-base; sidecar tells us the real run_subdir |


## Deep-dive items still open

- **Page-level resume** -- a group failing at page 179/180 restreams from page 0.  For 9 M rows this can waste ~5-10 min.  Page checkpoint would fix this.
- **eq-OR filter mode** -- range filter has a gap hazard if SAP MEBAL data exists for codes not in the company roster.  Switching to `Companycode eq 'X' or Companycode eq 'Y'` would close it (URL length permitting).
- **Schema drift** -- new columns mid-stream get dropped with WARN.  Could escalate to ERROR with a flag.
- **Direct-to-Oracle sink** -- C# pushes to Oracle, bypassing CSV.  ~3x faster.  Would skip Consolidate + Compress steps entirely.
