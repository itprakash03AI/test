"""
Create CTL (Control) File step.
Generates a template-based control file with runtime variable substitution.
Template and variables are fully configurable via JSON config.
"""
import os
from datetime import datetime
from typing import Dict

from steps.sap_odata_base import SapOdataBase


class CreateCTLFile(SapOdataBase):
    """Generate a template-based control file."""

    LOG_PREFIX = "create_ctl_file"

    REQUIRED_FIELDS = []

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        # Source file (compressed or consolidated)
        data_file = task.get('compressed_file', task.get('consolidated_file', ''))
        if not data_file:
            raise ValueError("No data file found in task — CompressFiles or ConsolidateFiles must run first")

        # Template from config
        template = config.get('ctl_template', '')
        if not template:
            self.logger.info("No ctl_template in config — skipping CTL generation")
            task['ctl_file'] = ''
            return task.get('totalcount', 0)

        # Build CTL filename
        ctl_filename = config.get('ctl_filename', '')
        if not ctl_filename:
            base_name = os.path.splitext(os.path.basename(data_file))[0]
            # Strip .csv from .csv.gz
            if base_name.endswith('.csv'):
                base_name = base_name[:-4]
            ctl_filename = f"{base_name}.ctl"

        output_dir = task.get('output_dir', os.path.dirname(data_file))
        ctl_path = os.path.join(output_dir, ctl_filename)

        # Build substitution variables.
        # Phase 134 — added TASK_ID / RUN_ID / RUN_DETAIL_ID / OTG_DAG_ID
        # and BUSINESS_DATE so the SAP balance CTL template can carry
        # the operator-visible identifiers the user requested.  Falls
        # back to a sensible default for each if the polling row didn't
        # populate it.
        # The CTL template references these as {{TASK_ID}}, {{RUN_ID}},
        # etc.  TASK_ID defaults to RUN_DETAIL_ID since that's the
        # finest-grained per-step identifier (matches "994665" in the
        # SAP example).
        run_id        = task.get('run_id') or task.get('RUN_ID') or ''
        run_detail_id = task.get('run_detail_id') or task.get('RUN_DETAIL_ID') or ''
        otg_dag_id    = task.get('otg_dag_id') or task.get('OTG_DAG_ID') or ''
        business_date = (task.get('business_date') or task.get('BUSINESS_DATE')
                         or datetime.now().strftime('%Y-%m-%d'))
        task_id       = (task.get('task_id') or task.get('TASK_ID')
                         or run_detail_id or run_id)
        variables = {
            'FILENAME': os.path.basename(data_file),
            'FILEPATH': data_file,
            'RECORD_COUNT': str(task.get('totalcount', 0)),
            'CHECKSUM': task.get('checksum', ''),
            'TIMESTAMP': datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
            'DATE': datetime.now().strftime('%Y-%m-%d'),
            'COMPRESSED_SIZE': str(task.get('compressed_size', 0)),
            'UNCOMPRESSED_SIZE': str(task.get('uncompressed_size', 0)),
            'POPER': task.get('p_poper', ''),
            'GJAHR': task.get('p_gjahr', ''),
            'PERIOD_MODE': config.get('period_mode', ''),
            # Phase 134 — task identifiers exposed to CTL templates
            'TASK_ID':        str(task_id),
            'RUN_ID':         str(run_id),
            'RUN_DETAIL_ID':  str(run_detail_id),
            'OTG_DAG_ID':     str(otg_dag_id),
            'BUSINESS_DATE':  str(business_date),
        }

        # Add any custom variables from config
        custom_vars = config.get('ctl_custom_variables', {})
        variables.update(custom_vars)

        # Substitute {{VAR}} placeholders
        ctl_content = template
        for key, value in variables.items():
            ctl_content = ctl_content.replace(f"{{{{{key}}}}}", str(value))

        # Write CTL file
        with open(ctl_path, 'w', encoding='utf-8') as f:
            f.write(ctl_content)

        self.logger.info(f"CTL file created: {ctl_path}")
        task['ctl_file'] = ctl_path

        return task.get('totalcount', 0)
