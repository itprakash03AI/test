"""Phase 134-P — Parquet → file via user SQL.

Reads parquet files from ``s3a://bucket/prefix`` (Spark's parquet
reader handles partition discovery + row-group filter pushdown
automatically), runs the user's SQL against the resulting DataFrame,
writes the result to a local NFS file.
"""
from __future__ import annotations

from typing import Any, Dict

from steps.s3_query_base import S3QueryBase


class S3ParquetQueryExtract(S3QueryBase):
    """Read parquet via Spark SQL, sink to file on NFS."""

    LOG_PREFIX = "s3_parquet_query_extract"

    REQUIRED_FIELDS = [
        *S3QueryBase.BASE_REQUIRED_FIELDS,
        "s3_prefix", "output_path",
    ]

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        spark = None
        try:
            spark = self._build_spark_session_s3(task, config, with_iceberg=False)
            df, total_rows, _read_time = self._read_parquet_with_query(spark, config, task)
            task["totalcount"] = total_rows
            output_path, _write_time = self._write_to_file(df, config, task)
            self._set_delivery_chain_aliases(task, output_path)

            if self.oracle_data_manager:
                await self.oracle_data_manager.update_otg_etl_batch_status(
                    task.get("run_id"), task.get("run_detail_id"),
                    "UPDATE_TASK_RECORDCOUNT", step_name,
                    total_rows, "", worker_connection_string,
                )
            return total_rows

        except Exception as exc:
            self.logger.error(f"JOB FAILED: {exc}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    spark.stop()
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
