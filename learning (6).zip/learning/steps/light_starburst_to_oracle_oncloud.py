"""BF-595 (2026-05-30) — non-Spark Starburst (Cloud) → Oracle step.

Drop-in lightweight replacement for ``StarburstToOracle_OnCloud``
used by the polling-service path.  Same config-file format, same
task contract, same STATUS lifecycle — Spark removed.

See ``light_starburst_base.LightStarburstBase`` for the full
rationale and trade-offs.
"""
from steps.light_starburst_base import LightStarburstBase


class LightStarburstToOracle_OnCloud(LightStarburstBase):
    """Non-Spark step to read from Starburst Cloud (Trino) and write to Oracle."""
    QUERY_KEY = "query_on_cloud"
    TRINO_URL_KEY = "trino_oncloud_url"
    LOG_PREFIX = "light_sb_to_oracle_oncloud"
