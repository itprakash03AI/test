"""SAP-flow deliver-files step.

Self-contained -- no inheritance from the generic ``DeliverFiles``.
Inherits only from ``SapOdataBase`` for the SAP-specific config loader
+ logger setup.

Uploads the (gz payload, ctl) pair to S3, SFTP, or NFS.  Delivery
type is config-driven via ``delivery_type``.

Phase 134-K hardening inline:
  * **SFTP host-key verification** (RejectPolicy + known_hosts) -- closes
    the MITM-trivial pre-Phase-134-K gap where paramiko.Transport ran
    with no host-key check.  AutoAddPolicy only when an explicit
    ``sftp_auto_add_host=true`` bootstrap flag is set.
  * **Recursive SFTP mkdir** -- one-level ``sftp.mkdir`` died on deep
    remote paths.
  * **Data-file-first / CTL-file-last ordering** -- a crashed upload
    never leaves a CTL pointing at a missing payload.
  * **Atomic ``.tmp`` rename** on SFTP / ``os.replace`` on NFS / S3
    multipart abort on error -- downstream readers never see partial
    files.
"""
import os
import shutil
from typing import Any, Dict, List, Optional, Tuple

from steps.sap_odata_base import SapOdataBase


class SapDeliverFiles(SapOdataBase):
    """SAP delivery of (gz, ctl) pair to S3 / SFTP / NFS."""

    LOG_PREFIX = "sap_deliver_files"

    REQUIRED_FIELDS: List[str] = []

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)
        self._hydrate_from_sidecar(task, config)

        delivery_type = config.get('delivery_type', 'nfs')

        # Explicit ordering: DATA first, CTL last.  Pre-Phase-134-K
        # contract wasn't enforced -- if CTL landed before data and
        # the data upload failed, downstream consumers saw a CTL
        # pointing at a missing file.
        data_file: Optional[str] = None
        ctl_file: Optional[str] = None
        compressed = task.get('compressed_file', '')
        if compressed and os.path.exists(compressed):
            data_file = compressed
        ctl = task.get('ctl_file', '')
        if ctl and os.path.exists(ctl):
            ctl_file = ctl

        if not data_file and not ctl_file:
            raise ValueError(
                "No files to deliver -- SapCompressFiles/SapCreateCTLFile must run first"
            )

        ordered: List[Tuple[str, str]] = []
        if data_file:
            ordered.append(("data", data_file))
        if ctl_file:
            ordered.append(("ctl", ctl_file))

        self.logger.info(
            "Delivering %d files via %s (order: %s)",
            len(ordered), delivery_type,
            ", ".join(f"{k}:{os.path.basename(p)}" for k, p in ordered),
        )

        if delivery_type == 's3':
            self._deliver_to_s3(config, ordered)
        elif delivery_type == 'sftp':
            self._deliver_to_sftp(config, ordered)
        elif delivery_type == 'nfs':
            self._deliver_to_nfs(config, ordered)
        else:
            raise ValueError(f"Unknown delivery_type: {delivery_type}")

        self.logger.info(f"Delivery complete ({delivery_type})")
        return task.get('totalcount', 0)

    # -- S3 ----------------------------------------------------------

    def _deliver_to_s3(self, config: Dict, ordered: List[Tuple[str, str]]):
        """Upload files to S3 via boto3.

        DATA-first / CTL-last ordering enforced by the caller's
        ``ordered`` list.  Each upload is wrapped in a try/except that,
        on failure, lists + aborts any in-flight multipart uploads
        under the same key so partial parts don't linger on S3.
        """
        import boto3
        from botocore.exceptions import BotoCoreError, ClientError

        bucket = config.get('s3_bucket', '')
        prefix = config.get('s3_prefix', '').rstrip('/')

        if not bucket:
            raise ValueError("s3_bucket is required for S3 delivery")

        s3_client = boto3.client(
            's3',
            endpoint_url=config.get('s3_endpoint_url') or None,
            aws_access_key_id=config.get('s3_access_key', ''),
            aws_secret_access_key=config.get('s3_secret_key', ''),
        )

        for kind, file_path in ordered:
            filename = os.path.basename(file_path)
            s3_key = f"{prefix}/{filename}" if prefix else filename

            self.logger.info(
                "Uploading %s file %s -> s3://%s/%s",
                kind, filename, bucket, s3_key,
            )
            try:
                s3_client.upload_file(file_path, bucket, s3_key)
                self.logger.info("Uploaded successfully (%s)", kind)
            except (BotoCoreError, ClientError, OSError) as exc:
                self.logger.error(
                    "S3 upload failed for %s (%s): %s -- aborting any "
                    "in-flight multipart uploads under the same key",
                    filename, kind, exc,
                )
                self._abort_in_flight_multipart(s3_client, bucket, s3_key)
                raise

    @staticmethod
    def _abort_in_flight_multipart(s3_client: Any, bucket: str, key: str) -> None:
        """List + abort every in-flight multipart upload under bucket/key.

        Boto3's ``upload_file`` initiates a multipart upload for files
        >8 MB but does NOT abort it on exception, so partial parts
        linger on S3 (billed for storage forever).  Best-effort -- never
        raises further.
        """
        try:
            resp = s3_client.list_multipart_uploads(Bucket=bucket, Prefix=key)
            for upload in resp.get("Uploads", []) or []:
                if upload.get("Key") != key:
                    continue
                upload_id = upload.get("UploadId")
                try:
                    s3_client.abort_multipart_upload(
                        Bucket=bucket, Key=key, UploadId=upload_id,
                    )
                except Exception:
                    pass
        except Exception:
            pass

    # -- NFS ---------------------------------------------------------

    def _deliver_to_nfs(self, config: Dict, ordered: List[Tuple[str, str]]):
        """Copy files to an NFS / shared-volume destination.

        Atomic ``shutil.copy2 -> os.replace`` so a crashed copy never
        leaves a half-file downstream readers can mistake for complete.
        Data file first, CTL last.
        """
        dest_dir = config.get('nfs_dest_dir', '')
        if not dest_dir:
            raise ValueError("nfs_dest_dir is required for NFS delivery")

        os.makedirs(dest_dir, exist_ok=True)

        for kind, file_path in ordered:
            filename = os.path.basename(file_path)
            dest_path = os.path.join(dest_dir, filename)
            tmp_path = dest_path + ".tmp"

            self.logger.info(
                "Copying %s file %s -> %s (via .tmp)",
                kind, filename, dest_path,
            )
            try:
                shutil.copy2(file_path, tmp_path)
                os.replace(tmp_path, dest_path)
                self.logger.info("Copied successfully (%s)", kind)
            except Exception:
                # Clean up partial .tmp on failure.
                if os.path.exists(tmp_path):
                    try: os.remove(tmp_path)
                    except Exception: pass
                raise

    # -- SFTP --------------------------------------------------------

    def _deliver_to_sftp(self, config: Dict, ordered: List[Tuple[str, str]]):
        """Upload files via SFTP using paramiko.

        Host-key verification, recursive mkdir, data-first ordering,
        and atomic rename all enforced inline.
        """
        import paramiko

        host = config.get('sftp_host', '')
        port = int(config.get('sftp_port', 22) or 22)
        username = config.get('sftp_username', '')
        password = config.get('sftp_password', '')
        key_path = config.get('sftp_key_path', '')
        remote_dir = (config.get('sftp_remote_dir', '/') or '/').rstrip('/') or '/'

        if not host or not username:
            raise ValueError(
                "sftp_host and sftp_username are required for SFTP delivery"
            )

        # Host-key verification: SSHClient with RejectPolicy + known_hosts
        # by default; AutoAddPolicy only for explicit bootstrap.
        client = paramiko.SSHClient()
        auto_add = bool(config.get('sftp_auto_add_host', False))
        known_hosts_path = (
            config.get('sftp_known_hosts_path')
            or os.path.expanduser('~/.ssh/known_hosts')
        )
        if os.path.exists(known_hosts_path):
            try:
                client.load_host_keys(known_hosts_path)
                self.logger.info("SFTP: loaded host keys from %s", known_hosts_path)
            except (IOError, OSError) as exc:
                self.logger.warning(
                    "SFTP: could not load %s: %s -- host-key check still "
                    "active (will reject unknown hosts unless "
                    "sftp_auto_add_host=true)", known_hosts_path, exc,
                )
        if auto_add:
            self.logger.warning(
                "SFTP: sftp_auto_add_host=true -- accepting NEW host keys for %s.  "
                "Use ONLY for bootstrap; revert to default after first "
                "successful connection.", host,
            )
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        else:
            client.set_missing_host_key_policy(paramiko.RejectPolicy())

        # Connect.  Try RSA, then Ed25519, then ECDSA for the key file.
        connect_kwargs: Dict[str, Any] = dict(
            hostname=host, port=port, username=username,
            timeout=int(config.get('sftp_connect_timeout', 30) or 30),
            banner_timeout=int(config.get('sftp_banner_timeout', 30) or 30),
            auth_timeout=int(config.get('sftp_auth_timeout', 30) or 30),
        )
        if key_path and os.path.exists(key_path):
            try:
                connect_kwargs['pkey'] = paramiko.RSAKey.from_private_key_file(key_path)
            except paramiko.SSHException:
                try:
                    connect_kwargs['pkey'] = paramiko.Ed25519Key.from_private_key_file(key_path)
                except paramiko.SSHException:
                    connect_kwargs['pkey'] = paramiko.ECDSAKey.from_private_key_file(key_path)
        else:
            connect_kwargs['password'] = password

        client.connect(**connect_kwargs)
        try:
            sftp = client.open_sftp()
            try:
                self._sftp_makedirs(sftp, remote_dir)
                for kind, file_path in ordered:
                    filename = os.path.basename(file_path)
                    remote_path = f"{remote_dir.rstrip('/')}/{filename}"
                    tmp_path = remote_path + ".tmp"
                    self.logger.info(
                        "Uploading %s file %s -> %s:%s (via .tmp)",
                        kind, filename, host, remote_path,
                    )
                    try:
                        sftp.put(file_path, tmp_path)
                        # Atomic rename so a crashed upload leaves a .tmp
                        # downstream readers ignore, not a half-file they
                        # mistake for complete.
                        try:
                            sftp.posix_rename(tmp_path, remote_path)
                        except AttributeError:
                            # Older paramiko / non-OpenSSH servers
                            # lacking posix-rename@openssh.com -- fall
                            # back to remove + rename.
                            try: sftp.remove(remote_path)
                            except IOError: pass
                            sftp.rename(tmp_path, remote_path)
                        self.logger.info(
                            "Uploaded successfully (%s) %s", kind, remote_path,
                        )
                    except Exception:
                        try: sftp.remove(tmp_path)
                        except Exception: pass
                        raise
            finally:
                sftp.close()
        finally:
            client.close()

    @staticmethod
    def _sftp_makedirs(sftp: Any, remote_dir: str) -> None:
        """Recursive ``mkdir -p`` over SFTP.

        Pre-Phase-134-K code did ``sftp.mkdir(remote_dir)`` once which
        failed when the parent didn't exist (e.g. /a/b/c/d with /a/b
        missing).  Walks each component, stat-then-mkdir.
        """
        if not remote_dir or remote_dir == '/':
            return
        parts = [p for p in remote_dir.split('/') if p]
        cur = '/' if remote_dir.startswith('/') else ''
        for p in parts:
            cur = (cur.rstrip('/') + '/' + p) if cur else p
            try:
                sftp.stat(cur)
            except (FileNotFoundError, IOError):
                try:
                    sftp.mkdir(cur)
                except (IOError, OSError):
                    # Race: another process may have created it between
                    # our stat and mkdir.  Re-stat; re-raise if missing.
                    try:
                        sftp.stat(cur)
                    except Exception:
                        raise
