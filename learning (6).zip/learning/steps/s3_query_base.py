"""Phase 134-P (2026-06-02) — S3 query base step.

Shared base for the new ``s3_query`` workflow that lets users execute a
SQL query directly against S3-resident Parquet OR Iceberg sources, then
sink the result to a file (NFS) or Oracle (JDBC).

Architecture
============

::

   S3BaseStep                            (existing — Spark + S3A + Iceberg + Oracle JDBC helpers)
   └── S3QueryBase                       (THIS FILE — shared read + write-to-file helpers)
       ├── S3IcebergQueryExtract          (sink: file)
       ├── S3ParquetQueryExtract          (sink: file)
       ├── S3IcebergQueryToOracle         (sink: Oracle JDBC, via _write_to_oracle)
       └── S3ParquetQueryToOracle         (sink: Oracle JDBC, via _write_to_oracle)

Each leaf is intentionally thin: source-side reader + sink-side writer
swap, no other behaviour.  All four share the per-task JSON config
shape (single ``query`` field with ``{BUSINESSDATE}`` / ``{SYSTEM_ENTITY}``
placeholders that the existing ``_parameterize_query`` resolves at run
time).

Pushdown
========

For Iceberg, Spark's catalyst optimiser pushes ``WHERE`` predicates
into the iceberg scanner — pruning data files via manifest stats
before any S3 read.  For Parquet, the same optimiser pushes filters
into the parquet reader's row-group filter (when the WHERE columns
have min/max stats).  Both are zero extra code on our side: emit the
DataFrame via ``spark.sql(...)`` and Spark does the rest.

Why this isn't shared with backend/core/dataflow/stages/sql_query_stage.py
==========================================================================

That stage runs inside the QueryStudio backend pod and uses DuckDB —
it cannot pull in Spark / Iceberg / Glue / Hive.  This file's steps
run inside the Spark container (image built from
``Dockerfile.polling-service``) and use Spark exclusively.  The
backend DuckDB path's pruning is BF-498..505 + Phase 134-O; this
Spark path's pruning is whatever Spark+Iceberg gives us natively.
The two are intentionally orthogonal.
"""
from __future__ import annotations

import os
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from steps.s3_base_step import S3BaseStep


class S3QueryBase(S3BaseStep):
    """Common helpers for the s3_query workflow.

    Subclasses pick the SOURCE (iceberg / parquet) and SINK (file /
    oracle) and stitch them together inside ``_execute_step``.
    """

    # Minimum S3 creds every leaf needs.  Iceberg leaves bolt on
    # catalog fields; Oracle-sink leaves bolt on oracle_url etc.
    BASE_REQUIRED_FIELDS = [
        "s3_access_key", "s3_secret_key", "s3_bucket",
        "query",
    ]

    SOURCE_VIEW_NAME = "source"

    # ── Source readers ──────────────────────────────────────────────────

    @staticmethod
    def _resolve_iceberg_full_table(table_fqn: str, catalog_name: str) -> str:
        """Resolve the fully-qualified iceberg table name.

        Rules:
          * If ``table_fqn`` is already ``{catalog_name}.…`` (exact
            first segment match), return it verbatim.
          * Otherwise prepend ``catalog_name.`` so Spark routes the
            read through the configured Iceberg catalog.

        Audit fix: previously used ``startswith(catalog_name + ".")``
        which silently accepted ``iceberg_catalog2.db.tbl`` as already
        prefixed when ``catalog_name=iceberg_catalog`` (matches by
        prefix, not by segment).  Now splits on the first ``.`` and
        compares the first segment exactly.
        """
        if "." in table_fqn:
            first_segment = table_fqn.split(".", 1)[0]
            if first_segment == catalog_name:
                return table_fqn
        return f"{catalog_name}.{table_fqn}"

    def _read_iceberg_with_query(
        self, spark, config: Dict, task: Dict,
    ) -> Tuple[Any, int, float]:
        """Read an Iceberg table and run the user's SQL against it.

        Returns ``(dataframe, total_rows, read_time_seconds)``.

        The Iceberg table is exposed as a temp view named
        ``source`` so the user's ``query`` reads naturally as
        ``SELECT ... FROM source WHERE ...``.

        Validates that the catalog wiring is complete before kicking
        off Spark — without this, missing ``iceberg_catalog_uri`` /
        ``iceberg_warehouse`` produces a confusing AnalysisException
        deep inside Spark instead of a clear config error here.
        """
        table_fqn = config.get("iceberg_table") or config.get("table_fqn")
        if not table_fqn:
            raise ValueError(
                "iceberg_table is required for iceberg-source steps"
            )
        catalog_type = (config.get("iceberg_catalog_type") or "rest").lower()
        if catalog_type in ("rest", "hive") and not config.get("iceberg_catalog_uri"):
            raise ValueError(
                f"iceberg_catalog_uri is required for "
                f"iceberg_catalog_type={catalog_type!r} — without it "
                f"Spark cannot connect to the catalog"
            )
        if catalog_type == "rest" and not config.get("iceberg_warehouse"):
            raise ValueError(
                "iceberg_warehouse is required for REST catalogues so "
                "Spark knows where to resolve table locations"
            )
        # Phase 134-P — validate time-travel config BEFORE touching
        # spark so a misconfigured task fails fast with a clear error
        # instead of an AttributeError mid-read.
        snapshot_id = config.get("snapshot_id")
        as_of_ts_ms = config.get("as_of_timestamp_ms")
        if snapshot_id is not None and as_of_ts_ms is not None:
            raise ValueError(
                "snapshot_id and as_of_timestamp_ms are mutually "
                "exclusive — set at most one"
            )
        catalog_name = config.get("iceberg_catalog_name", "iceberg_catalog")
        full_table = self._resolve_iceberg_full_table(table_fqn, catalog_name)
        self.logger.info(f"Iceberg source: {full_table}")
        read_start = datetime.now()

        # Phase 134-P (supplement pruning) — optional QS-supplement-
        # aware file-level pruning.  When enabled AND the table has
        # no partition transforms / delete files (we detect both and
        # refuse the pruned path to avoid correctness bugs), we
        # bypass Spark+Iceberg's reader, hand-pick the data files
        # via manifest+supplement bounds, and feed the surviving file
        # list directly to ``spark.read.parquet([files])``.
        df = self._supplement_pruned_read(
            spark, config, full_table, snapshot_id, as_of_ts_ms,
        )
        if df is None:
            # Standard path — Spark+Iceberg reader handles everything
            # (manifest pruning, deletes, transforms, schema evo).
            reader = spark.read.format("iceberg")
            if snapshot_id is not None:
                self.logger.info(
                    f"Iceberg time-travel: snapshot-id={snapshot_id}"
                )
                reader = reader.option("snapshot-id", str(snapshot_id))
            elif as_of_ts_ms is not None:
                self.logger.info(
                    f"Iceberg time-travel: as-of-timestamp={as_of_ts_ms} (ms)"
                )
                reader = reader.option("as-of-timestamp", str(as_of_ts_ms))
            df = reader.load(full_table)
        df.createOrReplaceTempView(self.SOURCE_VIEW_NAME)
        query = self._parameterize_query(config["query"], task)
        self.logger.info(
            f"Running user query against iceberg source "
            f"(length={len(query)}):\n{query}"
        )
        result_df = spark.sql(query)
        total_rows = result_df.count()
        read_time = (datetime.now() - read_start).total_seconds()
        self.logger.info(f"Iceberg query produced {total_rows} rows in {read_time:.2f}s")
        return result_df, total_rows, read_time

    def _read_parquet_with_query(
        self, spark, config: Dict, task: Dict,
    ) -> Tuple[Any, int, float]:
        """Read parquet files from ``s3a://bucket/prefix`` and run the
        user's SQL against them.

        ``s3_prefix`` may include ``{BUSINESSDATE}`` / ``{SYSTEM_ENTITY}``
        placeholders so the same config can drive different partitions
        across runs.
        """
        prefix_raw = config.get("s3_prefix", "")
        if not prefix_raw:
            raise ValueError(
                "s3_prefix is required for parquet-source steps"
            )
        prefix = self._parameterize_query(prefix_raw, task)
        bucket = config["s3_bucket"]
        s3_input_path = f"s3a://{bucket}/{prefix}"
        self.logger.info(f"Parquet source: {s3_input_path}")
        read_start = datetime.now()
        df = spark.read.parquet(s3_input_path)
        df.createOrReplaceTempView(self.SOURCE_VIEW_NAME)
        query = self._parameterize_query(config["query"], task)
        self.logger.info(
            f"Running user query against parquet source "
            f"(length={len(query)}):\n{query}"
        )
        result_df = spark.sql(query)
        total_rows = result_df.count()
        read_time = (datetime.now() - read_start).total_seconds()
        self.logger.info(f"Parquet query produced {total_rows} rows in {read_time:.2f}s")
        return result_df, total_rows, read_time

    # ── Supplement-pruning path (Phase 134-P) ─────────────────────────

    def _supplement_pruned_read(
        self, spark, config: Dict,
        full_table: str,
        snapshot_id: Any,
        as_of_ts_ms: Any,
    ):
        """Try the supplement-pruned read path.  Returns a Spark
        DataFrame when the pruned path applies, else ``None`` (caller
        falls back to the standard Spark+Iceberg reader).

        REFUSES (returns None) when ANY of these hold:

          * ``config['use_supplement_pruning']`` is not truthy
          * ``config['querystudio_db_connection_string']`` is missing
          * Required Python deps (pyiceberg, sqlglot, oracledb) aren't
            installed
          * The user's WHERE has no extractable predicates
          * The iceberg table uses partition transforms (bucket /
            truncate / year / month / day / hour) — pruned path
            can't reproduce those without re-implementing iceberg's
            ``Transform.project()``
          * The snapshot has equality or position delete files —
            pruned path's ``read.parquet([files])`` doesn't apply
            deletes; results would be wrong

        Every refusal logs the reason at INFO so operators can debug
        why supplement pruning isn't kicking in.

        Phase 134-P scope note
        ----------------------
        This is intentionally conservative.  Later sessions can
        narrow the refusal set (e.g. handle position deletes by
        excluding their target rows, handle date transforms by
        translating the predicate).
        """
        if not config.get("use_supplement_pruning"):
            return None
        qs_db = config.get("querystudio_db_connection_string")
        if not qs_db:
            self.logger.info(
                "supplement pruning enabled but querystudio_db_"
                "connection_string is empty — falling back to standard "
                "iceberg path"
            )
            return None

        try:
            from managers.sql_filter_extractor import extract_predicates
            from managers.iceberg_supplement_reader import IcebergSupplementReader
            from managers.iceberg_file_pruner import prune_files
        except ImportError as exc:
            self.logger.warning(
                f"supplement pruning deps missing ({exc}) — falling "
                f"back to standard iceberg path"
            )
            return None

        try:
            import pyiceberg.catalog as _pc  # noqa: F401
        except ImportError:
            self.logger.warning(
                "pyiceberg not installed — supplement pruning needs "
                "manifest reads; falling back to standard iceberg path"
            )
            return None

        query = self._parameterize_query(config["query"], config)
        predicates = extract_predicates(query)
        if not predicates:
            self.logger.info(
                "WHERE has no extractable predicates — supplement "
                "pruning would be a no-op; using standard path"
            )
            return None

        # Resolve snapshot + manifest + reject delete-files /
        # transforms.  This block is the one that goes deepest into
        # pyiceberg territory; failures here log and fall back rather
        # than raising — supplement pruning is OPT-IN, mustn't break
        # a working baseline.
        try:
            scan_info = self._scan_iceberg_for_pruning(
                config, full_table, snapshot_id, as_of_ts_ms,
            )
        except Exception as exc:
            self.logger.warning(
                f"supplement-pruning scan failed ({exc}) — falling "
                f"back to standard iceberg path"
            )
            return None
        if scan_info is None:
            return None  # _scan_iceberg_for_pruning already logged

        files, manifest_bounds, snap_id_str = scan_info

        # Supplement lookup keyed on bucket + table_prefix + snapshot.
        supp_reader = IcebergSupplementReader(
            connection_string=qs_db,
            bucket=config.get("s3_bucket", ""),
            table_prefix=config.get("table_prefix") or self._infer_prefix_from_table(full_table),
            snapshot_id=snap_id_str,
        )
        supplement_bounds: Dict[str, Dict[str, Any]] = {}
        for col in predicates:
            supplement_bounds[col] = supp_reader.bounds_for(col)

        pruned_files = prune_files(
            files, manifest_bounds, supplement_bounds, predicates,
        )
        kept = len(pruned_files)
        total = len(files)
        self.logger.info(
            f"supplement pruning: kept {kept}/{total} files "
            f"({total - kept} pruned)"
        )

        if not pruned_files:
            # Empty result — return an empty DF with the table's schema
            # so downstream count() / spark.sql() don't crash.  Use the
            # standard reader with a 0-row predicate so Iceberg's
            # delete-file / transform handling stays intact for the
            # schema source.
            return spark.read.format("iceberg").load(full_table).limit(0)
        return spark.read.parquet(*pruned_files)

    def _scan_iceberg_for_pruning(
        self, config: Dict, full_table: str,
        snapshot_id: Any, as_of_ts_ms: Any,
    ):
        """Resolve the snapshot's data files + manifest bounds via
        pyiceberg.  Returns ``(file_paths, manifest_bounds, snapshot_id_str)``
        or ``None`` when the table has unsupported features (delete
        files / partition transforms).

        Raises only on infrastructural failure (pyiceberg can't
        connect to the catalog); semantic refusals return None +
        log.
        """
        from pyiceberg.catalog import load_catalog
        from pyiceberg.transforms import IdentityTransform

        catalog_name = config.get("iceberg_catalog_name", "iceberg_catalog")
        catalog_props = self._build_pyiceberg_catalog_props(config)
        catalog = load_catalog(catalog_name, **catalog_props)

        # Strip the catalog prefix from full_table — pyiceberg's
        # ``load_table`` expects ``db.tbl``, not ``catalog.db.tbl``.
        if full_table.startswith(catalog_name + "."):
            tbl_ident = full_table[len(catalog_name) + 1:]
        else:
            tbl_ident = full_table
        tbl = catalog.load_table(tbl_ident)

        # Refuse partition transforms — the pruned path can't apply
        # them.  Identity transforms are fine (they're just direct
        # column references).
        spec = tbl.spec()
        for field in spec.fields:
            if not isinstance(field.transform, IdentityTransform):
                self.logger.info(
                    f"supplement pruning refused: partition transform "
                    f"{field.transform!r} on column "
                    f"{field.source_id} is not Identity — falling back"
                )
                return None

        # Resolve the snapshot we want.
        if snapshot_id is not None:
            snap = tbl.snapshot_by_id(int(snapshot_id))
        elif as_of_ts_ms is not None:
            snap = tbl.snapshot_as_of_timestamp(int(as_of_ts_ms))
        else:
            snap = tbl.current_snapshot()
        if snap is None:
            self.logger.info(
                "supplement pruning refused: no snapshot resolved "
                "(empty table?) — falling back"
            )
            return None
        snap_id_str = str(snap.snapshot_id)

        # Walk data files.  Refuse if any have delete files attached
        # — the pruned path can't apply deletes.
        files: List[str] = []
        manifest_bounds: Dict[str, Dict[str, Any]] = {}
        for task in tbl.scan(snapshot_id=snap.snapshot_id).plan_files():
            df = task.file
            if getattr(task, "delete_files", None):
                self.logger.info(
                    "supplement pruning refused: snapshot has delete "
                    "files — falling back"
                )
                return None
            files.append(df.file_path)
            for col_id, lower in (df.lower_bounds or {}).items():
                col_name = self._field_id_to_name(tbl, col_id)
                if col_name is None:
                    continue
                upper = (df.upper_bounds or {}).get(col_id)
                manifest_bounds.setdefault(col_name.lower(), {})[df.file_path] = (
                    self._bytes_to_str(lower),
                    self._bytes_to_str(upper),
                    df.null_value_counts.get(col_id, 0) if df.null_value_counts else 0,
                    df.record_count or 0,
                )
        return files, manifest_bounds, snap_id_str

    @staticmethod
    def _build_pyiceberg_catalog_props(config: Dict) -> Dict[str, Any]:
        """Convert ETL config's iceberg_* keys to pyiceberg's catalog
        properties dict.  Mirrors what _configure_iceberg_catalog
        passes to Spark, but in pyiceberg's vocabulary.
        """
        catalog_type = (config.get("iceberg_catalog_type") or "rest").lower()
        props: Dict[str, Any] = {"type": catalog_type}
        if catalog_type in ("rest", "hive"):
            props["uri"] = config.get("iceberg_catalog_uri", "")
        if config.get("iceberg_warehouse"):
            props["warehouse"] = config["iceberg_warehouse"]
        # S3A creds for the catalog's FileIO.
        if config.get("s3_access_key"):
            props["s3.access-key-id"] = config["s3_access_key"]
        if config.get("s3_secret_key"):
            props["s3.secret-access-key"] = config["s3_secret_key"]
        if config.get("s3_endpoint_url"):
            props["s3.endpoint"] = config["s3_endpoint_url"]
        return props

    @staticmethod
    def _field_id_to_name(tbl, col_id: int) -> Optional[str]:
        """Resolve a pyiceberg field id to its column name."""
        try:
            return tbl.schema().find_column_name(col_id)
        except Exception:
            return None

    @staticmethod
    def _bytes_to_str(b) -> Optional[str]:
        """Decode pyiceberg's bytes bound to a Python string.
        Numeric bounds come back as variable-length big-endian bytes
        — we let pyiceberg decode them upstream when possible, and
        fall back to repr() on unknown types here."""
        if b is None:
            return None
        if isinstance(b, bytes):
            try:
                return b.decode("utf-8")
            except UnicodeDecodeError:
                return b.hex()
        return str(b)

    @staticmethod
    def _infer_prefix_from_table(full_table: str) -> str:
        """When ``table_prefix`` isn't set in config, derive a
        best-effort prefix from the table FQN — fine for matching
        the supplement's keyed entries because QS writes the same
        prefix.  Falls back to the bare table name.
        """
        parts = full_table.split(".")
        return parts[-1] if parts else full_table

    # ── File sink ──────────────────────────────────────────────────────

    # Suffix used for the per-format Spark "part" files Spark drops
    # into its output directory.  We use the same naming Spark uses so
    # the move + cleanup logic finds the file without globbing.
    _SPARK_PART_GLOBS = {
        "csv":     "part-*.csv",
        "parquet": "part-*.parquet",
        "json":    "part-*.json",
    }

    def _write_to_file(
        self, df, config: Dict, task: Dict,
    ) -> Tuple[str, float]:
        """Write the DataFrame to a SINGLE local NFS file.

        Returns ``(resolved_output_path, write_time_seconds)``.

        Config keys honoured:
          * ``output_format``  — csv (default) | parquet | json
          * ``output_path``    — destination file (supports placeholders).
                                  MUST be a file path, not a directory —
                                  Spark's native ``write.csv(path)``
                                  produces ``path/`` as a directory of
                                  part files; we explicitly land a
                                  single file at this path so downstream
                                  consumers (CompressFiles / CreateCTLFile /
                                  DeliverFiles) can read it directly.
          * ``num_partitions`` — Spark output partitions (default 1
                                  so the consumer sees a single file
                                  per run).  Values > 1 are rejected —
                                  the file sink consolidates to one
                                  file by contract; use a downstream
                                  consolidator if you need partitioned
                                  output.
          * ``write_mode``     — overwrite (default) | append
          * ``header``         — bool, csv only (default True)
          * ``delimiter``      — csv only (default ',')
        """
        output_path_raw = config.get("output_path")
        if not output_path_raw:
            raise ValueError(
                "output_path is required for file-sink steps"
            )
        output_path = self._parameterize_query(output_path_raw, task)
        fmt = (config.get("output_format") or "csv").lower().strip()
        if fmt not in ("csv", "parquet", "json"):
            raise ValueError(
                f"output_format must be csv|parquet|json, got {fmt!r}"
            )
        write_mode = (config.get("write_mode") or "overwrite").lower().strip()
        num_partitions = int(config.get("num_partitions", 1))
        if num_partitions != 1:
            raise ValueError(
                f"num_partitions must be 1 for s3_query file-sink steps "
                f"(the sink consolidates to a single file by contract); "
                f"got {num_partitions}.  Use a downstream consolidator "
                f"step if you need partitioned output."
            )

        parent = os.path.dirname(output_path)
        if parent:
            os.makedirs(parent, exist_ok=True)

        # Spark writes a DIRECTORY of part files, not a single file.
        # Write to a staging directory next to the requested output,
        # then move the lone part file to ``output_path``.  Done this
        # way (vs ``write.option('path', tempdir)`` then rename) so a
        # crash mid-write doesn't leave a half-written ``output_path``.
        staging_dir = output_path + ".__staging__"
        if os.path.exists(staging_dir):
            import shutil as _shutil
            _shutil.rmtree(staging_dir, ignore_errors=True)

        self.logger.info(
            f"Writing {fmt} to {output_path} "
            f"(mode={write_mode}, staging={staging_dir})"
        )
        write_start = datetime.now()
        out = df.coalesce(1)
        writer = out.write.mode(write_mode)
        if fmt == "csv":
            writer = (
                writer
                .option("header", str(config.get("header", True)).lower())
                .option("sep", config.get("delimiter", ","))
            )
            writer.csv(staging_dir)
        elif fmt == "parquet":
            writer.parquet(staging_dir)
        else:
            writer.json(staging_dir)
        write_time = (datetime.now() - write_start).total_seconds()

        # Move the single part file out of staging into ``output_path``.
        self._materialise_single_part_file(staging_dir, output_path, fmt)
        self.logger.info(
            f"Wrote file in {write_time:.2f}s "
            f"(materialised single file at {output_path})"
        )
        return output_path, write_time

    @staticmethod
    def _materialise_single_part_file(
        staging_dir: str, output_path: str, fmt: str,
    ) -> None:
        """Move the lone ``part-*.{fmt}`` file out of ``staging_dir`` to
        ``output_path`` and remove the staging directory.

        Raises if Spark wrote zero or multiple part files (shouldn't
        happen with ``coalesce(1)`` but we'd rather fail loudly than
        produce a half-extracted result).
        """
        import glob as _glob
        import shutil as _shutil

        if not os.path.isdir(staging_dir):
            raise RuntimeError(
                f"Spark output staging directory {staging_dir} does not "
                f"exist — write step did not produce output"
            )
        pattern = os.path.join(staging_dir, S3QueryBase._SPARK_PART_GLOBS[fmt])
        part_files = _glob.glob(pattern)
        if not part_files:
            raise RuntimeError(
                f"No {fmt} part file in {staging_dir} — Spark wrote "
                f"nothing or wrote a different format than requested"
            )
        if len(part_files) > 1:
            raise RuntimeError(
                f"Multiple part files in {staging_dir} ({len(part_files)}) "
                f"— expected exactly one (coalesce(1) failed?)"
            )
        # Atomic rename when source + destination are on the same
        # filesystem (typical for NFS scratch dirs).  Pre-clear the
        # destination if a stale leftover sits there — handle BOTH
        # file and directory leftovers (a previous run that crashed
        # mid-write might have left ``output_path`` as a half-written
        # directory; ``os.remove`` would raise IsADirectoryError).
        if os.path.exists(output_path):
            if os.path.isdir(output_path):
                _shutil.rmtree(output_path)
            else:
                os.remove(output_path)
        _shutil.move(part_files[0], output_path)
        # Clean up the staging directory + its sidecar files (_SUCCESS
        # marker, .crc checksums).
        _shutil.rmtree(staging_dir, ignore_errors=True)

    @staticmethod
    def _set_delivery_chain_aliases(task: Dict, output_path: str) -> None:
        """Set every task-dict key the existing delivery steps look
        for so the s3_query Extract step can chain into ANY of them
        without contract-mismatch glue:

          * ``output_file``        — the s3_query Extract step's own key
          * ``consolidated_file``  — read by CompressFiles + CreateCTLFile
                                     so an Extract → Compress → CTL chain
                                     skips the unnecessary ConsolidateFiles
                                     (Spark already wrote a single file)
          * ``downloaded_files``   — read by ConsolidateFiles, so users
                                     who insist on a 5-step pipeline
                                     (Extract → Consolidate → Compress →
                                     CTL → Deliver) don't crash; the
                                     single-file consolidation is a
                                     no-op pass-through
        """
        task["output_file"]       = output_path
        task["consolidated_file"] = output_path
        task["downloaded_files"]  = [output_path]
