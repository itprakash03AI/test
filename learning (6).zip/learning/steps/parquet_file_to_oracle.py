"""
Parquet File → Oracle step.
Reads parquet files from local/NFS path and writes to Oracle via JDBC.
Supports glob patterns for multiple files.
"""
from typing import Dict, Any
from steps.s3_base_step import S3BaseStep


class ParquetFileToOracle(S3BaseStep):
    """Read parquet from local/NFS file path and write to Oracle via JDBC."""

    LOG_PREFIX = "parquet_file_to_oracle"

    REQUIRED_FIELDS = [
        'oracle_url', 'oracle_user', 'oracle_password',
        'file_path',
    ]

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str, *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        oracle_table = self._get_dest_table(task, config)
        file_path = config['file_path']
        num_partitions = config.get('num_partitions', 10)
        batch_size = config.get('batch_size', 50000)
        merge_schema = config.get('merge_schema', False)

        spark = None
        try:
            spark = self._build_spark_session_s3(task, config)

            self.logger.info(f"Reading parquet from {file_path}")
            reader = spark.read
            if merge_schema:
                reader = reader.option("mergeSchema", "true")
            df = reader.parquet(file_path)

            total_rows = df.count()
            self.logger.info(f"Read {total_rows} rows from parquet")
            task['totalcount'] = total_rows

            # Write to Oracle via shared base method
            write_time = self._write_to_oracle(df, config, oracle_table, batch_size, num_partitions)

            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"), task.get("run_detail_id"),
                'UPDATE_TASK_RECORDCOUNT', step_name,
                total_rows, "", worker_connection_string
            )
            return total_rows

        except Exception as e:
            self.logger.error(f"JOB FAILED: {e}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    spark.stop()
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
