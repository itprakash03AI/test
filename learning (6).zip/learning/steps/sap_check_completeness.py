"""SAP-flow check-completeness step.

ONE responsibility -- final pipeline-level reconcile:

    consolidated row count  ==  full $count  (pre-flight, no filter)

Per-group completeness is owned by ``SapOdataDownload`` (count -> stream
-> reconcile WITH RETRY) so a mismatch retries the group, not the
pipeline.  By the time we run here, every group has already proven its
actual == its $count, Consolidate has merged them, and the only thing
left to verify is that the merged total still equals what SAP told us
on the pre-flight count.

If THAT fails, the rows were lost between download and consolidation
(CSV parsing bug, embedded-newline row, column-mapping that dropped a
key column).  Halt before CTL / delivery.

Also enforces output-file existence + non-emptiness so a downstream
delivery step never ships a missing or 0-byte payload.

Knobs (JSON config or polling row, all optional):
  * ``min_record_count``     -- minimum acceptable row count (default 1).
                               0 means "any count, including empty, is OK".
  * ``max_record_count``     -- optional upper bound (catches runaway
                               extracts from misconfigured filters).
  * ``require_output_file``  -- bool, default True.  Validate the
                               compressed/consolidated file exists
                               and is non-empty.
  * ``allow_count_mismatch`` -- bypass the full-count reconcile when an
                               operator decides a known small gap is OK.
"""
import os
from typing import Dict, List

from steps.sap_odata_base import SapOdataBase


class SapCheckCompleteness(SapOdataBase):
    """Final gate before CTL emission + delivery."""

    LOG_PREFIX = "sap_check_completeness"

    REQUIRED_FIELDS: List[str] = []

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)
        self._hydrate_from_sidecar(task, config)

        totalcount = self._coerce_total(task)
        self._enforce_bounds(totalcount, config)

        # -- THE one check this step owns ---------------------------
        # Downloaded data (consolidated rows) must equal the full
        # period $count SAP told us before we started.  Per-group
        # reconcile is the download step's job; we only verify the
        # AGGREGATE survived consolidation intact.
        full_count = self._coerce_full_count(task)
        self._reconcile_total_vs_full(totalcount, full_count, config)

        # File-existence / non-empty guard.  Cheap, catches "Consolidate
        # said N rows but didn't actually write the file" pathologies.
        output_file = self._verify_output_file(task, totalcount, config)

        self._log_final_ledger(
            full_count=full_count,
            totalcount=totalcount,
            output_file=output_file,
        )
        return totalcount

    # -- Helpers -----------------------------------------------------

    def _coerce_total(self, task: Dict) -> int:
        totalcount = task.get('totalcount')
        if totalcount is None:
            raise ValueError(
                "SapCheckCompleteness: task['totalcount'] is unset -- "
                "Download / Consolidate did not record a row count.  "
                "Cannot certify completeness."
            )
        try:
            return int(totalcount)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"SapCheckCompleteness: task['totalcount'] "
                f"{totalcount!r} is not an integer ({exc})."
            )

    def _coerce_full_count(self, task: Dict):
        """Return int or None.  None means Download didn't stash a
        pre-flight count -- we skip the reconcile but log a WARN."""
        full_count = task.get('full_count')
        if full_count is None:
            self.logger.warning(
                "SapCheckCompleteness: task['full_count'] is unset -- "
                "Download didn't record a pre-flight $count.  Total-vs-"
                "full reconcile SKIPPED (only bounds + file check enforced)."
            )
            return None
        try:
            return int(full_count)
        except (TypeError, ValueError):
            self.logger.warning(
                "SapCheckCompleteness: full_count %r is not an int -- "
                "reconcile skipped", full_count,
            )
            return None

    def _enforce_bounds(self, totalcount: int, config: Dict) -> None:
        min_count = int(config.get('min_record_count', 1))
        max_count = config.get('max_record_count')
        if totalcount < min_count:
            raise ValueError(
                f"SapCheckCompleteness: row count {totalcount:,} is below "
                f"the configured minimum ({min_count:,}).  Halting before "
                f"CTL / delivery so partial data does not leave the pod."
            )
        if max_count is not None and totalcount > int(max_count):
            raise ValueError(
                f"SapCheckCompleteness: row count {totalcount:,} exceeds "
                f"the configured maximum ({max_count}).  Likely a "
                f"misconfigured filter producing a runaway extract."
            )

    def _reconcile_total_vs_full(
        self, totalcount: int, full_count, config: Dict,
    ) -> None:
        if full_count is None:
            return  # skipped -- already logged
        if totalcount == full_count:
            self.logger.info(
                "SapCheckCompleteness OK: consolidated %d == full $count %d",
                totalcount, full_count,
            )
            return
        delta = totalcount - full_count
        msg = (
            f"SapCheckCompleteness: consolidated rows {totalcount:,} != "
            f"full $count {full_count:,} (delta {delta:+,}).  Rows were "
            f"lost or duplicated between download (per-group reconcile "
            f"already PASSED in SapOdataDownload) and consolidation.  "
            f"Investigate Consolidate's CSV parsing / column-mapping "
            f"config."
        )
        if not bool(config.get('allow_count_mismatch', False)):
            raise ValueError(msg)
        self.logger.warning(
            msg + " -- proceeding per allow_count_mismatch=true"
        )

    def _verify_output_file(
        self, task: Dict, totalcount: int, config: Dict,
    ) -> str:
        require_file = bool(config.get('require_output_file', True))
        output_file = (
            task.get('compressed_file')
            or task.get('consolidated_file')
            or ''
        )
        if not require_file:
            return output_file
        if not output_file:
            raise ValueError(
                "SapCheckCompleteness: no compressed_file / "
                "consolidated_file in task dict -- Consolidate or "
                "Compress step did not record an output path."
            )
        if not os.path.exists(output_file):
            raise ValueError(
                f"SapCheckCompleteness: output file {output_file!r} "
                f"does not exist on disk."
            )
        if os.path.getsize(output_file) == 0:
            raise ValueError(
                f"SapCheckCompleteness: output file {output_file!r} is "
                f"empty (0 bytes) even though totalcount={totalcount:,}."
            )
        return output_file

    def _log_final_ledger(
        self, *, full_count, totalcount: int, output_file: str,
    ) -> None:
        """End-of-pipeline summary.  ONE visible block per run that
        encodes the final verdict -- operator opens the log, scrolls to
        the bottom, sees the certification at a glance."""
        self.logger.info("=" * 72)
        self.logger.info("SAP completeness ledger -- FINAL (pre-delivery)")
        self.logger.info("=" * 72)
        if full_count is not None:
            ok = totalcount == full_count
            verdict = "[OK]" if ok else f"[FAIL] delta {totalcount - full_count:+,}"
            self.logger.info("  full $count (pre-flight)  : %d", full_count)
            self.logger.info("  consolidated row count    : %d  %s",
                              totalcount, verdict)
        else:
            self.logger.info(
                "  full $count               : <not recorded by download>"
            )
            self.logger.info(
                "  consolidated row count    : %d  [unverified]",
                totalcount,
            )
        if output_file and os.path.exists(output_file):
            size = os.path.getsize(output_file)
            self.logger.info(
                "  output file on disk       : %s (%d bytes)",
                output_file, size,
            )
        self.logger.info("=" * 72)
