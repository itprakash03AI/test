"""SAP-flow compress-files step.

Self-contained -- no inheritance from the generic ``CompressFiles``.
Inherits only from ``SapOdataBase`` for the SAP-specific config loader
+ logger setup.

GZips the consolidated CSV (streaming, 64 MB chunks) and computes the
MD5 checksum the SAP CTL contract requires.  FIPS-strict hosts refuse
``hashlib.md5()`` without ``usedforsecurity=False`` -- the kwarg makes
this work on Python 3.9+ while staying compatible with earlier Pythons.
"""
import gzip
import hashlib
import os
from typing import Dict, List

from steps.sap_odata_base import SapOdataBase


class SapCompressFiles(SapOdataBase):
    """GZip the SAP consolidated CSV + compute MD5 for the CTL file."""

    LOG_PREFIX = "sap_compress_files"

    REQUIRED_FIELDS: List[str] = []

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)
        self._hydrate_from_sidecar(task, config)

        source_file = task.get('consolidated_file', '')
        if not source_file or not os.path.exists(source_file):
            raise ValueError(
                f"Consolidated file not found: {source_file!r} -- "
                f"SapConsolidateFiles must run first AND its sidecar "
                f"must point at the consolidated file."
            )

        gzip_level = config.get('gzip_level', 6)
        chunk_size = config.get('gzip_chunk_size', 64 * 1024 * 1024)
        delete_source = config.get('delete_uncompressed', True)

        gz_path = f"{source_file}.gz"
        self.logger.info(
            f"Compressing {source_file} -> {gz_path} (level={gzip_level})"
        )

        # FIPS-safe MD5 -- the CTL checksum is integrity, not crypto.
        try:
            md5_hash = hashlib.md5(usedforsecurity=False)
        except TypeError:  # pragma: no cover -- Py < 3.9
            md5_hash = hashlib.md5()
        source_size = os.path.getsize(source_file)

        with open(source_file, 'rb') as f_in:
            with gzip.open(gz_path, 'wb', compresslevel=gzip_level) as f_out:
                while True:
                    chunk = f_in.read(chunk_size)
                    if not chunk:
                        break
                    md5_hash.update(chunk)
                    f_out.write(chunk)

        compressed_size = os.path.getsize(gz_path)
        checksum = md5_hash.hexdigest()
        ratio = (1 - compressed_size / source_size) * 100 if source_size > 0 else 0

        self.logger.info(
            f"Compression complete: {source_size:,} -> {compressed_size:,} bytes "
            f"({ratio:.1f}% reduction), MD5={checksum}"
        )

        task['compressed_file'] = gz_path
        task['checksum'] = checksum
        task['compressed_size'] = compressed_size
        task['uncompressed_size'] = source_size

        # Persist compress state to sidecar for CTL / Deliver /
        # CheckCompleteness on their separate task dicts.
        self._save_sidecar(task, config)

        if delete_source:
            os.remove(source_file)
            self.logger.info(f"Deleted uncompressed file: {source_file}")

        return task.get('totalcount', 0)
