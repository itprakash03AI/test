"""SAP OData run-state sidecar.

Each polling row in the SAP workflow is dispatched to a separate step
class with its OWN task dict.  Without a shared persistence mechanism,
state that SapOdataDownload stashes on ``task['downloaded_files']``,
``task['full_count']`` etc. is INVISIBLE to SapConsolidateFiles --
its task dict comes from a different polling row.

Sidecar pattern: every step that runs for a given ``RUN_ID`` reads from
+ writes to a shared JSON file under the base output_dir:

    <base_output_dir>/_sap_state_<run_id>.json

Download writes it at the start (so consolidate-resume works even if
download crashes mid-way) AND on every successful group completion +
on success.  Consolidate / Compress / CTL / Deliver / CheckCompleteness
hydrate from it on entry, before any task-dict-only check fires.

Atomic write (``.tmp`` + ``os.replace``) so a crash mid-write leaves
the OLD state intact -- same contract the per-group checkpoint uses.
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional


def state_path(base_output_dir: str, run_id: Any) -> str:
    """Path of the sidecar state file for a given run_id.

    ``run_id`` is coerced to str so an Oracle NUMBER doesn't produce
    a weird ``_sap_state_42.0.json`` filename.
    """
    safe_run = str(run_id).strip().replace(os.sep, "_").replace("/", "_")
    return os.path.join(base_output_dir, f"_sap_state_{safe_run}.json")


def save_state(
    state: Dict[str, Any], base_output_dir: str, run_id: Any,
    logger=None,
) -> Optional[str]:
    """Atomically persist ``state`` to the sidecar.

    Returns the file path on success or None on failure (never raises --
    sidecar is a debugging / handoff aid, not a critical path).
    """
    if run_id is None:
        if logger:
            logger.warning(
                "save_state: run_id is None -- skipping sidecar persist"
            )
        return None
    try:
        os.makedirs(base_output_dir, exist_ok=True)
    except OSError as exc:
        if logger:
            logger.warning(
                "save_state: could not create %s: %s", base_output_dir, exc,
            )
        return None

    target = state_path(base_output_dir, run_id)
    tmp = target + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2, default=str)
            try:
                f.flush()
                os.fsync(f.fileno())
            except (AttributeError, OSError):
                pass
        os.replace(tmp, target)
        if logger:
            logger.info(
                "Persisted run-state sidecar to %s "
                "(downloaded_files=%d, totalcount=%s)",
                target,
                len(state.get("downloaded_files", []) or []),
                state.get("totalcount"),
            )
        return target
    except OSError as exc:
        if logger:
            logger.warning(
                "save_state: write to %s failed: %s", target, exc,
            )
        # Best-effort cleanup of the tmp file
        try:
            os.remove(tmp)
        except OSError:
            pass
        return None


def load_state(
    base_output_dir: str, run_id: Any, logger=None,
) -> Optional[Dict[str, Any]]:
    """Load the sidecar; return None on missing / corrupt."""
    if run_id is None or not base_output_dir:
        return None
    path = state_path(base_output_dir, run_id)
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None
        return data
    except (json.JSONDecodeError, OSError) as exc:
        if logger:
            logger.warning(
                "load_state: %s unreadable (%s) -- treating as missing",
                path, exc,
            )
        return None
