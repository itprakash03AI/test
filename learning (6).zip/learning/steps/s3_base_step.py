"""
Shared base class for S3/Iceberg Spark steps.
Provides S3A configuration, Iceberg catalog setup, presigned URL fallback,
and common Spark session building with S3/Iceberg extensions.
"""
import os
import json
import logging
import sys
import tempfile
from datetime import datetime
from typing import Dict, Any, List, Optional

from pyspark.sql import SparkSession
from steps.BaseStep import BaseStep


class S3BaseStep(BaseStep):
    """Base class for S3/Iceberg steps with shared S3 config and Spark setup."""

    LOG_PREFIX: str = "s3_step"

    def _load_and_validate_config(self, task: Dict, required_fields: List[str]) -> Dict:
        """Load JSON config and validate required fields."""
        config_path = task.get('sql_query_path')
        if not config_path:
            raise ValueError("Task missing 'sql_query_path'")

        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Config file not found: {config_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in config {config_path}: {e}")

        missing = [f for f in required_fields if f not in config]
        if missing:
            raise ValueError(f"Missing required config fields: {missing}")

        return config

    def _setup_logging(self, task: Dict) -> None:
        """Configure a named logger for this step.

        Uses shared pipeline log file from ``task['log_file']`` so all
        steps write to a single file.  Falls back to a per-step file.
        """
        self.logger = logging.getLogger(f"etl.{self.LOG_PREFIX}")

        # Avoid adding duplicate handlers if called again
        if self.logger.handlers:
            return

        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        self.logger.addHandler(sh)

        # Prefer shared pipeline log file; fall back to per-step file.
        # Log dir resolved via log_config.get_log_dir() — ETL_LOG_DIR
        # env var wins, then polling YAML, then legacy PVC path.
        log_path = task.get('log_file')
        if not log_path:
            run_id = task.get('run_id', 'unknown')
            date_str = datetime.now().strftime('%Y-%m-%d')
            try:
                from log_config import get_log_dir as _resolve_log_dir
                _ld = _resolve_log_dir()
            except Exception:
                _ld = "/usr/local/spark/nfs/bcp/batch/logs"
            log_path = os.path.join(
                _ld, f"etl_{self.LOG_PREFIX}_{run_id}_{date_str}.log",
            )

        try:
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            fh = logging.FileHandler(log_path)
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except OSError as e:
            self.logger.warning(f"Cannot create log file {log_path}: {e} — console only")

    def _build_spark_session_s3(self, task: Dict, config: Dict, with_iceberg: bool = False) -> SparkSession:
        """Build SparkSession with S3A and optional Iceberg support."""
        run_id = task.get('run_id', 'unknown')
        run_detail_id = task.get('run_detail_id', 'unknown')
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')

        executor_memory = config.get('spark_executor_memory', '10g')
        driver_memory = config.get('spark_driver_memory', '3g')
        num_partitions = config.get('num_partitions', 10)
        spark_jars = config.get('spark_jars', '')

        try:
            from log_config import get_log_dir as _resolve_log_dir
            _evt_root = _resolve_log_dir()
        except Exception:
            _evt_root = "/usr/local/spark/nfs/bcp/batch/logs"
        event_log_dir = os.path.join(
            _evt_root, "event-logs",
            f"{run_id}_{run_detail_id}_{timestamp}",
        )
        os.makedirs(event_log_dir, exist_ok=True)

        builder = (
            SparkSession.builder
            .appName(f"{self.LOG_PREFIX}_{run_id}-{run_detail_id}")
            .config("spark.executor.cores", "1")
            .config("spark.kubernetes.executor.request.cores", "300m")
            .config("spark.kubernetes.executor.limit.cores", "1")
            .config("spark.executor.memory", executor_memory)
            .config("spark.driver.memory", driver_memory)
            .config("spark.executor.memoryOverhead", config.get('spark_executor_memory_overhead', '1g'))
            .config("spark.driver.memoryOverhead", config.get('spark_driver_memory_overhead', '1g'))
            .config("spark.executor.instances", "1")
            .config("spark.sql.shuffle.partitions", str(num_partitions))
            .config("spark.sql.execution.arrow.pyspark.enabled", "true")
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.dynamicAllocation.enabled", "false")
            .config("spark.eventLog.enabled", "true")
            .config("spark.eventLog.dir", event_log_dir)
        )

        if spark_jars:
            builder = builder.config("spark.jars", spark_jars)

        # S3A configuration
        builder = self._configure_s3a(builder, config)

        # Iceberg configuration (optional)
        if with_iceberg:
            builder = self._configure_iceberg_catalog(builder, config)

        return builder.getOrCreate()

    def _configure_s3a(self, builder, config: Dict):
        """Configure Spark S3A FileSystem for AWS or on-prem S3."""
        access_key = config.get('s3_access_key', '')
        secret_key = config.get('s3_secret_key', '')
        endpoint = config.get('s3_endpoint_url', '')
        path_style = config.get('s3_path_style_access', False)

        builder = (
            builder
            .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
            .config("spark.hadoop.fs.s3a.access.key", access_key)
            .config("spark.hadoop.fs.s3a.secret.key", secret_key)
        )

        if endpoint:
            # On-prem S3 (Dell ECS, MinIO, etc.)
            builder = (
                builder
                .config("spark.hadoop.fs.s3a.endpoint", endpoint)
                .config("spark.hadoop.fs.s3a.path.style.access", str(path_style).lower())
                .config("spark.hadoop.fs.s3a.connection.ssl.enabled",
                         str(config.get('s3_ssl_enabled', True)).lower())
            )

        return builder

    def _configure_iceberg_catalog(self, builder, config: Dict):
        """Configure Iceberg catalog (REST, Glue, or Hive)."""
        catalog_type = config.get('iceberg_catalog_type', 'rest')
        catalog_name = config.get('iceberg_catalog_name', 'iceberg_catalog')

        builder = (
            builder
            .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
            .config(f"spark.sql.catalog.{catalog_name}", "org.apache.iceberg.spark.SparkCatalog")
        )

        if catalog_type == 'rest':
            builder = (
                builder
                .config(f"spark.sql.catalog.{catalog_name}.type", "rest")
                .config(f"spark.sql.catalog.{catalog_name}.uri",
                         config.get('iceberg_catalog_uri', 'http://localhost:8181'))
            )
        elif catalog_type == 'glue':
            builder = (
                builder
                .config(f"spark.sql.catalog.{catalog_name}.catalog-impl",
                         "org.apache.iceberg.aws.glue.GlueCatalog")
            )
        elif catalog_type == 'hive':
            builder = (
                builder
                .config(f"spark.sql.catalog.{catalog_name}.type", "hive")
                .config(f"spark.sql.catalog.{catalog_name}.uri",
                         config.get('iceberg_catalog_uri', ''))
            )

        warehouse = config.get('iceberg_warehouse', '')
        if warehouse:
            builder = builder.config(f"spark.sql.catalog.{catalog_name}.warehouse", warehouse)

        return builder

    def _presigned_fallback(self, config: Dict, s3_paths: List[str]) -> List[str]:
        """Download S3 files via boto3 presigned URLs to local temp (on-prem fallback)."""
        import boto3

        s3_client = boto3.client(
            's3',
            endpoint_url=config.get('s3_endpoint_url', None),
            aws_access_key_id=config.get('s3_access_key', ''),
            aws_secret_access_key=config.get('s3_secret_key', ''),
        )

        local_paths = []
        temp_dir = tempfile.mkdtemp(prefix="s3_download_")

        for s3_path in s3_paths:
            # Parse s3://bucket/key
            path = s3_path.replace("s3://", "").replace("s3a://", "")
            bucket = path.split("/")[0]
            key = "/".join(path.split("/")[1:])

            local_file = os.path.join(temp_dir, os.path.basename(key))
            self.logger.info(f"Downloading {s3_path} → {local_file}")

            response = s3_client.get_object(Bucket=bucket, Key=key)
            with open(local_file, 'wb') as f:
                for chunk in response['Body'].iter_chunks(chunk_size=8 * 1024 * 1024):
                    f.write(chunk)

            local_paths.append(local_file)

        return local_paths

    def _parameterize_query(self, query: str, task: Dict) -> str:
        """Replace template variables in SQL query."""
        replacements = {
            "{BUSINESSDATE}": task.get('business_date', ''),
            "{SYSTEM_ENTITY}": task.get('system_entity', ''),
            "{EventCode}": task.get('eventcode', ''),
        }
        for placeholder, value in replacements.items():
            query = query.replace(placeholder, value)
        return query

    # ── Shared Oracle JDBC read/write (used by Oracle↔S3 steps) ──────────

    def _read_from_oracle(
        self, spark: SparkSession, config: Dict, query: str, num_partitions: int = 10
    ) -> tuple:
        """Read data from Oracle via JDBC. Returns (df, total_rows, read_time_seconds)."""
        oracle_url = config['oracle_url']
        oracle_user = config['oracle_user']
        oracle_password = config['oracle_password']
        fetchsize = config.get('fetchsize', '50000')

        # COUNT(*) pushdown
        count_query = f"SELECT COUNT(*) AS CNT FROM ({query}) t"
        self.logger.info("Fetching record count from Oracle via COUNT(*) pushdown...")
        cnt_df = (
            spark.read.format("jdbc")
            .option("url", oracle_url)
            .option("dbtable", f"({count_query}) as c")
            .option("user", oracle_user)
            .option("password", oracle_password)
            .option("driver", "oracle.jdbc.OracleDriver")
            .load()
        )
        total_rows = int(cnt_df.collect()[0]["CNT"])
        self.logger.info(f"Record count from Oracle = {total_rows}")

        # Read all data
        self.logger.info("Reading data from Oracle...")
        read_start = datetime.now()
        df = (
            spark.read.format("jdbc")
            .option("url", oracle_url)
            .option("dbtable", f"({query}) as subq")
            .option("user", oracle_user)
            .option("password", oracle_password)
            .option("driver", "oracle.jdbc.OracleDriver")
            .option("fetchsize", str(fetchsize))
            .option("numPartitions", str(num_partitions))
            .load()
        )
        read_time = (datetime.now() - read_start).total_seconds()
        self.logger.info(f"Read {total_rows} rows in {read_time:.2f}s")

        return df, total_rows, read_time

    def _write_to_oracle(
        self, df, config: Dict, table: str,
        batch_size: int = 50000, num_partitions: int = 10
    ) -> float:
        """Write DataFrame to Oracle via JDBC. Returns write_time_seconds."""
        oracle_url = config['oracle_url']
        oracle_user = config['oracle_user']
        oracle_password = config['oracle_password']

        self.logger.info(f"Repartitioning to {num_partitions} and writing to {table}")
        df = df.repartition(num_partitions)

        write_start = datetime.now()
        (
            df.write.format("jdbc")
            .option("url", oracle_url)
            .option("dbtable", table)
            .option("user", oracle_user)
            .option("password", oracle_password)
            .option("driver", "oracle.jdbc.OracleDriver")
            .option("batchsize", str(batch_size))
            .option("isolationLevel", "NONE")
            .option("numPartitions", str(num_partitions))
            .mode("append")
            .save()
        )
        write_time = (datetime.now() - write_start).total_seconds()
        self.logger.info(f"Write to {table} completed in {write_time:.2f}s")
        return write_time

    def _list_s3_files(self, config: Dict, bucket: str, prefix: str) -> List[str]:
        """List S3 parquet files in the given prefix via boto3 paginator."""
        import boto3

        s3_client = boto3.client(
            's3',
            endpoint_url=config.get('s3_endpoint_url', None),
            aws_access_key_id=config.get('s3_access_key', ''),
            aws_secret_access_key=config.get('s3_secret_key', ''),
        )

        files = []
        paginator = s3_client.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get('Contents', []):
                if obj['Key'].endswith('.parquet'):
                    files.append(f"s3://{bucket}/{obj['Key']}")

        self.logger.info(f"Found {len(files)} parquet files in s3://{bucket}/{prefix}")
        return files

    def _get_dest_table(self, task: Dict, config: Dict) -> str:
        """Get destination Oracle table — consistent across all steps."""
        return task.get("dest_table") or config.get("dest_table", "")
