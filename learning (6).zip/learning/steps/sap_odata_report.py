"""SAP OData run report -- HTML + log + email.

ALWAYS written to ``<output_dir>/run_report.html`` regardless of
success/failure, so an operator opening the output dir after a crash
sees the full picture without grepping logs.

Three deliverables, all gated on flags so local dev doesn't accidentally
mail prod:

  * ``run_report.html``  -- always written.  Self-contained, no external
                            CSS/JS, opens in any browser.
  * Start email          -- ``send_email=true`` AND first call (status="START")
  * Finish email         -- ``send_email=true`` AND final call (status="SUCCESS"
                            or "FAILED"); inlines the HTML body.

The report ALSO lives as plain text in ``run_report.txt`` so it grep-s.
"""
from __future__ import annotations

import html
import os
import smtplib
from datetime import datetime, timezone
from email.message import EmailMessage
from typing import Any, Dict, List, Optional


class RunReport:
    """Accumulates run state, renders HTML + text, optionally emails."""

    def __init__(self, *, output_dir: str, logger=None):
        self.output_dir = output_dir
        self.logger = logger
        self.started_at: datetime = datetime.now(timezone.utc)
        self.finished_at: Optional[datetime] = None
        # Free-form context: period, run_id, dag_id, etc.
        self.context: Dict[str, Any] = {}
        # URL inventory
        self.urls: Dict[str, str] = {}
        # Group results
        self.group_results: List[Dict[str, Any]] = []
        # Counts
        self.full_count: Optional[int] = None
        self.sum_expected: Optional[int] = None
        self.sum_actual: Optional[int] = None
        self.consolidated_count: Optional[int] = None
        # Output files
        self.output_files: List[str] = []
        # Status: "START" / "SUCCESS" / "FAILED"
        self.status: str = "START"
        self.error_message: Optional[str] = None
        # Performance/parallelism knobs
        self.runtime_knobs: Dict[str, Any] = {}

    # -- Setters --------------------------------------------------------

    def set_context(self, **kwargs) -> None:
        self.context.update({k: v for k, v in kwargs.items() if v is not None})

    def set_urls(self, **kwargs) -> None:
        self.urls.update({k: v for k, v in kwargs.items() if v is not None})

    def set_runtime_knobs(self, **kwargs) -> None:
        self.runtime_knobs.update(
            {k: v for k, v in kwargs.items() if v is not None}
        )

    def set_counts(
        self,
        full_count: Optional[int] = None,
        sum_expected: Optional[int] = None,
        sum_actual: Optional[int] = None,
        consolidated_count: Optional[int] = None,
    ) -> None:
        if full_count is not None: self.full_count = full_count
        if sum_expected is not None: self.sum_expected = sum_expected
        if sum_actual is not None: self.sum_actual = sum_actual
        if consolidated_count is not None: self.consolidated_count = consolidated_count

    def add_group_result(self, result: Dict[str, Any]) -> None:
        self.group_results.append(result)

    def add_output_file(self, path: str) -> None:
        if path and path not in self.output_files:
            self.output_files.append(path)

    def mark_started(self) -> None:
        self.status = "START"
        self.started_at = datetime.now(timezone.utc)

    def mark_success(self) -> None:
        self.status = "SUCCESS"
        self.finished_at = datetime.now(timezone.utc)

    def mark_failed(self, error_message: str) -> None:
        self.status = "FAILED"
        self.error_message = error_message
        self.finished_at = datetime.now(timezone.utc)

    # -- Render ---------------------------------------------------------

    def _duration_str(self) -> str:
        if self.finished_at is None:
            return "(in progress)"
        delta = self.finished_at - self.started_at
        secs = delta.total_seconds()
        h, rem = divmod(int(secs), 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"

    def to_html(self) -> str:
        e = html.escape
        rows_groups = ""
        for r in sorted(self.group_results, key=lambda x: x.get("group_idx", 0)):
            gi = r.get("group_idx", "?")
            expected = r.get("expected_count")
            actual = r.get("row_count")
            attempts = r.get("attempts", 1)
            file_path = r.get("file_path", "")
            codes = r.get("codes", [])
            verdict = "ok"
            if expected is not None and actual is not None and actual != expected:
                verdict = "fail"
            mn = min(codes) if codes else ""
            mx = max(codes) if codes else ""
            rows_groups += (
                f"<tr class='{verdict}'>"
                f"<td>{e(str(gi))}</td>"
                f"<td>{len(codes)}</td>"
                f"<td>{e(str(mn))} .. {e(str(mx))}</td>"
                f"<td>{expected if expected is not None else '?'}</td>"
                f"<td>{actual if actual is not None else '?'}</td>"
                f"<td>{attempts}</td>"
                f"<td><code>{e(file_path)}</code></td>"
                f"</tr>"
            )

        # Completeness ledger
        def verdict_html(ok: bool, detail: str) -> str:
            cls = "ok" if ok else "fail"
            label = "OK" if ok else "FAIL"
            return f"<td class='{cls}'>{label}</td><td>{e(detail)}</td>"

        ledger_rows = ""
        if self.full_count is not None:
            ledger_rows += (
                f"<tr><td>G1 full $count (pre-flight)</td>"
                f"{verdict_html(True, f'{self.full_count:,}')}</tr>"
            )
        if self.sum_expected is not None and self.full_count is not None:
            ok = self.sum_expected == self.full_count
            ledger_rows += (
                f"<tr><td>G2 Sum(per-group $count) == G1</td>"
                f"{verdict_html(ok, f'{self.sum_expected:,} (delta {self.sum_expected - self.full_count:+,})')}</tr>"
            )
        if self.sum_actual is not None and self.full_count is not None:
            ok = self.sum_actual == self.full_count
            ledger_rows += (
                f"<tr><td>G3 Sum(actual rows) == G1</td>"
                f"{verdict_html(ok, f'{self.sum_actual:,} (delta {self.sum_actual - self.full_count:+,})')}</tr>"
            )
        if self.group_results:
            mism = [
                r for r in self.group_results
                if r.get("expected_count") is not None
                and r["row_count"] != r["expected_count"]
            ]
            ok = not mism
            ledger_rows += (
                f"<tr><td>G4 per-group actual == $count</td>"
                f"{verdict_html(ok, f'{len(self.group_results) - len(mism)} of {len(self.group_results)} groups match')}</tr>"
            )
        if self.consolidated_count is not None and self.full_count is not None:
            ok = self.consolidated_count == self.full_count
            ledger_rows += (
                f"<tr><td>G5 consolidated == G1</td>"
                f"{verdict_html(ok, f'{self.consolidated_count:,}')}</tr>"
            )

        rows_urls = "".join(
            f"<tr><td><b>{e(k)}</b></td><td><code>{e(str(v))}</code></td></tr>"
            for k, v in self.urls.items()
        )
        rows_context = "".join(
            f"<tr><td><b>{e(k)}</b></td><td>{e(str(v))}</td></tr>"
            for k, v in self.context.items()
        )
        rows_knobs = "".join(
            f"<tr><td><b>{e(k)}</b></td><td>{e(str(v))}</td></tr>"
            for k, v in self.runtime_knobs.items()
        )
        rows_files = "".join(
            f"<li><code>{e(p)}</code> ({os.path.getsize(p):,} bytes)</li>"
            if os.path.exists(p)
            else f"<li><code>{e(p)}</code> <em>(missing)</em></li>"
            for p in self.output_files
        )

        status_class = {
            "START": "warn",
            "SUCCESS": "ok",
            "FAILED": "fail",
        }.get(self.status, "warn")

        error_block = ""
        if self.error_message:
            error_block = (
                f"<h2>Error</h2><pre class='fail'>{e(self.error_message)}</pre>"
            )

        return f"""<!DOCTYPE html>
<html><head><meta charset='utf-8'>
<title>SAP OData run -- {e(self.context.get('period', ''))}</title>
<style>
body {{ font-family: -apple-system, Segoe UI, sans-serif; margin: 24px; color: #222; }}
h1 {{ border-bottom: 2px solid #444; padding-bottom: 8px; }}
h2 {{ margin-top: 32px; border-bottom: 1px solid #aaa; padding-bottom: 4px; }}
table {{ border-collapse: collapse; margin: 8px 0; }}
td, th {{ padding: 6px 12px; border: 1px solid #ccc; font-size: 13px; }}
th {{ background: #f0f0f0; text-align: left; }}
code {{ font-family: Consolas, monospace; font-size: 12px; word-break: break-all; }}
.status {{ display: inline-block; padding: 4px 12px; border-radius: 4px;
           font-weight: bold; color: white; }}
.status.ok    {{ background: #2e7d32; }}
.status.warn  {{ background: #f57c00; }}
.status.fail  {{ background: #c62828; }}
td.ok    {{ background: #e8f5e9; color: #2e7d32; font-weight: bold; }}
td.fail  {{ background: #ffebee; color: #c62828; font-weight: bold; }}
tr.fail td {{ background: #fff5f5; }}
pre.fail {{ background: #ffebee; padding: 12px; overflow-x: auto; }}
ul {{ font-family: Consolas, monospace; font-size: 13px; }}
</style></head>
<body>
<h1>SAP OData download run --
   <span class='status {status_class}'>{e(self.status)}</span></h1>
<table>
  <tr><th>Started (UTC)</th><td>{self.started_at.isoformat()}</td></tr>
  <tr><th>Finished (UTC)</th>
      <td>{self.finished_at.isoformat() if self.finished_at else '(in progress)'}</td></tr>
  <tr><th>Duration</th><td>{self._duration_str()}</td></tr>
</table>

<h2>Context</h2>
<table>{rows_context}</table>

<h2>Runtime knobs</h2>
<table>{rows_knobs}</table>

<h2>Completeness ledger</h2>
<table>
  <tr><th>Gate</th><th>Verdict</th><th>Detail</th></tr>
  {ledger_rows}
</table>

<h2>Per-group results</h2>
<table>
  <tr><th>#</th><th>Codes</th><th>Range</th><th>$count expected</th>
      <th>Actual rows</th><th>Attempts</th><th>File</th></tr>
  {rows_groups}
</table>

<h2>URLs</h2>
<table>{rows_urls}</table>

<h2>Output files</h2>
<ul>{rows_files}</ul>

{error_block}
</body></html>"""

    def to_text(self) -> str:
        """Plain-text version -- grep-able, log-paste-friendly."""
        lines = []
        lines.append("=" * 72)
        lines.append(f"SAP OData run -- {self.status}")
        lines.append("=" * 72)
        lines.append(f"Started:  {self.started_at.isoformat()}")
        if self.finished_at:
            lines.append(f"Finished: {self.finished_at.isoformat()}")
            lines.append(f"Duration: {self._duration_str()}")
        lines.append("")
        lines.append("CONTEXT:")
        for k, v in self.context.items():
            lines.append(f"  {k}: {v}")
        lines.append("")
        lines.append("RUNTIME KNOBS:")
        for k, v in self.runtime_knobs.items():
            lines.append(f"  {k}: {v}")
        lines.append("")
        lines.append("URLS:")
        for k, v in self.urls.items():
            lines.append(f"  {k}: {v}")
        lines.append("")
        lines.append("COMPLETENESS:")
        lines.append(f"  full $count          : {self.full_count}")
        lines.append(f"  Sum(per-group count) : {self.sum_expected}")
        lines.append(f"  Sum(actual rows)     : {self.sum_actual}")
        lines.append(f"  consolidated rows    : {self.consolidated_count}")
        lines.append("")
        lines.append("GROUPS:")
        for r in sorted(self.group_results, key=lambda x: x.get("group_idx", 0)):
            lines.append(
                f"  group {r.get('group_idx')}: "
                f"expected={r.get('expected_count')} "
                f"actual={r.get('row_count')} "
                f"attempts={r.get('attempts', 1)} "
                f"-> {r.get('file_path')}"
            )
        lines.append("")
        lines.append("OUTPUT FILES:")
        for p in self.output_files:
            size = os.path.getsize(p) if os.path.exists(p) else "missing"
            lines.append(f"  {p}  ({size} bytes)")
        if self.error_message:
            lines.append("")
            lines.append("ERROR:")
            lines.append(self.error_message)
        return "\n".join(lines)

    # -- Write to disk --------------------------------------------------

    def write(self) -> Dict[str, str]:
        """Write run_report.html + run_report.txt to output_dir.
        Returns the paths.  Errors logged but never raised -- the
        report is a debug aid, not a critical-path artefact."""
        paths: Dict[str, str] = {}
        os.makedirs(self.output_dir, exist_ok=True)
        for ext, content in (("html", self.to_html()),
                              ("txt", self.to_text())):
            path = os.path.join(self.output_dir, f"run_report.{ext}")
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
                paths[ext] = path
                if self.logger:
                    self.logger.info(
                        "Wrote run_report.%s to %s (%d bytes)",
                        ext, path, os.path.getsize(path),
                    )
            except OSError as exc:
                if self.logger:
                    self.logger.warning(
                        "Could not write run_report.%s: %s", ext, exc,
                    )
        return paths

    # -- Email ----------------------------------------------------------

    def send_email(self, email_cfg: Dict[str, Any]) -> bool:
        """Send the report as an HTML email.

        ``email_cfg`` keys (all optional except smtp_host + to + from):
            send_email     bool       master switch (default False)
            smtp_host      str        SMTP server hostname
            smtp_port      int        default 25
            smtp_user      str        optional auth user
            smtp_password  str        optional auth password
            smtp_use_tls   bool       default False (set True for STARTTLS)
            email_from     str        From: header
            email_to       str|list   To: header (comma list or python list)
            email_subject  str        override default subject

        Returns True if mail sent, False if skipped (flag off or
        config missing).  Errors logged at WARN -- never raises (an
        email failure must not kill the pipeline).
        """
        if not email_cfg.get("send_email"):
            if self.logger:
                self.logger.info(
                    "send_email=False -- skipping %s notification",
                    self.status,
                )
            return False
        smtp_host = email_cfg.get("smtp_host", "")
        email_from = email_cfg.get("email_from", "")
        email_to = email_cfg.get("email_to", "")
        if not smtp_host or not email_from or not email_to:
            if self.logger:
                self.logger.warning(
                    "send_email=True but smtp_host / email_from / "
                    "email_to missing -- skipping email"
                )
            return False
        if isinstance(email_to, str):
            email_to = [t.strip() for t in email_to.split(",") if t.strip()]

        period = self.context.get("period", "")
        run_id = self.context.get("run_id", "")
        default_subject = (
            f"[SAP MEBAL] {self.status} -- period {period} -- run_id {run_id}"
        )
        subject = email_cfg.get("email_subject") or default_subject

        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = email_from
        msg["To"] = ", ".join(email_to)
        msg.set_content(self.to_text())  # plain-text fallback
        msg.add_alternative(self.to_html(), subtype="html")

        try:
            with smtplib.SMTP(smtp_host, int(email_cfg.get("smtp_port", 25))) as s:
                if email_cfg.get("smtp_use_tls"):
                    s.starttls()
                if email_cfg.get("smtp_user"):
                    s.login(
                        email_cfg["smtp_user"],
                        email_cfg.get("smtp_password", ""),
                    )
                s.send_message(msg)
            if self.logger:
                self.logger.info(
                    "Sent %s email to %s via %s",
                    self.status, email_to, smtp_host,
                )
            return True
        except Exception as exc:
            if self.logger:
                self.logger.warning(
                    "Email send FAILED (%s) -- run continues, "
                    "report still on disk at %s",
                    exc, self.output_dir,
                )
            return False
