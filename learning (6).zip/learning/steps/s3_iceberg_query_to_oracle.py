"""Phase 134-P — Iceberg → Oracle via user SQL.

Reads an Iceberg table, runs the user's SQL against it (Spark+Iceberg
predicate pushdown), writes the filtered result to Oracle via JDBC
(``S3BaseStep._write_to_oracle``).

Parity note: ``s3_iceberg_to_oracle.py`` already exists but it loads
the whole table (or applies a single ``where_filter`` string).  This
step gives the user a SQL-shaped pushdown — full ``SELECT
col1, col2 FROM source WHERE …`` semantics, projection-pruning
included — which matches the BQB / CQB / Published API surface on
the QueryStudio side.
"""
from __future__ import annotations

from typing import Any, Dict

from steps.s3_query_base import S3QueryBase


class S3IcebergQueryToOracle(S3QueryBase):
    """Read Iceberg via Spark SQL, sink to Oracle via JDBC."""

    LOG_PREFIX = "s3_iceberg_query_to_oracle"

    REQUIRED_FIELDS = [
        *S3QueryBase.BASE_REQUIRED_FIELDS,
        "iceberg_table",
        "oracle_url", "oracle_user", "oracle_password",
    ]

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        oracle_table = self._get_dest_table(task, config)
        if not oracle_table:
            raise ValueError(
                "dest_table is required (set in the polling row or "
                "the per-task JSON config) for Oracle-sink steps"
            )
        batch_size = int(config.get("batch_size", 50000))
        num_partitions = int(config.get("num_partitions", 10))

        spark = None
        try:
            spark = self._build_spark_session_s3(task, config, with_iceberg=True)
            df, total_rows, _read_time = self._read_iceberg_with_query(spark, config, task)
            task["totalcount"] = total_rows

            self._write_to_oracle(df, config, oracle_table, batch_size, num_partitions)

            if self.oracle_data_manager:
                await self.oracle_data_manager.update_otg_etl_batch_status(
                    task.get("run_id"), task.get("run_detail_id"),
                    "UPDATE_TASK_RECORDCOUNT", step_name,
                    total_rows, "", worker_connection_string,
                )
            return total_rows

        except Exception as exc:
            self.logger.error(f"JOB FAILED: {exc}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    spark.stop()
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
