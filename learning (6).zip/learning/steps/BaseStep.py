# BaseStep.py
from abc import ABC, abstractmethod
from typing import Dict, Any

class BaseStep(ABC):
    """Base class for all step implementations, providing common functionality."""

    def __init__(
        self,
        starburst_clients: Dict[str, Any],
        oracle_data_manager: Any,
        logger: Any,
        config: Dict = None
    ):
        """Initialize the base step with dependencies.

        Args:
            starburst_clients (Dict[str, Any]): Dictionary of StarburstDataSource instances.
            oracle_data_manager (Any): Oracle data manager for database operations.
            logger (Any): Logger instance.
            config (Dict, Optional): Additional configuration (e.g., download path).
        """
        self.starburst_clients = starburst_clients
        self.oracle_data_manager = oracle_data_manager
        self.logger = logger
        self.config = config or {}

    async def execute(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs
    ) -> Any:
        """Execute the step logic with status updates.

        Args:
            task (Dict): Task details from the database.
            worker_connection_string (str): Worker database connection string.
            dest_connection_string (str): Destination database connection string.
            step_name (str): Name of the step for logging.
            *args, **kwargs: Additional arguments such as event_id, dag_run_id, fk_report_id.

        Returns:
            Any: Result of the step execution.

        Raises:
            Exception: If the step fails, status updated to FAILED.
        """
        run_detail_id = task.get("run_detail_id")
        dag_run_id = task.get("run_id")
        event_id = kwargs.get("event_id", task.get("run_detail_id", ""))
        fk_report_id = kwargs.get("fk_report_id", task.get("fk_report_id", ""))

        self.logger.info(
            f"ProcessBaseStep - Starting {step_name} for run_detail_id {run_detail_id}"
        )
        self.logger.info(
            f"ProcessBaseStep - Starting {step_name} for run_id {dag_run_id}"
        )

        if not dag_run_id:
            raise ValueError("run_id (dag_run_id) is required in task")

        if self.oracle_data_manager:
            await self.oracle_data_manager.update_otg_etl_batch_status(
                dag_run_id,
                run_detail_id,
                "INPROGRESS",
                step_name,
                0,
                "",
                worker_connection_string
            )

        try:
            result = await self._execute_step(
                task,
                worker_connection_string,
                dest_connection_string,
                step_name,
                *args,
                **kwargs
            )

            totalcount = task.get("totalcount", 0)
            self.logger.info(f"Total records from base steps {totalcount}")

            if self.oracle_data_manager:
                await self.oracle_data_manager.update_otg_etl_batch_status(
                    dag_run_id,
                    run_detail_id,
                    "COMPLETED",
                    step_name,
                    totalcount,
                    "",
                    worker_connection_string
                )
            return result

        except Exception as e:
            totalcount = task.get("totalcount", 0)
            self.logger.error(
                f"Step {step_name} failed for task {run_detail_id}: {str(e)}"
            )

            if self.oracle_data_manager:
                await self.oracle_data_manager.update_otg_etl_batch_status(
                    dag_run_id,
                    run_detail_id,
                    "FAILED",
                    step_name,
                    totalcount,
                    str(e),
                    worker_connection_string
                )
            raise

    @abstractmethod
    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs
    ) -> Any:
        """Abstract method to implement the specific step logic.

        Args:
            task (Dict): Task details from the database.
            worker_connection_string (str): Worker database connection string.
            dest_connection_string (str): Destination database connection string.
            step_name (str): Name of the step for logging.

        Returns:
            Any: Result of the step execution.
        """
        pass