"""
Starburst/Trino (Cloud) → Oracle step.
Extends StarburstBase — only overrides cloud-specific config keys and memory defaults.
"""
from steps.starburst_base import StarburstBase


class StarburstToOracle_OnCloud(StarburstBase):
    """Spark step to read from Starburst Cloud (Trino) and write to Oracle."""

    QUERY_KEY = "query_on_cloud"
    TRINO_URL_KEY = "trino_oncloud_url"
    DEFAULT_EXECUTOR_MEMORY = "10g"
    DEFAULT_DRIVER_MEMORY = "3g"
    LOG_PREFIX = "sb_to_oracle_oncloud"
