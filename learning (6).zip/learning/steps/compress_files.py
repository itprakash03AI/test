"""
Compress Files step.
GZips the consolidated data file and computes MD5 checksum.
"""
import gzip
import hashlib
import os
from typing import Dict

from steps.sap_odata_base import SapOdataBase


class CompressFiles(SapOdataBase):
    """GZip a data file and compute MD5 checksum."""

    LOG_PREFIX = "compress_files"

    REQUIRED_FIELDS = []

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        source_file = task.get('consolidated_file', '')
        if not source_file or not os.path.exists(source_file):
            raise ValueError(f"Consolidated file not found: {source_file}")

        gzip_level = config.get('gzip_level', 6)
        chunk_size = config.get('gzip_chunk_size', 64 * 1024 * 1024)  # 64MB chunks
        delete_source = config.get('delete_uncompressed', True)

        gz_path = f"{source_file}.gz"
        self.logger.info(f"Compressing {source_file} → {gz_path} (level={gzip_level})")

        # GZip with streaming (no full file in memory)
        # Audit NIT — FIPS-strict hosts refuse hashlib.md5() without
        # ``usedforsecurity=False`` (Python 3.9+).  The MD5 here is a
        # CTL-file integrity checksum — not a cryptographic primitive —
        # so the kwarg is correct (mirrors the Phase 130 fix for CTL).
        try:
            md5_hash = hashlib.md5(usedforsecurity=False)
        except TypeError:  # pragma: no cover — Py < 3.9
            md5_hash = hashlib.md5()
        source_size = os.path.getsize(source_file)

        with open(source_file, 'rb') as f_in:
            with gzip.open(gz_path, 'wb', compresslevel=gzip_level) as f_out:
                while True:
                    chunk = f_in.read(chunk_size)
                    if not chunk:
                        break
                    md5_hash.update(chunk)
                    f_out.write(chunk)

        compressed_size = os.path.getsize(gz_path)
        checksum = md5_hash.hexdigest()
        ratio = (1 - compressed_size / source_size) * 100 if source_size > 0 else 0

        self.logger.info(
            f"Compression complete: {source_size:,} → {compressed_size:,} bytes "
            f"({ratio:.1f}% reduction), MD5={checksum}"
        )

        # Pass state to next steps
        task['compressed_file'] = gz_path
        task['checksum'] = checksum
        task['compressed_size'] = compressed_size
        task['uncompressed_size'] = source_size

        # Clean up uncompressed file
        if delete_source:
            os.remove(source_file)
            self.logger.info(f"Deleted uncompressed file: {source_file}")

        return task.get('totalcount', 0)
