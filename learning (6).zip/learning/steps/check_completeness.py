"""Check data completeness step.

Validates that the data the upstream steps produced is non-empty and
meets the operator-configured minimum-record threshold.  Pure
in-process check — no external services, no DB writes.

Consumes from the task dict (populated by Download → Consolidate):
  * ``totalcount``        — row count after consolidation
  * ``consolidated_file`` — path to the merged CSV / parquet
  * ``compressed_file``   — path to the gzipped output (if compression ran)

Honours the following JSON-config knobs (optional):
  * ``min_record_count`` — minimum acceptable row count (default 1).
                           0 means "any count, including empty, is OK".
  * ``require_output_file`` — bool, default True.  When True, the file
                              referenced by ``consolidated_file`` /
                              ``compressed_file`` must exist on disk.
  * ``max_record_count`` — optional upper bound.  Useful when the SAP
                           service is paginated and a runaway request
                           would point at a misconfigured filter.

Fails loud with a descriptive ValueError so the worker's break-on-step-
failure semantics kick in and downstream steps (CreateCTLFile,
DeliverFiles) never run on incomplete data.
"""
import os
from typing import Dict

from steps.sap_odata_base import SapOdataBase


class CheckCompleteness(SapOdataBase):
    """Validate downstream-step output before delivery."""

    LOG_PREFIX = "check_completeness"

    REQUIRED_FIELDS = []  # all state comes from the task dict + JSON config

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        totalcount = task.get('totalcount')
        if totalcount is None:
            raise ValueError(
                "CheckCompleteness: task['totalcount'] is unset — the "
                "upstream Download / Consolidate step did not record a "
                "row count.  Cannot certify completeness."
            )
        try:
            totalcount = int(totalcount)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"CheckCompleteness: task['totalcount'] {totalcount!r} "
                f"is not an integer ({exc})."
            )

        min_count = int(config.get('min_record_count', 1))
        max_count = config.get('max_record_count')

        if totalcount < min_count:
            raise ValueError(
                f"CheckCompleteness: row count {totalcount} is below the "
                f"configured minimum ({min_count}).  Halting before "
                f"CTL / delivery so partial data does not leave the pod."
            )

        if max_count is not None and totalcount > int(max_count):
            raise ValueError(
                f"CheckCompleteness: row count {totalcount} exceeds the "
                f"configured maximum ({max_count}).  Likely a "
                f"misconfigured filter producing a runaway extract."
            )

        require_file = bool(config.get('require_output_file', True))
        if require_file:
            # Compressed file wins (it's the artefact that ships), but
            # fall through to the consolidated file when the compress
            # step was skipped.
            output_file = (
                task.get('compressed_file')
                or task.get('consolidated_file')
                or ''
            )
            if not output_file:
                raise ValueError(
                    "CheckCompleteness: no compressed_file/consolidated_file "
                    "in task dict — Consolidate or Compress step did not "
                    "record an output path."
                )
            if not os.path.exists(output_file):
                raise ValueError(
                    f"CheckCompleteness: output file {output_file!r} does "
                    f"not exist on disk."
                )

            size = os.path.getsize(output_file)
            if size == 0:
                raise ValueError(
                    f"CheckCompleteness: output file {output_file!r} is "
                    f"empty (0 bytes) even though totalcount={totalcount}."
                )
            self.logger.info(
                "CheckCompleteness PASS: rows=%d, file=%s (%d bytes)",
                totalcount, output_file, size,
            )
        else:
            self.logger.info(
                "CheckCompleteness PASS: rows=%d (file check skipped per config)",
                totalcount,
            )

        return totalcount
