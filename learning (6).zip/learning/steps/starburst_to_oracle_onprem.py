"""
Starburst/Trino (On-Prem) → Oracle step.
Extends StarburstBase — only overrides on-prem-specific config keys and memory defaults.
"""
from steps.starburst_base import StarburstBase


class StarburstToOracle_OnPrem(StarburstBase):
    """Spark step to read from Starburst On-Prem (Trino) and write to Oracle."""

    QUERY_KEY = "query_on_prem"
    TRINO_URL_KEY = "trino_onprem_url"
    DEFAULT_EXECUTOR_MEMORY = "15g"
    DEFAULT_DRIVER_MEMORY = "4g"
    LOG_PREFIX = "sb_to_oracle_onprem"
