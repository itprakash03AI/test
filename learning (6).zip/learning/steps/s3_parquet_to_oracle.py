"""
S3 Parquet → Oracle step.
Reads parquet files from S3 (AWS or on-prem) and writes to Oracle via JDBC.
Supports presigned URL fallback for on-prem S3 (Dell ECS/MinIO).
"""
import shutil
import os
from typing import Dict, Any
from steps.s3_base_step import S3BaseStep


class S3ParquetToOracle(S3BaseStep):
    """Read parquet from S3 and write to Oracle via JDBC."""

    LOG_PREFIX = "s3_parquet_to_oracle"

    REQUIRED_FIELDS = [
        'oracle_url', 'oracle_user', 'oracle_password',
        's3_access_key', 's3_secret_key', 's3_bucket', 's3_prefix',
    ]

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str, *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        oracle_table = self._get_dest_table(task, config)
        s3_input_path = f"s3a://{config['s3_bucket']}/{config['s3_prefix']}"
        num_partitions = config.get('num_partitions', 10)
        batch_size = config.get('batch_size', 50000)
        use_presigned = config.get('use_presigned_urls', False)

        spark = None
        local_paths = None
        try:
            spark = self._build_spark_session_s3(task, config)

            # Read parquet from S3 (with presigned fallback for on-prem)
            self.logger.info(f"Reading parquet from {s3_input_path}")
            if use_presigned:
                self.logger.info("Using presigned URL fallback (on-prem S3)")
                s3_paths = self._list_s3_files(config, config['s3_bucket'], config['s3_prefix'])
                local_paths = self._presigned_fallback(config, s3_paths)
                df = spark.read.parquet(*local_paths)
            else:
                df = spark.read.parquet(s3_input_path)

            total_rows = df.count()
            self.logger.info(f"Read {total_rows} rows")
            task['totalcount'] = total_rows

            # Write to Oracle via shared base method
            write_time = self._write_to_oracle(df, config, oracle_table, batch_size, num_partitions)

            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"), task.get("run_detail_id"),
                'UPDATE_TASK_RECORDCOUNT', step_name,
                total_rows, "", worker_connection_string
            )
            return total_rows

        except Exception as e:
            self.logger.error(f"JOB FAILED: {e}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    spark.stop()
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
            if local_paths:
                try:
                    shutil.rmtree(os.path.dirname(local_paths[0]), ignore_errors=True)
                except Exception:
                    pass
