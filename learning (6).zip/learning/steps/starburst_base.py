"""
Shared base class for Starburst/Trino → Oracle Spark JDBC steps.
Subclasses override QUERY_KEY, TRINO_URL_KEY, and default memory settings.
"""
import os
import json
import logging
import sys
from datetime import datetime
from typing import Dict, Any, List

from pyspark.sql import SparkSession, DataFrame
from steps.BaseStep import BaseStep


class StarburstBase(BaseStep):
    """Base class for Starburst→Oracle steps with shared config, Spark, and JDBC logic."""

    # --- Subclass overrides ---
    QUERY_KEY: str = "query_on_cloud"           # config key for SQL query
    TRINO_URL_KEY: str = "trino_oncloud_url"    # config key for Trino JDBC URL
    DEFAULT_EXECUTOR_MEMORY: str = "10g"
    DEFAULT_DRIVER_MEMORY: str = "3g"
    LOG_PREFIX: str = "sb_to_oracle"

    # --- Required config fields (shared across OnPrem/OnCloud) ---
    COMMON_REQUIRED_FIELDS: List[str] = [
        'trino_user', 'trino_password',
        'oracle_url', 'oracle_user', 'oracle_password',
        'spark_jars',
    ]

    def _get_required_fields(self) -> List[str]:
        """Return full list of required config fields including subclass-specific keys."""
        return [self.QUERY_KEY, self.TRINO_URL_KEY] + self.COMMON_REQUIRED_FIELDS

    def _load_and_validate_config(self, task: Dict) -> Dict:
        """Load JSON config from task['sql_query_path'] and validate required fields."""
        config_path = task.get('sql_query_path')
        if not config_path:
            raise ValueError("Task missing 'sql_query_path'")

        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Config file not found: {config_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in config {config_path}: {e}")

        required = self._get_required_fields()
        missing = [f for f in required if f not in config]
        if missing:
            raise ValueError(f"Missing required config fields: {missing}")

        return config

    def _parameterize_query(self, query: str, task: Dict) -> str:
        """Replace template variables in SQL query."""
        replacements = {
            "{BUSINESSDATE}": task.get('business_date', ''),
            "{SYSTEM_ENTITY}": task.get('system_entity', ''),
            "{EventCode}": task.get('eventcode', ''),
        }
        for placeholder, value in replacements.items():
            query = query.replace(placeholder, value)
        return query

    def _setup_logging(self, task: Dict) -> None:
        """Configure a named logger for this step.

        Uses shared pipeline log file from ``task['log_file']`` so all
        steps write to a single file.  Falls back to a per-step file.
        """
        self.logger = logging.getLogger(f"etl.{self.LOG_PREFIX}")

        # Avoid adding duplicate handlers if called again
        if self.logger.handlers:
            return

        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        self.logger.addHandler(sh)

        # Prefer shared pipeline log file; fall back to per-step file.
        # Log dir resolved via log_config.get_log_dir() — ETL_LOG_DIR
        # env var wins, then polling YAML, then legacy PVC path.
        log_path = task.get('log_file')
        if not log_path:
            run_id = task.get('run_id', 'unknown')
            date_str = datetime.now().strftime('%Y-%m-%d')
            try:
                from log_config import get_log_dir as _resolve_log_dir
                _ld = _resolve_log_dir()
            except Exception:
                _ld = "/usr/local/spark/nfs/bcp/batch/logs"
            log_path = os.path.join(
                _ld, f"etl_{self.LOG_PREFIX}_{run_id}_{date_str}.log",
            )

        try:
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            fh = logging.FileHandler(log_path)
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except OSError as e:
            self.logger.warning(f"Cannot create log file {log_path}: {e} — console only")

    def _build_spark_session(self, task: Dict, config: Dict) -> SparkSession:
        """Build SparkSession with configurable memory and common settings."""
        run_id = task.get('run_id', 'unknown')
        run_detail_id = task.get('run_detail_id', 'unknown')
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')

        executor_memory = config.get('spark_executor_memory', self.DEFAULT_EXECUTOR_MEMORY)
        driver_memory = config.get('spark_driver_memory', self.DEFAULT_DRIVER_MEMORY)
        executor_overhead = config.get('spark_executor_memory_overhead', '1g')
        driver_overhead = config.get('spark_driver_memory_overhead', '1g')
        num_partitions = config.get('num_partitions', 10)
        spark_jars = config['spark_jars']

        try:
            from log_config import get_log_dir as _resolve_log_dir
            _evt_root = _resolve_log_dir()
        except Exception:
            _evt_root = "/usr/local/spark/nfs/bcp/batch/logs"
        event_log_dir = os.path.join(
            _evt_root, "event-logs",
            f"{run_id}_{run_detail_id}_{timestamp}",
        )
        os.makedirs(event_log_dir, exist_ok=True)

        spark = (
            SparkSession.builder
            .appName(f"{self.LOG_PREFIX}_{run_id}-{run_detail_id}")
            .config("spark.executor.cores", "1")
            .config("spark.kubernetes.executor.request.cores", "300m")
            .config("spark.kubernetes.executor.limit.cores", "1")
            .config("spark.executor.memory", executor_memory)
            .config("spark.driver.memory", driver_memory)
            .config("spark.executor.memoryOverhead", executor_overhead)
            .config("spark.driver.memoryOverhead", driver_overhead)
            .config("spark.executor.instances", "1")
            .config("spark.sql.shuffle.partitions", str(num_partitions))
            .config("spark.jars", spark_jars)
            .config("spark.sql.execution.arrow.pyspark.enabled", "true")
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.dynamicAllocation.enabled", "false")
            .config("spark.eventLog.enabled", "true")
            .config("spark.eventLog.dir", event_log_dir)
            .getOrCreate()
        )
        return spark

    def _read_from_trino(
        self, spark: SparkSession, config: Dict, query: str, num_partitions: int = 10
    ) -> tuple:
        """Read data from Trino via JDBC. Returns (df, total_rows, read_time_seconds)."""
        trino_url = config[self.TRINO_URL_KEY]
        trino_user = config['trino_user']
        trino_password = config['trino_password']
        fetchsize = config.get('fetchsize', '70000')

        # COUNT(*) pushdown — get record count without full scan
        count_query = f"SELECT COUNT(*) AS CNT FROM ({query}) t"
        self.logger.info("Fetching record count from Trino via COUNT(*) pushdown...")
        cnt_df = (
            spark.read.format("jdbc")
            .option("url", trino_url)
            .option("dbtable", f"({count_query}) as c")
            .option("user", trino_user)
            .option("password", trino_password)
            .option("driver", "io.trino.jdbc.TrinoDriver")
            .load()
        )
        total_rows = int(cnt_df.collect()[0]["CNT"])
        self.logger.info(f"Record count from source = {total_rows}")

        # Read all data
        self.logger.info("Reading data from Trino...")
        read_start = datetime.now()
        df = (
            spark.read.format("jdbc")
            .option("url", trino_url)
            .option("dbtable", f"({query}) as subq")
            .option("user", trino_user)
            .option("password", trino_password)
            .option("driver", "io.trino.jdbc.TrinoDriver")
            .option("fetchsize", str(fetchsize))
            .option("numPartitions", str(num_partitions))
            .load()
        )
        read_time = (datetime.now() - read_start).total_seconds()
        self.logger.info(f"Read all rows in {read_time:.2f}s")

        return df, total_rows, read_time

    def _write_to_oracle(
        self, df: DataFrame, config: Dict, table: str,
        batch_size: int = 50000, num_partitions: int = 10
    ) -> float:
        """Write DataFrame to Oracle via JDBC. Returns write_time_seconds."""
        oracle_url = config['oracle_url']
        oracle_user = config['oracle_user']
        oracle_password = config['oracle_password']

        self.logger.info(f"Repartitioning to {num_partitions} partitions before write...")
        df = df.repartition(num_partitions)

        self.logger.info(f"Writing to {table}")
        write_start = datetime.now()
        (
            df.write.format("jdbc")
            .option("url", oracle_url)
            .option("dbtable", table)
            .option("user", oracle_user)
            .option("password", oracle_password)
            .option("driver", "oracle.jdbc.OracleDriver")
            .option("batchsize", str(batch_size))
            .option("isolationLevel", "NONE")
            .option("numPartitions", str(num_partitions))
            .mode("append")
            .save()
        )
        write_time = (datetime.now() - write_start).total_seconds()
        self.logger.info(f"Write completed in {write_time:.2f}s")
        return write_time

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        """Execute the Starburst→Oracle step: read from Trino, write to Oracle."""
        config = self._load_and_validate_config(task)
        self._setup_logging(task)

        # Parameterize query
        raw_query = config[self.QUERY_KEY]
        trino_query = self._parameterize_query(raw_query, task)

        batch_size = config.get('batch_size', 50000)
        num_partitions = config.get('num_partitions', 10)
        oracle_table = task["dest_table"]

        # Build Spark session
        spark = None
        try:
            spark = self._build_spark_session(task, config)
        except Exception as e:
            self.logger.error(f"Spark session failed: {e}", exc_info=True)
            raise RuntimeError(f"Spark init failed: {e}") from e

        try:
            # Read from Trino
            df, total_rows, read_time = self._read_from_trino(
                spark, config, trino_query, num_partitions
            )
            task['totalcount'] = total_rows

            # Write to Oracle
            write_time = self._write_to_oracle(
                df, config, oracle_table, batch_size, num_partitions
            )

            total_time = read_time + write_time
            self.logger.info(f"TOTAL TIME: {total_time:.2f}s (read={read_time:.2f}s, write={write_time:.2f}s)")

            # Update record count in Oracle metadata
            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"), task.get("run_detail_id"),
                'UPDATE_TASK_RECORDCOUNT', step_name,
                total_rows, "", worker_connection_string
            )
            return total_rows

        except Exception as e:
            self.logger.error(f"JOB FAILED: {e}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    spark.stop()
                    self.logger.info("Spark session stopped successfully")
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark session: {stop_err}")
