"""
Consolidate Files step.
Merges multiple per-group CSV files into a single output file.
Handles header deduplication (only first file's header kept).

Phase 132.29 — also applies optional column mapping read from the JSON
file at ``config['column_mapping_path']``:
    {
      "column_mapping": {"Companycode": "company_code", ...},
      "column_order":   ["company_code", "fiscal_year", ...],   # optional
      "drop_columns":   ["__metadata", "__deferred"]            # optional
    }
Renames SAP source columns to your target schema in a single pass over
each per-group CSV, then writes the consolidated file with the final
header.  Skipped entirely when ``column_mapping_path`` is absent — the
legacy behaviour (verbatim pass-through) is preserved.
"""
import csv
import json
import os
from typing import Any, Dict, List, Optional

from steps.sap_odata_base import SapOdataBase


class ConsolidateFiles(SapOdataBase):
    """Merge per-group CSV/parquet files into a single file."""

    LOG_PREFIX = "consolidate_files"

    REQUIRED_FIELDS = []  # All state comes from task dict (set by download step)

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        downloaded_files = task.get('downloaded_files', [])
        if not downloaded_files:
            raise ValueError("No downloaded files found in task — SapOdataDownload must run first")

        output_dir = task.get('output_dir', config.get('output_dir', '/tmp'))
        p_gjahr = task.get('p_gjahr', '')
        p_poper = task.get('p_poper', '')
        output_format = task.get('output_format', 'csv')

        # Audit BLOCKER #1 (Phase 134-K) — consolidated CSV used the default
        # `,` delimiter while the CTL template advertises `csv-separator:|`,
        # so every downstream pipe-split reader was mangling rows.  Default
        # to `|` here so the data file matches the CTL contract.  Per-group
        # source files are read with the SAME delimiter — both writer + reader
        # honour the same config key — so re-runs over already-pipe-delimited
        # intermediates keep working.
        consolidated_delim = config.get('consolidated_csv_delimiter', '|')
        # Per-group source files come from _paginated_odata_to_csv which
        # writes via csv.DictWriter() (default `,`).  Allow the reader to
        # be configured separately for environments that produce sources
        # in a different shape (e.g. when steps run with different configs
        # mid-migration).
        source_delim = config.get('source_csv_delimiter', ',')

        filename_template = config.get('consolidated_filename', 'MEBAL_{GJAHR}_{POPER}')
        filename = filename_template.replace('{GJAHR}', p_gjahr).replace('{POPER}', p_poper)
        output_path = os.path.join(output_dir, f"{filename}.{output_format}")

        # Phase 132.29 — load optional column mapping
        mapping_spec = self._load_column_mapping(config.get('column_mapping_path'))
        if mapping_spec:
            self.logger.info(
                "Column mapping loaded: %d renames, %d drops, %s ordering",
                len(mapping_spec.get("column_mapping") or {}),
                len(mapping_spec.get("drop_columns") or []),
                "explicit" if mapping_spec.get("column_order") else "natural",
            )

        self.logger.info(
            "Consolidating %d files into %s (source delim=%r, output delim=%r)",
            len(downloaded_files), output_path, source_delim, consolidated_delim,
        )

        if output_format == 'csv':
            total_rows = self._merge_csv_files(
                downloaded_files, output_path,
                mapping_spec=mapping_spec,
                source_delim=source_delim,
                output_delim=consolidated_delim,
            )
        else:
            total_rows = self._merge_parquet_files(downloaded_files, output_path,
                                                     mapping_spec=mapping_spec)

        self.logger.info(f"Consolidated {total_rows} rows into {output_path}")
        task['consolidated_file'] = output_path
        task['totalcount'] = total_rows

        # Clean up per-group files
        if config.get('delete_group_files', True):
            for f in downloaded_files:
                try:
                    os.remove(f)
                except OSError:
                    pass

        return total_rows

    # ── Phase 132.29 — column mapping helpers ───────────────────────────

    def _load_column_mapping(self, path: Optional[str]) -> Dict[str, Any]:
        """Read the column_mapping JSON.  Returns {} on missing/unreadable
        — column mapping is OPTIONAL so a bad/missing file degrades to
        verbatim pass-through.
        """
        if not path:
            return {}
        if not os.path.exists(path):
            self.logger.warning(
                "column_mapping_path %s does not exist — using verbatim columns", path)
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                spec = json.load(f)
            if not isinstance(spec, dict):
                self.logger.warning("column_mapping JSON is not a dict — ignoring")
                return {}
            return spec
        except Exception as exc:
            self.logger.warning(
                "could not read column_mapping %s: %s — using verbatim columns",
                path, exc)
            return {}

    def _resolve_header(
        self, source_header: List[str], mapping_spec: Dict[str, Any],
    ) -> tuple:
        """Apply rename + drop + reorder.  Returns:
            (target_header,                       # final column names, write order
             source_index_by_target_position)     # int[len(target_header)] → source col idx
        """
        if not mapping_spec:
            # No mapping → use source as-is
            return source_header, list(range(len(source_header)))

        rename = mapping_spec.get("column_mapping") or {}
        drop_set = set(mapping_spec.get("drop_columns") or [])
        explicit_order = mapping_spec.get("column_order")

        # 1. Build renamed header (drop columns flagged for removal)
        renamed: List[tuple] = []   # (target_name, source_idx)
        for idx, src_name in enumerate(source_header):
            if src_name in drop_set:
                continue
            target_name = rename.get(src_name, src_name)
            if target_name in drop_set:
                continue
            renamed.append((target_name, idx))

        if explicit_order:
            # 2a. Reorder by explicit list; missing target columns are skipped
            by_target = {t: idx for t, idx in renamed}
            target_header: List[str] = []
            source_index_by_target: List[int] = []
            for t in explicit_order:
                if t in by_target:
                    target_header.append(t)
                    source_index_by_target.append(by_target[t])
                else:
                    self.logger.warning(
                        "column_order references %r but it's not in the "
                        "renamed source columns — skipped", t)
            return target_header, source_index_by_target

        # 2b. Natural ordering — same as source minus drops
        target_header = [t for t, _ in renamed]
        source_index_by_target = [idx for _, idx in renamed]
        return target_header, source_index_by_target

    # ── CSV / Parquet merge ─────────────────────────────────────────────

    def _merge_csv_files(self, files: List[str], output_path: str,
                          mapping_spec: Optional[Dict[str, Any]] = None,
                          source_delim: str = ',',
                          output_delim: str = '|') -> int:
        """Merge CSV files, keeping header from first file only.
        Optionally applies rename/drop/reorder from mapping_spec.

        ``source_delim`` is the delimiter expected on the per-group input
        files; ``output_delim`` is what we emit on the consolidated file
        (default ``|`` so the CTL template's ``csv-separator:|``
        advertisement matches what's actually on disk).
        """
        mapping_spec = mapping_spec or {}
        total_rows = 0
        header_written = False
        writer = None
        target_header: List[str] = []
        col_idx: List[int] = []

        with open(output_path, 'w', newline='', encoding='utf-8') as out_f:
            for file_path in files:
                if not os.path.exists(file_path):
                    self.logger.warning(f"File not found, skipping: {file_path}")
                    continue

                with open(file_path, 'r', encoding='utf-8') as in_f:
                    reader = csv.reader(in_f, delimiter=source_delim)
                    header = next(reader, None)
                    if not header:
                        continue

                    if not header_written:
                        target_header, col_idx = self._resolve_header(
                            header, mapping_spec)
                        writer = csv.writer(out_f, delimiter=output_delim)
                        writer.writerow(target_header)
                        header_written = True

                    if mapping_spec:
                        # Per-row projection — pick + order source cells
                        for row in reader:
                            try:
                                projected = [row[i] if i < len(row) else "" for i in col_idx]
                            except IndexError:
                                projected = [row[i] if i < len(row) else "" for i in col_idx]
                            writer.writerow(projected)
                            total_rows += 1
                    else:
                        for row in reader:
                            writer.writerow(row)
                            total_rows += 1

                self.logger.info(f"Merged {file_path}")

        return total_rows

    def _merge_parquet_files(self, files: List[str], output_path: str,
                              mapping_spec: Optional[Dict[str, Any]] = None) -> int:
        """Merge parquet files using pyarrow.  Applies column mapping
        when supplied (rename → drop → reorder) via pyarrow.Table
        operations (no DataFrame round-trip)."""
        import pyarrow.parquet as pq
        import pyarrow as pa

        existing = [f for f in files if os.path.exists(f)]
        if not existing:
            return 0

        tables = [pq.read_table(f) for f in existing]
        merged = pa.concat_tables(tables)

        if mapping_spec:
            rename = mapping_spec.get("column_mapping") or {}
            drop_set = set(mapping_spec.get("drop_columns") or [])
            # rename
            new_names = []
            for c in merged.column_names:
                if c in drop_set:
                    new_names.append(None)
                else:
                    new_names.append(rename.get(c, c))
            keep_idx = [i for i, n in enumerate(new_names) if n is not None]
            kept = merged.select(keep_idx)
            kept = kept.rename_columns([new_names[i] for i in keep_idx])
            # drop any target-named columns
            drop_target = [c for c in kept.column_names if c in drop_set]
            for c in drop_target:
                kept = kept.drop([c])
            explicit_order = mapping_spec.get("column_order")
            if explicit_order:
                in_order = [c for c in explicit_order if c in kept.column_names]
                if in_order:
                    kept = kept.select(in_order)
            merged = kept

        pq.write_table(merged, output_path)
        return merged.num_rows
    # Audit SERIOUS #1 (Phase 134-K) — the duplicate (mapping-less)
    # _merge_parquet_files definition that used to live below this point
    # was silently shadowing the mapping-aware version above (Python
    # last-wins), so column mapping was being ignored for parquet output.
    # Deleted on 2026-05-26.  Do NOT reintroduce a second def.
