import asyncio
import argparse
import logging
import os
import sys
import time
from pathlib import Path
from datetime import datetime
from typing import Dict, List

import yaml

from workers.oracle_worker import OracleWorker
from datasources.starburst_datasource import StarburstDataSource

# Resolve core_libs path and add to sys.path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
CORE_LIBS_PATH = os.path.join(CURRENT_DIR, "core_libs")

if CORE_LIBS_PATH not in sys.path:
    sys.path.insert(0, CORE_LIBS_PATH)

from managers.oracle_metadata_manager import OracleMetadataManager

from log_config import get_log_dir as _get_log_dir
LOG_DIR = _get_log_dir()
LOG_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# ── Console-only logger at startup (file handler added after args parsed) ──
logger = logging.getLogger("oracle_standalone")
logger.setLevel(logging.INFO)
_sh = logging.StreamHandler(sys.stdout)
_sh.setFormatter(logging.Formatter(LOG_FMT))
logger.addHandler(_sh)

SPARK_UPLOAD_ROOT = Path("/usr/local/spark/gvc/jars")
MAX_AGE_HOURS = 1
PREFIX = "spark-upload-"


def _build_log_file(dag_id: str, report_id: int, business_date: str) -> str:
    """Build a log filename that identifies this batch execution.

    Format: oracle_standalone_{dag_id}_{report_id}_{business_date}_{HHMMSS}.log
    Example: oracle_standalone_GMI_APAC_71_2025-07-10_143022.log
    """
    # Sanitize dag_id for filesystem (replace slashes, spaces, etc.)
    safe_dag = dag_id.replace("/", "_").replace("\\", "_").replace(" ", "_")[:60]
    ts = datetime.now().strftime("%H%M%S")
    safe_date = str(business_date).replace("/", "-").replace(" ", "_")[:20]
    filename = f"oracle_standalone_{safe_dag}_{report_id}_{safe_date}_{ts}.log"
    return os.path.join(LOG_DIR, filename)


def _attach_file_handler(log_file: str) -> None:
    """Add file handler to the module logger after we know the batch context."""
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        fh = logging.FileHandler(log_file)
        fh.setFormatter(logging.Formatter(LOG_FMT))
        logger.addHandler(fh)
        logger.info(f"Logging to: {log_file}")
    except OSError as e:
        logger.warning(f"Cannot create log file {log_file}: {e} — console only")


def cleanup_old_spark_uploads() -> None:
    """Delete old spark-upload-* directories older than MAX_AGE_HOURS."""
    cutoff_timestamp = time.time() - (MAX_AGE_HOURS * 3600)
    try:
        for item in SPARK_UPLOAD_ROOT.iterdir():
            if item.is_dir() and item.name.startswith(PREFIX):
                if item.stat().st_atime < cutoff_timestamp:
                    logger.info(f"Deleting: {item}")
                    try:
                        import shutil
                        shutil.rmtree(item)
                    except Exception as e:
                        logger.error(f"Failed to delete {item}: {e}")
    except Exception as e:
        logger.error(f"cleanup_old_spark_uploads failed with error: {str(e)}")


async def execute_tasks(
    tasks: List[Dict],
    config: Dict,
    worker_connection_string: str,
    dest_connection_string: str,
    log_file: str,
) -> None:
    """
    Execute all Oracle task steps for a given RUN ID based on dynamic sequence.

    Tasks are ordered by SEQ from the polling query. Each row is one step
    (ClearStaging SEQ=1, StarburstToOracle SEQ=2, ProcessData SEQ=3, etc.).
    All tasks share the same Starburst connection config, so we create
    StarburstDataSource clients and OracleWorker ONCE for the entire run.
    """
    if not tasks or not worker_connection_string or not dest_connection_string:
        raise ValueError(
            "Tasks, worker_connection_string, and dest_connection_string are required"
        )

    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # Build Starburst clients ONCE — config is the same for all tasks in a run
    first_task = tasks[0]
    cloud_config = {
        "host": first_task["c_hostname"],
        "port": first_task["c_port"],
        "user": first_task["c_username"],
        "password": first_task["c_pwd"],
        "catalog": first_task["c_catalog"],
        "schema": first_task["c_schemainfo"],
    }
    pres_config = {
        "host": first_task["p_hostname"],
        "port": first_task["p_port"],
        "user": first_task["p_username"],
        "password": first_task["p_pwd"],
        "catalog": first_task["p_catalog"],
        "schema": first_task["p_schemainfo"],
    }
    starburst_clients = {
        "cloud": StarburstDataSource(cloud_config),
        "pres": StarburstDataSource(pres_config),
        "use_99": True,
    }

    # Create OracleWorker ONCE — reused for all steps in this run
    worker = OracleWorker(starburst_clients, oracle_data_manager, logger)

    for task in tasks:
        # Attach shared starburst_clients to each task dict (steps may read it)
        task["starburst_clients"] = starburst_clients
        # Single log file for entire batch execution
        task["log_file"] = log_file

        logger.info(
            f"Executing task {task.get('run_id')} with DAG_ID: {task.get('fk_dag_id')} "
            f"and FK_REPORT_ID: {task.get('fk_report_id')} for step {task.get('task_steps')} "
            f"(SEQ: {task.get('seq')})"
        )

        try:
            await worker.execute_step(
                task,
                worker_connection_string,
                dest_connection_string,
                task["task_steps"],
            )
        except Exception as e:
            logger.error(
                f"Step {task['task_steps']} for task {task['run_id']} failed: {str(e)}"
            )
            # Stop further execution for this RUN_ID — sequential steps depend on each other
            break


async def main() -> None:
    """Main function to execute an Oracle task based on command-line arguments."""
    cleanup_old_spark_uploads()

    parser = argparse.ArgumentParser(
        description="Execute an Oracle task for a specific report ID and business date."
    )
    parser.add_argument(
        "--report_id", type=int, required=True,
        help="The report ID to process.",
    )
    parser.add_argument(
        "--business_date", type=str, required=True,
        help='The business date to process (e.g., "2025-07-10").',
    )
    parser.add_argument(
        "--dag_id", type=str, required=True,
        help="The DAG ID to process.",
    )
    parser.add_argument(
        "--config_path", type=str,
        default="/usr/local/spark/pvc/code/configs/oracle_config.yaml",
        help="Path to the configuration file.",
    )

    args = parser.parse_args()

    # ── Build batch-specific log file after args are known ──
    log_file = _build_log_file(args.dag_id, args.report_id, args.business_date)
    _attach_file_handler(log_file)

    logger.info(
        f"Starting Oracle batch: dag_id={args.dag_id}, "
        f"report_id={args.report_id}, business_date={args.business_date}"
    )

    # Load configuration
    config_path = args.config_path
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    if not config or "oracle" not in config:
        raise ValueError("Invalid configuration file: missing 'oracle' section")

    # Load queries from YAML
    queries_path = "/usr/local/spark/pvc/code/configs/etl_polling_task_query.yaml"
    if not os.path.exists(queries_path):
        raise FileNotFoundError(f"Queries file not found: {queries_path}")

    with open(queries_path, "r") as qf:
        queries = yaml.safe_load(qf)

    if "polling_query_sb_to_oracle" not in queries:
        raise ValueError(
            "polling_query_sb_to_oracle not found in etl_polling_task_query.yaml"
        )

    # Establish database connections
    worker_connection_string = config["oracle"]["etl_connection_string"]
    dest_connection_string = config["oracle"]["dest_connection_string"]

    # Fetch all tasks from database using OracleMetadataManager
    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # execute_query_asynch returns a DataFrame — convert to list of dicts
    tasks_df = await oracle_data_manager.execute_query_asynch(
        queries["polling_query_sb_to_oracle"],
        {
            "1": args.report_id,
            "2": args.business_date,
            "3": args.dag_id,
        },
        worker_connection_string,
    )

    if tasks_df is None or tasks_df.empty:
        logger.info(
            f"No tasks found for report_id {args.report_id}, "
            f"business_date {args.business_date}, dag_id {args.dag_id}"
        )
        return

    # Convert DataFrame rows to list of dicts for downstream consumption
    tasks = tasks_df.to_dict(orient='records')

    # Normalize column names to lowercase for consistent access
    tasks = [{k.lower(): v for k, v in row.items()} for row in tasks]

    # Normalize tasks
    for task in tasks:
        task["task_id"] = task["run_id"]
        task["dag_run_id"] = f"run_{task['run_id']}"

    await execute_tasks(
        tasks, config, worker_connection_string, dest_connection_string, log_file,
    )


if __name__ == "__main__":
    asyncio.run(main())
