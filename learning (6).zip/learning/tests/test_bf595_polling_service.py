"""BF-595 (2026-05-30) — production-readiness fixes for the polling service.

Tests the six closeout items from the deep-dive audit:
  1. BLOCKER: cross-pod DBMS_LOCK claim wired into poller._poll_once
  2. BLOCKER: Spark removed from polling path; createJob_light uses
     LightStarburstBase (direct trino-python-client + oracledb)
  3. SERIOUS: thread_pool_workers config wired into a dedicated executor
  4. SERIOUS: max_run_seconds per-run timeout
  5. SERIOUS: bg_polling_query LIMIT'd via :row_limit bind
  6. SERIOUS: shutdown_timeout_seconds graceful drain
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest
import yaml

# Make ETL/ importable from the test
ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


def _read(*rel: str) -> str:
    """Read a file under ETL_ROOT as text — robust to cwd."""
    return (Path(ETL_ROOT).joinpath(*rel)).read_text(encoding="utf-8")


def _exists(*rel: str) -> bool:
    return (Path(ETL_ROOT).joinpath(*rel)).is_file()


# ─── 1. BLOCKER — cross-pod claim wired ──────────────────────────────


class TestBF595CrossPodClaim:
    def test_try_claim_run_called_from_poll_once(self):
        """poller._poll_once must invoke try_claim_run before dispatch."""
        src = _read("polling_service", "poller.py")
        assert "try_claim_run" in src, (
            "BF-595: poller must call oracle_manager.try_claim_run before "
            "dispatching each RUN_ID — cross-pod safety."
        )
        # Anchor on the _poll_once block to make sure the call is in the
        # dispatch path, not just a comment elsewhere.
        idx = src.find("async def _poll_once")
        assert idx > 0
        block = src[idx:idx + 5000]
        assert "try_claim_run" in block, (
            "BF-595: try_claim_run must be in the _poll_once dispatch path."
        )

    def test_skipped_cross_pod_counter_present(self):
        src = _read("polling_service", "poller.py")
        assert "skipped_cross_pod" in src

    @pytest.mark.asyncio
    async def test_poll_once_skips_when_claim_returns_false(self):
        from polling_service.poller import BackgroundPoller

        cfg = MagicMock()
        cfg.etl_connection_string = "dummy"
        cfg.bg_polling_sql = "SELECT 1 FROM DUAL"
        cfg.max_concurrent_runs = 5
        cfg.polling_query_limit_multiplier = 20
        cfg.worker_id = "test"

        oracle_mgr = MagicMock()
        oracle_mgr.get_all_start_tasks = AsyncMock(return_value=[{
            "run_id": 42, "seq": 1, "task_steps": "CheckDependencies",
            "otg_dag_id": "createJob_x", "fk_dag_id": "DAG_X",
            "fk_report_id": 100, "business_date": "2026-05-30",
            "run_detail_id": 1001,
        }])
        oracle_mgr.try_claim_run = AsyncMock(return_value=False)

        dispatcher = MagicMock()
        dispatcher.execute = AsyncMock()

        poller = BackgroundPoller(
            config=cfg, oracle_manager=oracle_mgr,
            dispatcher=dispatcher, logger=MagicMock(),
        )
        await poller._poll_once()

        assert oracle_mgr.try_claim_run.await_count == 1
        assert dispatcher.execute.await_count == 0
        assert poller.stats["skipped_cross_pod"] == 1
        assert poller.stats["dispatched"] == 0


# ─── 2. BLOCKER — Spark removed, light steps present ─────────────────


class TestBF595LightStarburstSteps:
    def test_light_starburst_base_exists_and_is_spark_free(self):
        assert _exists("steps", "light_starburst_base.py"), (
            "BF-595: LightStarburstBase must exist"
        )
        src = _read("steps", "light_starburst_base.py")
        # Check ONLY non-comment, non-docstring lines for Spark imports.
        # The module docstring legitimately mentions Spark in the
        # rationale ("removed because…") — that's not a Spark import.
        import ast
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                module = getattr(node, "module", None) or ""
                names = ", ".join(n.name for n in node.names)
                assert "pyspark" not in module.lower() and "pyspark" not in names.lower(), (
                    f"BF-595: LightStarburstBase must NOT import pyspark "
                    f"(got module={module!r} names={names!r})"
                )
        # And no live `SparkSession(...)` calls.
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and getattr(node.func, "id", "") == "SparkSession":
                pytest.fail("BF-595: SparkSession(...) call in LightStarburstBase")
        assert "import trino" in src or "from trino" in src
        assert "import oracledb" in src

    def test_light_oncloud_and_onprem_exist(self):
        assert _exists("steps", "light_starburst_to_oracle_oncloud.py")
        assert _exists("steps", "light_starburst_to_oracle_onprem.py")

    def test_step_mapping_yaml_unchanged_by_lightweight_mode(self):
        """BF-596: the YAML is a pure step-name → Python-class CONTRACT.
        Lightweight mode is a dispatcher routing decision, NOT a YAML
        change.  No `createJob_light` section should exist.

        Rationale: the DB row's TASK_TYPE column drives step selection.
        A parallel YAML section would force operators to either keep
        two YAMLs in sync OR populate new step-name rows in the DB —
        neither is acceptable per user direction (2026-05-30).
        """
        m = yaml.safe_load(_read("config", "step_mapping.yaml"))
        assert "createJob_light" not in m, (
            "BF-596: createJob_light section must NOT exist — lightweight "
            "routing is done in Python via Dispatcher.LIGHTWEIGHT_STEP_SWAPS."
        )
        # The original createJob section MUST still resolve Starburst→Oracle
        # to the Spark classes — they're the default; light is the swap.
        assert m["createJob"]["StarburstToOracleOnCloud"]["class"] == "StarburstToOracle_OnCloud"


# ─── Dispatcher routing (BF-596 in-memory swap) ──────────────────────


class TestBF596DispatcherInMemorySwap:
    def test_dispatcher_constructor_accepts_use_lightweight_steps(self):
        from polling_service.dispatcher import Dispatcher
        d = Dispatcher(logger=MagicMock(), use_lightweight_steps=True)
        assert d.use_lightweight_steps is True
        d2 = Dispatcher(logger=MagicMock())
        assert d2.use_lightweight_steps is False

    def test_lightweight_step_swaps_dict_present(self):
        """BF-596: the swap mapping lives in Python code (not YAML)."""
        from polling_service.dispatcher import Dispatcher
        assert "StarburstToOracleOnCloud" in Dispatcher.LIGHTWEIGHT_STEP_SWAPS
        assert "StarburstToOracleOnPrem" in Dispatcher.LIGHTWEIGHT_STEP_SWAPS
        # Format: (module_path, class_name) tuples.
        for step, val in Dispatcher.LIGHTWEIGHT_STEP_SWAPS.items():
            assert isinstance(val, tuple) and len(val) == 2, (
                f"LIGHTWEIGHT_STEP_SWAPS[{step!r}] must be (module, class) tuple"
            )

    def test_apply_lightweight_swaps_replaces_only_known_steps(self):
        """BF-596: the swap overlay must (a) replace registered step
        classes with their Light* variants, (b) leave un-registered
        steps untouched, (c) leave steps not in the swap table alone.
        """
        from polling_service.dispatcher import Dispatcher
        d = Dispatcher(logger=MagicMock(), use_lightweight_steps=True)

        class _FakeSparkCls: pass
        class _OtherCls: pass
        step_mapping = {
            "StarburstToOracleOnCloud": _FakeSparkCls,  # SHOULD be swapped
            "StarburstToOracleOnPrem":   _FakeSparkCls,  # SHOULD be swapped
            "CheckDependencies":         _OtherCls,      # SHOULD remain
            "ProcessData":               _OtherCls,      # SHOULD remain
        }
        result = d._apply_lightweight_swaps(step_mapping)
        # Spark classes were replaced
        assert result["StarburstToOracleOnCloud"] is not _FakeSparkCls
        assert result["StarburstToOracleOnPrem"] is not _FakeSparkCls
        # Non-Starburst classes untouched
        assert result["CheckDependencies"] is _OtherCls
        assert result["ProcessData"] is _OtherCls
        # Class names verified
        assert result["StarburstToOracleOnCloud"].__name__ == "LightStarburstToOracle_OnCloud"
        assert result["StarburstToOracleOnPrem"].__name__ == "LightStarburstToOracle_OnPrem"

    def test_apply_lightweight_swaps_noop_when_step_missing(self):
        """A workflow that doesn't include Starburst→Oracle steps
        should leave the mapping completely unchanged."""
        from polling_service.dispatcher import Dispatcher
        d = Dispatcher(logger=MagicMock(), use_lightweight_steps=True)
        class _OtherCls: pass
        mapping = {"CheckDependencies": _OtherCls}
        result = d._apply_lightweight_swaps(mapping)
        assert result == {"CheckDependencies": _OtherCls}


# ─── 3. SERIOUS — thread pool executor wired ─────────────────────────


class TestBF595ThreadPoolExecutorWired:
    def test_main_creates_bounded_executor_from_config(self):
        src = _read("polling_service", "main.py")
        assert "ThreadPoolExecutor" in src
        assert "cfg.thread_pool_workers" in src
        assert "set_default_executor" in src
        assert "atexit" in src


# ─── 4. SERIOUS — per-run timeout ────────────────────────────────────


class TestBF595PerRunTimeout:
    def test_max_run_seconds_in_config(self):
        from polling_service.config import PollingServiceConfig
        c = PollingServiceConfig()
        assert hasattr(c, "max_run_seconds")
        assert c.max_run_seconds > 0

    def test_execute_run_uses_wait_for(self):
        src = _read("polling_service", "poller.py")
        idx = src.find("async def _execute_run")
        assert idx > 0
        block = src[idx:idx + 3000]
        assert "asyncio.wait_for" in block
        assert "timed_out" in src
        assert "TimeoutError" in block

    @pytest.mark.asyncio
    async def test_execute_run_times_out_and_flips_status_failed(self):
        from polling_service.poller import BackgroundPoller

        cfg = MagicMock()
        cfg.etl_connection_string = "dummy"
        cfg.dest_connection_string = "dummy"
        cfg.max_run_seconds = 1

        oracle_mgr = MagicMock()
        oracle_mgr.update_otg_etl_batch_status = AsyncMock()

        async def _hang(*a, **k):
            await asyncio.sleep(60)
        dispatcher = MagicMock()
        dispatcher.execute = _hang

        poller = BackgroundPoller(
            config=cfg, oracle_manager=oracle_mgr,
            dispatcher=dispatcher, logger=MagicMock(),
        )
        task_dict = {
            "run_id": 99, "run_detail_id": 999,
            "task_steps": "Hang", "fk_dag_id": "X",
            "fk_report_id": 1, "business_date": "2026-05-30",
        }
        await poller._execute_run(99, [task_dict], "createJob")

        assert poller.stats["timed_out"] == 1
        assert poller.stats["completed"] == 0
        oracle_mgr.update_otg_etl_batch_status.assert_awaited()
        call_args = oracle_mgr.update_otg_etl_batch_status.await_args
        # update_otg_etl_batch_status(run_id, run_detail_id, command,
        #   step_name, totalcount, error_message, connection_string)
        assert call_args.args[2] == "FAILED"
        # error_message is positional[5], not 6.
        assert "timeout" in call_args.args[5].lower()


# ─── 5. SERIOUS — polling query LIMIT ────────────────────────────────


class TestBF595PollingQueryLimit:
    def test_bg_polling_query_has_row_limit_bind(self):
        q = yaml.safe_load(_read("config", "etl_polling_task_query.yaml"))
        sql = q["bg_polling_query"]
        assert ":row_limit" in sql
        assert "ROWNUM" in sql.upper() or "FETCH FIRST" in sql.upper()

    def test_get_all_start_tasks_signature_accepts_row_limit(self):
        import inspect
        from managers.oracle_metadata_manager import OracleMetadataManager
        sig = inspect.signature(OracleMetadataManager.get_all_start_tasks)
        assert "row_limit" in sig.parameters

    def test_poller_passes_computed_row_limit(self):
        src = _read("polling_service", "poller.py")
        assert "polling_query_limit_multiplier" in src
        assert "row_limit=" in src or "row_limit =" in src


# ─── 6. SERIOUS — shutdown timeout ───────────────────────────────────


class TestBF595ShutdownTimeout:
    def test_shutdown_timeout_in_config(self):
        from polling_service.config import PollingServiceConfig
        c = PollingServiceConfig()
        assert hasattr(c, "shutdown_timeout_seconds")
        assert c.shutdown_timeout_seconds > 0

    def test_poller_run_uses_wait_for_on_shutdown_gather(self):
        src = _read("polling_service", "poller.py")
        idx = src.find("Background poller stopped")
        if idx < 0:
            idx = src.find("Shutdown timeout reached")
        assert idx > 0
        block = src[max(0, idx - 500):idx + 2000]
        assert "asyncio.wait_for" in block
        assert "shutdown_timeout_seconds" in block
        assert ".cancel()" in block


# ─── Dockerfile — Spark removed ──────────────────────────────────────


class TestBF595DockerfileSparkFree:
    def test_dockerfile_uses_slim_python_base(self):
        df = _read("Dockerfile.polling-service")
        # Strip comments before checking — the rationale comment block
        # legitimately mentions "apache/spark-py" in past tense.
        code_only = "\n".join(
            line for line in df.splitlines() if not line.strip().startswith("#")
        )
        assert "python:3.11-slim" in code_only or "python:3.12-slim" in code_only
        assert "apache/spark-py" not in code_only, (
            "BF-595: Spark base image must be gone (in non-comment lines)."
        )

    def test_dockerfile_does_not_install_pyspark(self):
        df = _read("Dockerfile.polling-service")
        # Comment containing "pyspark" is fine; pip install / ADD is not.
        for line in df.splitlines():
            s = line.strip().lower()
            if s.startswith("#") or not s:
                continue
            assert "pyspark" not in s, (
                f"BF-595: pyspark must not be installed in Dockerfile — got: {line!r}"
            )

    def test_requirements_has_no_pyspark(self):
        req = _read("requirements.txt")
        for line in req.splitlines():
            s = line.strip()
            if s.startswith("#") or not s:
                continue
            assert not s.lower().startswith("pyspark"), (
                f"BF-595: pyspark must not be in requirements.txt — got: {line!r}"
            )

    def test_dockerfile_uses_tini_for_signal_propagation(self):
        df = _read("Dockerfile.polling-service")
        assert "tini" in df
