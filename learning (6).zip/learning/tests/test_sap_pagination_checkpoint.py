"""Phase 134-K — pagination + checkpoint hardening tests.

Audit findings exercised:

  * SERIOUS #6 — _save_checkpoint writes atomically (.tmp + os.replace).
  * SERIOUS #9 — _paginated_odata_get / _paginated_odata_to_csv
    terminate on EMPTY-page OR (no-__next AND partial page).  A
    partial page WITH a __next link must continue paging.
  * SERIOUS #10 — _fetch_company_codes routes through the paginator
    instead of a single un-paginated session.get.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest


ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ── S6: atomic checkpoint write ─────────────────────────────────────


class TestCheckpointAtomicWrite:
    def _step(self):
        from steps.sap_odata_download import SapOdataDownload
        return SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def test_save_checkpoint_uses_tmp_then_replace(self, tmp_path, monkeypatch):
        step = self._step()
        replace_calls = []
        real_replace = os.replace

        def spy_replace(src, dst):
            replace_calls.append((src, dst))
            real_replace(src, dst)
        monkeypatch.setattr(os, "replace", spy_replace)

        step._save_checkpoint(str(tmp_path), 0, {
            "file_path": "/x/g0.csv", "row_count": 42, "codes": ["8129"],
        })
        # 1 replace call — from .tmp to the real path.
        assert len(replace_calls) == 1
        src, dst = replace_calls[0]
        assert src.endswith(".checkpoint.json.tmp")
        assert dst.endswith(".checkpoint.json")
        # Final file exists + parses.
        cp = json.loads((tmp_path / ".checkpoint.json").read_text())
        assert cp["completed_groups"]["0"]["row_count"] == 42
        # No leftover .tmp.
        assert not (tmp_path / ".checkpoint.json.tmp").exists()

    def test_save_checkpoint_preserves_old_on_crash(self, tmp_path, monkeypatch):
        """If the JSON-write phase throws BEFORE os.replace, the
        previous good checkpoint must remain intact.  We simulate
        the crash by making json.dump raise.
        """
        step = self._step()
        # Seed an existing good checkpoint.
        good = {"completed_groups": {"0": {"file_path": "/g0.csv",
                                              "row_count": 10,
                                              "codes": ["8129"]}}}
        (tmp_path / ".checkpoint.json").write_text(json.dumps(good))

        # Make json.dump crash on the SECOND group write so the first
        # write succeeded but the in-progress one fails.
        import json as _json
        original_dump = _json.dump
        calls = {"n": 0}

        def crash_on_second(obj, fp, **kw):
            calls["n"] += 1
            if calls["n"] >= 2:
                raise IOError("disk full")
            return original_dump(obj, fp, **kw)
        monkeypatch.setattr("steps.sap_odata_download.json.dump", crash_on_second)

        # First save succeeds.
        step._save_checkpoint(str(tmp_path), 1, {
            "file_path": "/g1.csv", "row_count": 20, "codes": ["8130"],
        })
        # Second save crashes.
        with pytest.raises(IOError):
            step._save_checkpoint(str(tmp_path), 2, {
                "file_path": "/g2.csv", "row_count": 30, "codes": ["8131"],
            })
        # The .checkpoint.json on disk should still be the result of
        # the FIRST successful save (group 0+1), NOT corrupted.
        cp = json.loads((tmp_path / ".checkpoint.json").read_text())
        assert "0" in cp["completed_groups"]
        assert "1" in cp["completed_groups"]
        assert "2" not in cp["completed_groups"]


# ── S9: pagination termination rule ─────────────────────────────────


class TestPaginationTermination:
    def _step(self):
        from steps.sap_odata_base import SapOdataBase

        class _Probe(SapOdataBase):
            async def _execute_step(self, *args, **kwargs):
                return 0

        return _Probe(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def _build_session(self, page_responses):
        """Return a MagicMock session whose .get() returns the
        pre-canned page dicts in order.  Each page dict becomes the
        `d` envelope of an OData response.
        """
        sess = MagicMock()
        responses = []
        for p in page_responses:
            r = MagicMock()
            r.raise_for_status.return_value = None
            r.json.return_value = {"d": p}
            responses.append(r)
        sess.get.side_effect = responses
        return sess

    def test_empty_page_terminates(self):
        step = self._step()
        sess = self._build_session([
            {"results": [{"k": "v1"}, {"k": "v2"}]},
            {"results": []},  # empty → done
        ])
        rows = step._paginated_odata_get(
            sess, "https://sap/x", {}, {"page_size": 10},
        )
        assert len(rows) == 2

    def test_partial_page_with_next_link_continues(self):
        """Server returned 5 rows on a $top=10 page BUT included a
        __next link → paginator must continue.  Audit SERIOUS #9
        guarded against the old ``len < top → stop`` rule.
        """
        step = self._step()
        sess = self._build_session([
            {"results": [{"i": i} for i in range(5)],
             "__next": "https://sap/x?$skip=10"},   # short BUT has __next
            {"results": [{"i": 100}], "__next": None},  # tail
            {"results": []},  # explicit end
        ])
        rows = step._paginated_odata_get(
            sess, "https://sap/x", {}, {"page_size": 10},
        )
        # 5 + 1 + 0 — pre-fix would have ended after page 0 (5 rows),
        # silently dropping the tail.
        assert len(rows) == 6

    def test_partial_page_without_next_terminates(self):
        """Server returns 5 rows on a $top=10 page AND no __next →
        terminate (no further pages).  Standard end-of-stream signal.
        """
        step = self._step()
        sess = self._build_session([
            {"results": [{"i": i} for i in range(5)]},
        ])
        rows = step._paginated_odata_get(
            sess, "https://sap/x", {}, {"page_size": 10},
        )
        assert len(rows) == 5

    def test_full_page_no_next_keeps_paging(self):
        """A full page with no __next link still triggers another
        request (the server is responding at exactly $top).  This
        is the legacy behaviour — confirmed unchanged.
        """
        step = self._step()
        sess = self._build_session([
            {"results": [{"i": i} for i in range(5)]},  # full page
            {"results": []},  # next page is empty
        ])
        rows = step._paginated_odata_get(
            sess, "https://sap/x", {}, {"page_size": 5},
        )
        assert len(rows) == 5
        assert sess.get.call_count == 2  # 2 pages fetched


# ── S10: company-code fetch is paginated ────────────────────────────


class TestCompanyCodeFetchPaginated:
    def test_fetch_company_codes_uses_paginator(self, tmp_path):
        """A tenant with > $top company codes must be returned fully,
        not silently truncated.  Verified by mocking the session +
        confirming multiple page fetches happened.
        """
        from steps.sap_odata_download import SapOdataDownload

        sess = MagicMock()
        # Two pages: first full, second empty → end-of-stream.
        page1 = MagicMock()
        page1.raise_for_status.return_value = None
        page1.json.return_value = {"d": {"results": [
            {"Companycode": f"81{i:02d}"} for i in range(5)
        ]}}
        page2 = MagicMock()
        page2.raise_for_status.return_value = None
        page2.json.return_value = {"d": {"results": []}}
        sess.get.side_effect = [page1, page2]

        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        cfg = {
            "sap_company_api": "https://sap.example.com/CompanyCodes",
            "company_code_field": "Companycode",
            "page_size": 5,
            "timeout_seconds": 60,
            "rate_limit_rps": 1000,  # effectively disabled for the test
        }
        codes = step._fetch_company_codes(sess, cfg)
        assert len(codes) == 5
        # Multi-page → at least 2 GETs (versus pre-fix: 1).
        assert sess.get.call_count >= 2
