"""Tests for the C#-to-Python history seeder."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest


ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


class TestParseLines:
    def _parse(self, *lines):
        from tools.seed_sap_group_history import parse_lines
        return parse_lines(list(lines))

    def test_eq_single_code(self):
        rows = self._parse(
            "1381312 | SAP BALANCE (GROUP21_C Eq: 8115) | 974441",
        )
        assert rows == [("8115", "8115", 974441)]

    def test_min_only_is_single(self):
        rows = self._parse(
            "1381350 | SAP BALANCE (GROUP19 Min: 7740) | 97160",
        )
        assert rows == [("7740", "7740", 97160)]

    def test_min_max_range(self):
        rows = self._parse(
            "1381355 | SAP BALANCE (GROUP23 Min: 8248 Max: 8809) | 103629",
        )
        assert rows == [("8248", "8809", 103629)]

    def test_header_and_blank_lines_skipped(self):
        rows = self._parse(
            "TASKID | TASKNAME | TOTAL_RECORD_COUNT",
            "------ | -------- | ------------------",
            "",
            "# a comment",
            "1381312 | SAP BALANCE (GROUP21_C Eq: 8115) | 974441",
        )
        assert len(rows) == 1
        assert rows[0] == ("8115", "8115", 974441)

    def test_case_insensitive(self):
        rows = self._parse(
            "9 | xxx (group11 min: 100 max: 200) | 1000",
            "9 | xxx (GROUP12 EQ: 300)            | 2000",
        )
        assert ("100", "200", 1000) in rows
        assert ("300", "300", 2000) in rows


class TestDistributeWeights:
    def test_single_code_full_weight(self):
        from tools.seed_sap_group_history import distribute_weights
        w = distribute_weights([("8115", "8115", 974441)])
        assert w == {"8115": 974441.0}

    def test_range_split_evenly(self):
        from tools.seed_sap_group_history import distribute_weights
        # 8248..8809 = 562 codes, total 103629 -> ~184.4 per code
        w = distribute_weights([("8248", "8809", 103629)])
        assert len(w) == 562
        # Total preserved (within rounding)
        assert abs(sum(w.values()) - 103629) < 1.0
        # Each entry roughly the per-code share
        per = 103629 / 562
        for v in w.values():
            assert abs(v - per) < 0.01

    def test_overlap_later_wins(self):
        from tools.seed_sap_group_history import distribute_weights
        # Two entries touching code 100: later wins
        w = distribute_weights([
            ("100", "100", 50),
            ("100", "100", 999),
        ])
        assert w["100"] == 999.0


class TestEndToEndSeed:
    def test_real_csharp_data_produces_history_with_heavies(self, tmp_path):
        """The real C# data from the user must produce a history JSON
        where 8115 and 1319 are the top-weighted codes."""
        from tools.seed_sap_group_history import (
            parse_lines, distribute_weights, build_history,
        )
        sample = [
            "1381312 | SAP BALANCE (GROUP21_C Eq: 8115) | 974441",
            "1381409 | SAP BALANCE (GROUP1 Min: 1319) | 684981",
            "1381305 | SAP BALANCE (GROUP21_B Min: 8112 Max: 8114) | 337717",
            "1381393 | SAP BALANCE (GROUP22 Min: 1320 Max: 2184) | 183267",
        ]
        rows = parse_lines(sample)
        weights = distribute_weights(rows)
        history = build_history(weights)

        # Top weight = 8115 (alone)
        top = max(weights.items(), key=lambda x: x[1])
        assert top == ("8115", 974441.0)
        # Second = 1319 (alone)
        assert weights["1319"] == 684981.0
        # Range 1320..2184 distributed; each tiny
        assert weights["1320"] < 1000  # diluted across 865 codes
        # File structure correct
        assert history["runs"][0]["source"] == "seed_from_csharp"
        assert "code_weights" in history

    def test_seeded_history_drives_weight_aware_grouping(self, tmp_path):
        """End-to-end: seed -> save -> CompanyCodeGrouper uses it ->
        heavy codes auto-isolated even WITHOUT SINGLE_CODE_LIST."""
        from tools.seed_sap_group_history import (
            parse_lines, distribute_weights, build_history,
        )
        from managers.company_code_grouper import CompanyCodeGrouper

        sample = [
            "1381312 | SAP BALANCE (GROUP21_C Eq: 8115) | 974441",
            "1381409 | SAP BALANCE (GROUP1 Min: 1319) | 684981",
            "1381393 | SAP BALANCE (GROUP22 Min: 1320 Max: 2184) | 183267",
        ]
        weights = distribute_weights(parse_lines(sample))
        history = build_history(weights)

        hp = tmp_path / "group_history.json"
        hp.write_text(json.dumps(history))

        grouper = CompanyCodeGrouper(
            history_path=str(hp),
            rows_per_group_target=500000,
        )
        # Roster: 1319 + 1320..2184 + 8115
        codes = ["1319"] + [str(c) for c in range(1320, 2185)] + ["8115"]
        groups = grouper.group_codes(codes)
        # Heavies (1319, 8115) MUST be isolated
        single_groups = [g for g in groups if len(g) == 1]
        single_codes = {g[0] for g in single_groups}
        assert "1319" in single_codes
        assert "8115" in single_codes

    def test_main_with_merge_preserves_existing(self, tmp_path):
        """--merge keeps existing code_weights, adds new ones."""
        from tools.seed_sap_group_history import main

        # Pre-existing history
        existing = {
            "runs": [{"timestamp": "old", "total_groups": 1, "total_rows": 100}],
            "code_weights": {"OLD": 100.0},
        }
        out = tmp_path / "group_history.json"
        out.write_text(json.dumps(existing))

        # Input adds new codes (numeric -- SAP codes are always digits)
        inp = tmp_path / "tasks.txt"
        inp.write_text(
            "1 | SAP BALANCE (GROUP1 Eq: 9999) | 5000\n"
        )

        rc = main([
            "--input", str(inp),
            "--output", str(out),
            "--merge",
        ])
        assert rc == 0
        merged = json.loads(out.read_text())
        assert merged["code_weights"]["OLD"] == 100.0
        assert merged["code_weights"]["9999"] == 5000.0


class TestNoStaticSeedShipped:
    """The Python pipeline must NOT depend on any C#-derived data
    checked into the repo.  The CLI seeder is operator-driven --
    they may run it if they have C# data, but we ship no static
    weights / codes / heavies anywhere."""

    def test_no_seed_json_in_configs(self):
        configs = Path(__file__).parent.parent / "configs"
        offenders = list(configs.rglob("group_history.seed.json"))
        assert not offenders, (
            f"Found static C#-derived seed files: {offenders}.  "
            f"Pipeline must build history from API runs, not from "
            f"a hardcoded JSON."
        )

    def test_no_hardcoded_company_codes_in_python(self):
        """Grep the Python source for hardcoded company codes from the
        C# data the user shared.  None should appear anywhere -- those
        codes were just REFERENCES, not seed data."""
        import re
        # Codes the user mentioned in their C# data dump
        suspicious = ["8115", "1319", "8112", "8128", "7740"]
        # Files where these codes appearing OUTSIDE tests is suspicious
        roots = [
            Path(__file__).parent.parent / "steps",
            Path(__file__).parent.parent / "managers",
            Path(__file__).parent.parent / "configs",
            Path(__file__).parent.parent / "workers",
        ]
        offenders = []
        for root in roots:
            for p in root.rglob("*"):
                if not p.is_file():
                    continue
                if p.suffix not in (".py", ".yaml", ".json"):
                    continue
                try:
                    text = p.read_text(encoding="utf-8")
                except Exception:
                    continue
                for code in suspicious:
                    # Look for the code as a quoted string -- comments
                    # in docstrings mentioning them are fine, but a
                    # quoted '8115' that COULD be code data is not.
                    pattern = rf"['\"]{code}['\"]"
                    if re.search(pattern, text):
                        offenders.append((str(p), code))
        assert not offenders, (
            f"Found hardcoded SAP company codes in source "
            f"(use polling-row config instead): {offenders}"
        )
