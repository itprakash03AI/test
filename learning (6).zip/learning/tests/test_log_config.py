"""Contract tests for ``log_config.get_log_dir()`` — the strategic
resolver introduced 2026-06-03 to replace the 9 hardcoded copies of
``/usr/local/spark/nfs/bcp/batch/logs`` across the ETL codebase.

Priority order under test:
    1. ETL_LOG_DIR env var
    2. logging.dir in polling_service_config.yaml (or a custom path
       via ETL_LOG_CONFIG_PATH)
    3. /usr/local/spark/nfs/bcp/batch/logs legacy production fallback
"""
from __future__ import annotations
import os
from pathlib import Path

import pytest

import log_config


@pytest.fixture(autouse=True)
def _reset_resolver_cache():
    """Every test starts with a clean cache so the previous test's
    resolution doesn't leak through."""
    log_config.reset_for_tests()
    yield
    log_config.reset_for_tests()


def test_env_var_wins(monkeypatch, tmp_path):
    monkeypatch.setenv("ETL_LOG_DIR", str(tmp_path))
    assert log_config.get_log_dir() == str(tmp_path)


def test_env_var_beats_yaml(monkeypatch, tmp_path):
    yaml_path = tmp_path / "polling.yaml"
    yaml_path.write_text("logging:\n  dir: C:/yaml/log/dir\n")
    monkeypatch.setenv("ETL_LOG_CONFIG_PATH", str(yaml_path))
    monkeypatch.setenv("ETL_LOG_DIR", "C:/env/var/dir")
    assert log_config.get_log_dir() == "C:/env/var/dir"


def test_yaml_used_when_env_unset(monkeypatch, tmp_path):
    yaml_path = tmp_path / "polling.yaml"
    yaml_path.write_text("logging:\n  dir: C:/yaml/log/dir\n")
    monkeypatch.delenv("ETL_LOG_DIR", raising=False)
    monkeypatch.setenv("ETL_LOG_CONFIG_PATH", str(yaml_path))
    assert log_config.get_log_dir() == "C:/yaml/log/dir"


def test_falls_back_to_legacy_when_nothing_set(monkeypatch, tmp_path):
    monkeypatch.delenv("ETL_LOG_DIR", raising=False)
    # Point ETL_LOG_CONFIG_PATH at a non-existent file so the YAML
    # branch is bypassed regardless of the dev's checkout state.
    monkeypatch.setenv(
        "ETL_LOG_CONFIG_PATH", str(tmp_path / "does_not_exist.yaml"),
    )
    assert log_config.get_log_dir() == "/usr/local/spark/nfs/bcp/batch/logs"


def test_yaml_with_legacy_value_still_falls_through(monkeypatch, tmp_path):
    """When polling_service_config.yaml carries the legacy PVC path
    (which it does by default), the resolver treats it as 'no
    explicit override' and falls through to the legacy fallback.
    This keeps the resolver consistent whether the YAML sets the
    legacy path explicitly or omits it entirely.
    """
    yaml_path = tmp_path / "polling.yaml"
    yaml_path.write_text(
        "logging:\n  dir: /usr/local/spark/nfs/bcp/batch/logs\n"
    )
    monkeypatch.delenv("ETL_LOG_DIR", raising=False)
    monkeypatch.setenv("ETL_LOG_CONFIG_PATH", str(yaml_path))
    assert log_config.get_log_dir() == "/usr/local/spark/nfs/bcp/batch/logs"


def test_cache_returns_same_value(monkeypatch, tmp_path):
    monkeypatch.setenv("ETL_LOG_DIR", str(tmp_path / "first"))
    first = log_config.get_log_dir()
    # Mutating the env after first call must NOT change the cached
    # value — every consumer in the process must see the same dir.
    monkeypatch.setenv("ETL_LOG_DIR", str(tmp_path / "second"))
    assert log_config.get_log_dir() == first


def test_reset_for_tests_picks_up_new_env(monkeypatch, tmp_path):
    monkeypatch.setenv("ETL_LOG_DIR", str(tmp_path / "first"))
    assert log_config.get_log_dir() == str(tmp_path / "first")
    log_config.reset_for_tests()
    monkeypatch.setenv("ETL_LOG_DIR", str(tmp_path / "second"))
    assert log_config.get_log_dir() == str(tmp_path / "second")


def test_all_hardcoded_sites_removed():
    """Every hardcoded copy of the legacy PVC path that was a
    bare string assignment ``LOG_DIR = "/usr/local/..."`` MUST
    now read from log_config.  Walks the ETL tree for the
    bad pattern and asserts zero matches.

    The legacy string itself is allowed inside log_config.py
    (it's the documented fallback) and in YAML comments / configs.
    """
    etl_root = Path(__file__).parent.parent
    forbidden = 'LOG_DIR = "/usr/local/spark/nfs/bcp/batch/logs'
    offenders = []
    for path in etl_root.rglob("*.py"):
        if "tests" in path.parts or "__pycache__" in path.parts:
            continue
        if path.name == "log_config.py":
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if forbidden in text:
            offenders.append(str(path.relative_to(etl_root)))
    assert not offenders, (
        f"Hardcoded LOG_DIR assignments found in {offenders}.  "
        "Replace with `from log_config import get_log_dir; "
        "LOG_DIR = get_log_dir()`."
    )
