"""Phase 134-P — tests for the s3_query ETL workflow.

Six concerns:
  1. Step classes register correctly and inherit the shared base.
  2. ``_load_and_validate_config`` enforces required fields per leaf.
  3. ``_parameterize_query`` substitutes ``{BUSINESSDATE}`` / ``{SYSTEM_ENTITY}``
     in BOTH the user query AND the s3_prefix / output_path.
  4. ``S3QueryWorker`` resolves all four leaves from step_mapping.yaml.
  5. The polling-query YAML carries the s3_query entry.
  6. The Airflow DAG file references ``s3_query_standalone.py`` and
     wires through the standard CLI args.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import yaml

ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ── 1. Step class registry + inheritance ────────────────────────────────


class TestStepClassRegistry:
    def test_four_leaf_classes_inherit_shared_base(self):
        from steps.s3_query_base import S3QueryBase
        from steps.s3_iceberg_query_extract import S3IcebergQueryExtract
        from steps.s3_parquet_query_extract import S3ParquetQueryExtract
        from steps.s3_iceberg_query_to_oracle import S3IcebergQueryToOracle
        from steps.s3_parquet_query_to_oracle import S3ParquetQueryToOracle
        for cls in (
            S3IcebergQueryExtract, S3ParquetQueryExtract,
            S3IcebergQueryToOracle, S3ParquetQueryToOracle,
        ):
            assert issubclass(cls, S3QueryBase), (
                f"{cls.__name__} must inherit S3QueryBase so it picks "
                f"up the shared Spark / S3 / pushdown helpers"
            )

    def test_iceberg_leaves_require_iceberg_table(self):
        from steps.s3_iceberg_query_extract import S3IcebergQueryExtract
        from steps.s3_iceberg_query_to_oracle import S3IcebergQueryToOracle
        for cls in (S3IcebergQueryExtract, S3IcebergQueryToOracle):
            assert "iceberg_table" in cls.REQUIRED_FIELDS

    def test_parquet_leaves_require_s3_prefix(self):
        from steps.s3_parquet_query_extract import S3ParquetQueryExtract
        from steps.s3_parquet_query_to_oracle import S3ParquetQueryToOracle
        for cls in (S3ParquetQueryExtract, S3ParquetQueryToOracle):
            assert "s3_prefix" in cls.REQUIRED_FIELDS

    def test_oracle_leaves_require_oracle_creds(self):
        from steps.s3_iceberg_query_to_oracle import S3IcebergQueryToOracle
        from steps.s3_parquet_query_to_oracle import S3ParquetQueryToOracle
        for cls in (S3IcebergQueryToOracle, S3ParquetQueryToOracle):
            for field in ("oracle_url", "oracle_user", "oracle_password"):
                assert field in cls.REQUIRED_FIELDS, (
                    f"{cls.__name__} missing {field} in REQUIRED_FIELDS"
                )

    def test_extract_leaves_require_output_path(self):
        from steps.s3_iceberg_query_extract import S3IcebergQueryExtract
        from steps.s3_parquet_query_extract import S3ParquetQueryExtract
        for cls in (S3IcebergQueryExtract, S3ParquetQueryExtract):
            assert "output_path" in cls.REQUIRED_FIELDS


# ── 2. Config validation ────────────────────────────────────────────────


class TestLoadAndValidateConfig:
    def _make_step(self, cls):
        return cls(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def test_missing_required_field_raises(self, tmp_path):
        from steps.s3_iceberg_query_extract import S3IcebergQueryExtract
        # Drop iceberg_table from the otherwise-valid config.
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({
            "s3_access_key": "k", "s3_secret_key": "s", "s3_bucket": "b",
            "query": "SELECT * FROM source",
            "output_path": str(tmp_path / "out.csv"),
        }))
        step = self._make_step(S3IcebergQueryExtract)
        with pytest.raises(ValueError, match="iceberg_table"):
            step._load_and_validate_config(
                {"sql_query_path": str(cfg_path)},
                S3IcebergQueryExtract.REQUIRED_FIELDS,
            )

    def test_valid_config_round_trips(self, tmp_path):
        from steps.s3_parquet_query_extract import S3ParquetQueryExtract
        cfg = {
            "s3_access_key": "k", "s3_secret_key": "s", "s3_bucket": "b",
            "s3_prefix": "fact/{BUSINESSDATE}/",
            "query": "SELECT * FROM source",
            "output_path": str(tmp_path / "out.csv"),
        }
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps(cfg))
        step = self._make_step(S3ParquetQueryExtract)
        loaded = step._load_and_validate_config(
            {"sql_query_path": str(cfg_path)},
            S3ParquetQueryExtract.REQUIRED_FIELDS,
        )
        for k, v in cfg.items():
            assert loaded[k] == v


# ── 2b. Deep-dive audit fixes (Phase 134-P round 2) ─────────────────────


class TestIcebergFullTableResolver:
    """Audit fix #5 — the ``startswith(catalog_name + ".")`` resolver
    matched ``iceberg_catalog2.db.tbl`` against catalog
    ``iceberg_catalog`` because string prefix matching doesn't respect
    segment boundaries.  New ``_resolve_iceberg_full_table`` splits on
    the first ``.`` and compares the first segment exactly."""

    def test_already_prefixed_passes_through(self):
        from steps.s3_query_base import S3QueryBase
        assert S3QueryBase._resolve_iceberg_full_table(
            "iceberg_catalog.db.tbl", "iceberg_catalog",
        ) == "iceberg_catalog.db.tbl"

    def test_bare_name_gets_prefixed(self):
        from steps.s3_query_base import S3QueryBase
        assert S3QueryBase._resolve_iceberg_full_table(
            "db.tbl", "iceberg_catalog",
        ) == "iceberg_catalog.db.tbl"

    def test_catalog_prefix_collision_does_not_match(self):
        """The bug: prefix match ``startswith('iceberg_catalog.')``
        accepted ``iceberg_catalog2.db.tbl`` as already-prefixed.  Fixed
        resolver does NOT — it now segment-matches."""
        from steps.s3_query_base import S3QueryBase
        assert S3QueryBase._resolve_iceberg_full_table(
            "iceberg_catalog2.db.tbl", "iceberg_catalog",
        ) == "iceberg_catalog.iceberg_catalog2.db.tbl", (
            "Different-catalog names must NOT match — the resolver "
            "must prepend the configured catalog"
        )


class TestIcebergTimeTravel:
    """Phase 134-P parity item — Spark+Iceberg supports point-in-time
    reads via ``snapshot-id`` (specific snapshot) or
    ``as-of-timestamp`` (latest snapshot <= the supplied ms timestamp).
    QS exposes both in its time-travel UI; the ETL standalone now
    surfaces them via per-task JSON config so feeds can reproduce a
    historical query."""

    def _make_step(self):
        from steps.s3_iceberg_query_extract import S3IcebergQueryExtract
        from unittest.mock import MagicMock
        return S3IcebergQueryExtract(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def _stub_spark_reader(self):
        """Build a chain of mocks tracking the ``.option`` calls so we
        can assert which time-travel option (if any) was set."""
        from unittest.mock import MagicMock
        # reader.option(k, v) → reader; reader.load(table) → df
        reader = MagicMock()
        reader.option.return_value = reader
        df = MagicMock()
        df.count.return_value = 0
        reader.load.return_value = df
        # spark.read.format("iceberg") → reader
        spark = MagicMock()
        spark.read.format.return_value = reader
        # spark.sql(query) → df-like with count
        result_df = MagicMock()
        result_df.count.return_value = 0
        spark.sql.return_value = result_df
        return spark, reader

    def test_no_options_set_when_neither_kwarg_supplied(self):
        step = self._make_step()
        spark, reader = self._stub_spark_reader()
        step._read_iceberg_with_query(
            spark=spark,
            config={
                "iceberg_table": "db.tbl",
                "iceberg_catalog_type": "rest",
                "iceberg_catalog_uri": "http://x:8181",
                "iceberg_warehouse": "s3a://b/wh",
                "query": "SELECT 1 FROM source",
            },
            task={},
        )
        # No time-travel option was set.
        for call in reader.option.call_args_list:
            key = call.args[0] if call.args else call.kwargs.get("key")
            assert key not in ("snapshot-id", "as-of-timestamp"), (
                f"unexpected time-travel option set: {key}"
            )

    def test_snapshot_id_threaded_into_spark(self):
        step = self._make_step()
        spark, reader = self._stub_spark_reader()
        step._read_iceberg_with_query(
            spark=spark,
            config={
                "iceberg_table": "db.tbl",
                "iceberg_catalog_type": "rest",
                "iceberg_catalog_uri": "http://x:8181",
                "iceberg_warehouse": "s3a://b/wh",
                "query": "SELECT 1 FROM source",
                "snapshot_id": 1234567890,
            },
            task={},
        )
        reader.option.assert_any_call("snapshot-id", "1234567890")

    def test_as_of_timestamp_ms_threaded_into_spark(self):
        step = self._make_step()
        spark, reader = self._stub_spark_reader()
        step._read_iceberg_with_query(
            spark=spark,
            config={
                "iceberg_table": "db.tbl",
                "iceberg_catalog_type": "rest",
                "iceberg_catalog_uri": "http://x:8181",
                "iceberg_warehouse": "s3a://b/wh",
                "query": "SELECT 1 FROM source",
                "as_of_timestamp_ms": 1700000000000,
            },
            task={},
        )
        reader.option.assert_any_call("as-of-timestamp", "1700000000000")

    def test_mutually_exclusive_keys_raise(self):
        step = self._make_step()
        with pytest.raises(ValueError, match="mutually exclusive"):
            step._read_iceberg_with_query(
                spark=None,
                config={
                    "iceberg_table": "db.tbl",
                    "iceberg_catalog_type": "rest",
                    "iceberg_catalog_uri": "http://x:8181",
                    "iceberg_warehouse": "s3a://b/wh",
                    "query": "SELECT 1 FROM source",
                    "snapshot_id": 1234,
                    "as_of_timestamp_ms": 1700000000000,
                },
                task={},
            )


class TestIcebergCatalogValidation:
    """Audit fix #6 — fail fast with a clear ValueError when required
    catalog wiring is missing, instead of letting Spark crash deep
    inside with an AnalysisException the user can't decode."""

    def _make_step(self):
        from steps.s3_iceberg_query_extract import S3IcebergQueryExtract
        from unittest.mock import MagicMock
        step = S3IcebergQueryExtract(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        return step

    def test_rest_catalog_requires_uri(self):
        step = self._make_step()
        # Stub spark — _read_iceberg_with_query validates BEFORE
        # touching spark, so the mock is never read.
        with pytest.raises(ValueError, match="iceberg_catalog_uri"):
            step._read_iceberg_with_query(
                spark=None,
                config={
                    "iceberg_table": "db.tbl",
                    "iceberg_catalog_type": "rest",
                    "iceberg_warehouse": "s3a://x/wh",
                    "query": "SELECT 1",
                },
                task={},
            )

    def test_rest_catalog_requires_warehouse(self):
        step = self._make_step()
        with pytest.raises(ValueError, match="iceberg_warehouse"):
            step._read_iceberg_with_query(
                spark=None,
                config={
                    "iceberg_table": "db.tbl",
                    "iceberg_catalog_type": "rest",
                    "iceberg_catalog_uri": "http://catalog:8181",
                    "query": "SELECT 1",
                },
                task={},
            )

    def test_hive_catalog_requires_uri(self):
        step = self._make_step()
        with pytest.raises(ValueError, match="iceberg_catalog_uri"):
            step._read_iceberg_with_query(
                spark=None,
                config={
                    "iceberg_table": "db.tbl",
                    "iceberg_catalog_type": "hive",
                    "query": "SELECT 1",
                },
                task={},
            )

    def test_glue_catalog_skips_uri_check(self):
        """Glue catalogues authenticate via AWS SDK — no URI / warehouse
        needed in config.  Validation must let them through."""
        step = self._make_step()
        # Will fail later (spark is None) but not on the validation step.
        with pytest.raises(Exception) as exc_info:
            step._read_iceberg_with_query(
                spark=None,
                config={
                    "iceberg_table": "db.tbl",
                    "iceberg_catalog_type": "glue",
                    "query": "SELECT 1",
                },
                task={},
            )
        msg = str(exc_info.value)
        assert "iceberg_catalog_uri" not in msg
        assert "iceberg_warehouse" not in msg


class TestFileSinkSinglePartMaterialisation:
    """Audit fix #4 — ``df.write.csv(path)`` produces a DIRECTORY of
    part files.  ``_materialise_single_part_file`` extracts the lone
    part file out of the staging directory so downstream consumers
    see a single file at the requested output_path."""

    def test_extracts_lone_part_file(self, tmp_path):
        """Happy path — one part file in staging gets moved to the
        requested output_path; staging dir is cleaned up."""
        from steps.s3_query_base import S3QueryBase
        staging = tmp_path / "out.csv.__staging__"
        staging.mkdir()
        (staging / "_SUCCESS").write_text("")
        (staging / ".part-00000-uuid.csv.crc").write_text("crc")
        (staging / "part-00000-uuid.csv").write_text("a,b\n1,2\n")
        output_path = str(tmp_path / "out.csv")
        S3QueryBase._materialise_single_part_file(
            str(staging), output_path, "csv",
        )
        assert os.path.isfile(output_path)
        assert open(output_path).read() == "a,b\n1,2\n"
        # Staging dir + sidecars are gone.
        assert not staging.exists()

    def test_raises_on_zero_part_files(self, tmp_path):
        from steps.s3_query_base import S3QueryBase
        staging = tmp_path / "out.csv.__staging__"
        staging.mkdir()
        (staging / "_SUCCESS").write_text("")  # no part-* file
        with pytest.raises(RuntimeError, match="No csv part file"):
            S3QueryBase._materialise_single_part_file(
                str(staging), str(tmp_path / "out.csv"), "csv",
            )

    def test_raises_on_multiple_part_files(self, tmp_path):
        """coalesce(1) should always produce exactly one part file —
        if Spark somehow wrote multiple we want to fail loudly, not
        silently pick the first."""
        from steps.s3_query_base import S3QueryBase
        staging = tmp_path / "out.parquet.__staging__"
        staging.mkdir()
        (staging / "part-00000-a.parquet").write_text("p1")
        (staging / "part-00001-b.parquet").write_text("p2")
        with pytest.raises(RuntimeError, match="Multiple part files"):
            S3QueryBase._materialise_single_part_file(
                str(staging), str(tmp_path / "out.parquet"), "parquet",
            )

    def test_raises_on_missing_staging_dir(self, tmp_path):
        from steps.s3_query_base import S3QueryBase
        with pytest.raises(RuntimeError, match="does not"):
            S3QueryBase._materialise_single_part_file(
                str(tmp_path / "nope.__staging__"),
                str(tmp_path / "out.csv"), "csv",
            )

    def test_overwrites_existing_output_path(self, tmp_path):
        """Per the overwrite semantic — if output_path already exists
        (rerun, restart), we replace it cleanly."""
        from steps.s3_query_base import S3QueryBase
        staging = tmp_path / "out.csv.__staging__"
        staging.mkdir()
        (staging / "part-00000-a.csv").write_text("new\n")
        output_path = tmp_path / "out.csv"
        output_path.write_text("stale\n")
        S3QueryBase._materialise_single_part_file(
            str(staging), str(output_path), "csv",
        )
        assert output_path.read_text() == "new\n"

    def test_overwrites_existing_directory_at_output_path(self, tmp_path):
        """A previous run that crashed mid-write might have left
        ``output_path`` as a half-written DIRECTORY (e.g. if a stage
        was rerun with a different output path convention).  Plain
        ``os.remove(directory)`` raises IsADirectoryError; we must
        rmtree the leftover so the rename succeeds."""
        from steps.s3_query_base import S3QueryBase
        staging = tmp_path / "out.csv.__staging__"
        staging.mkdir()
        (staging / "part-00000-a.csv").write_text("new\n")
        # Stale directory leftover at the requested output_path.
        stale_dir = tmp_path / "out.csv"
        stale_dir.mkdir()
        (stale_dir / "junk").write_text("leftover")
        S3QueryBase._materialise_single_part_file(
            str(staging), str(stale_dir), "csv",
        )
        # After materialisation, output_path is a file with the new
        # content; the stale directory is gone.
        assert os.path.isfile(stale_dir) and not os.path.isdir(stale_dir)
        assert stale_dir.read_text() == "new\n"


class TestDeliveryChainAliases:
    """Audit fix #3 — Extract steps set 3 task-dict keys so any
    delivery step (ConsolidateFiles / CompressFiles / CreateCTLFile /
    DeliverFiles) finds the output regardless of which key it reads."""

    def test_sets_all_three_aliases(self):
        from steps.s3_query_base import S3QueryBase
        task: dict = {}
        S3QueryBase._set_delivery_chain_aliases(task, "/nfs/out/x.csv")
        # Our own key.
        assert task["output_file"] == "/nfs/out/x.csv"
        # Read by CompressFiles + CreateCTLFile.
        assert task["consolidated_file"] == "/nfs/out/x.csv"
        # Read by ConsolidateFiles (5-step pipeline back-compat).
        assert task["downloaded_files"] == ["/nfs/out/x.csv"]

    def test_extract_leaves_call_aliases(self):
        """Both Extract leaves must funnel output through
        ``_set_delivery_chain_aliases`` — using plain
        ``task['output_file'] = …`` would silently leave
        consolidated_file / downloaded_files unset and break the
        delivery chain."""
        import inspect
        from steps.s3_iceberg_query_extract import S3IcebergQueryExtract
        from steps.s3_parquet_query_extract import S3ParquetQueryExtract
        for cls in (S3IcebergQueryExtract, S3ParquetQueryExtract):
            src = inspect.getsource(cls._execute_step)
            assert "_set_delivery_chain_aliases" in src, (
                f"{cls.__name__} must call _set_delivery_chain_aliases "
                f"so downstream delivery steps find the output"
            )


class TestFileSinkRejectsMultiPartition:
    """num_partitions > 1 would produce N part files, breaking the
    single-file contract.  Reject it with a clear message instead of
    silently producing a directory."""

    def test_num_partitions_two_rejected(self):
        from steps.s3_query_base import S3QueryBase
        # Subclass just to instantiate — _write_to_file validates
        # BEFORE touching spark, so we don't need a real session.
        class _Concrete(S3QueryBase):
            LOG_PREFIX = "_test"
            async def _execute_step(self, *a, **kw):
                pass
        from unittest.mock import MagicMock
        step = _Concrete(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        with pytest.raises(ValueError, match="num_partitions must be 1"):
            step._write_to_file(
                df=MagicMock(),
                config={
                    "output_path": "/tmp/x.csv",
                    "output_format": "csv",
                    "num_partitions": 2,
                },
                task={},
            )


class TestPollingServiceIntegration:
    """Audit fix #1 + #2 — the polling service must know about the
    s3_query workflow OR every polling row routes to the wrong worker
    (createJob default) and crashes with "Unsupported step name"."""

    def test_worker_registry_includes_s3_query(self):
        """Skip when pyspark is unavailable in this env — the import
        guard in dispatcher.py drops the entry on ImportError so this
        is the correct behaviour, and we already cover that branch via
        the test_pyspark_unavailable_drops_entry test below."""
        try:
            import polling_service.dispatcher as dispatcher
        except Exception as exc:
            pytest.skip(f"polling_service.dispatcher unimportable: {exc}")
        if "s3_query" not in dispatcher.WORKER_REGISTRY:
            pytest.skip(
                "s3_query not registered — likely because pyspark "
                "stub doesn't satisfy S3QueryWorker's import chain"
            )
        worker_cls, needs_starburst = dispatcher.WORKER_REGISTRY["s3_query"]
        assert worker_cls.__name__ == "S3QueryWorker"
        assert needs_starburst is False, (
            "s3_query is S3-sourced — must NOT build Starburst clients"
        )

    def test_infer_dag_type_matches_s3_query_prefix(self):
        from polling_service.poller import _infer_dag_type
        # OTG_DAG_ID with s3_query substring → s3_query.
        assert _infer_dag_type({"otg_dag_id": "S3_QUERY_RUNNER"}) == "s3_query"
        assert _infer_dag_type({"otg_dag_id": "s3query_etl"}) == "s3_query"
        # DB_CONNECTION fallback.
        assert _infer_dag_type({"otg_dag_id": "", "db_connection": "S3_QUERY_CONN"}) == "s3_query"

    def test_infer_dag_type_s3_query_matched_before_file(self):
        """``file`` is a broader substring — an OTG_DAG_ID like
        ``S3_QUERY_FILE_RUNNER`` must route to s3_query, NOT the
        legacy file workflow.  Order matters in the if-chain."""
        from polling_service.poller import _infer_dag_type
        assert _infer_dag_type(
            {"otg_dag_id": "S3_QUERY_FILE_RUNNER"},
        ) == "s3_query"

    def test_infer_dag_type_unchanged_for_existing_workflows(self):
        """Regression: existing workflows must still resolve correctly.
        Locks the existing behaviour so future audits don't trip on it."""
        from polling_service.poller import _infer_dag_type
        assert _infer_dag_type({"otg_dag_id": "SAP_MEBAL"}) == "sap_odata"
        assert _infer_dag_type({"otg_dag_id": "FILE_DELIVERY"}) == "file"
        assert _infer_dag_type({"otg_dag_id": "OTHER"}) == "createJob"


# ── 3. Placeholder substitution ─────────────────────────────────────────


class TestParameterizeQuery:
    def test_substitutes_in_query_and_paths(self):
        from steps.s3_query_base import S3QueryBase

        class _Concrete(S3QueryBase):
            LOG_PREFIX = "_test"
            async def _execute_step(self, *a, **kw):
                pass

        step = _Concrete(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "business_date": "2026-06-02",
            "system_entity": "APAC",
            "eventcode":     "SOD",
        }
        # Query
        sql = step._parameterize_query(
            "SELECT * FROM source WHERE bd='{BUSINESSDATE}' AND r='{SYSTEM_ENTITY}'",
            task,
        )
        assert "2026-06-02" in sql and "APAC" in sql and "{" not in sql

        # s3_prefix
        prefix = step._parameterize_query(
            "fact/{BUSINESSDATE}/{SYSTEM_ENTITY}/", task,
        )
        assert prefix == "fact/2026-06-02/APAC/"

        # output_path
        out = step._parameterize_query(
            "/nfs/out/{BUSINESSDATE}/extract.csv", task,
        )
        assert out == "/nfs/out/2026-06-02/extract.csv"


# ── 4. Worker resolves all four leaves ──────────────────────────────────


class TestS3QueryWorkerMapping:
    def test_worker_loads_all_four_steps(self, tmp_path):
        from workers.s3_query_worker import S3QueryWorker

        # Use the real step_mapping.yaml so the test catches drift between
        # the YAML and the Python modules — exactly the BF-pattern this
        # workflow follows everywhere else.
        mapping_path = Path(ETL_ROOT) / "config" / "step_mapping.yaml"
        worker = S3QueryWorker(
            oracle_data_manager=None,
            logger=MagicMock(),
            mapping_path=str(mapping_path),
        )
        for step in (
            "S3IcebergQueryExtract", "S3ParquetQueryExtract",
            "S3IcebergQueryToOracle", "S3ParquetQueryToOracle",
        ):
            assert step in worker.step_mapping, (
                f"step_mapping.yaml is missing the s3_query workflow "
                f"entry for {step}"
            )

    def test_worker_includes_reused_delivery_steps(self, tmp_path):
        """File-sink flows need ConsolidateFiles/CompressFiles/CreateCTLFile/
        DeliverFiles in the same workflow section so the s3_query worker
        can dispatch them too (no cross-workflow lookup)."""
        from workers.s3_query_worker import S3QueryWorker
        mapping_path = Path(ETL_ROOT) / "config" / "step_mapping.yaml"
        worker = S3QueryWorker(
            oracle_data_manager=None,
            logger=MagicMock(),
            mapping_path=str(mapping_path),
        )
        for step in (
            "ConsolidateFiles", "CompressFiles",
            "CreateCTLFile", "DeliverFiles",
            "ClearStaging",
        ):
            assert step in worker.step_mapping, (
                f"s3_query workflow must alias {step} so file-sink "
                f"pipelines can chain through to delivery"
            )

    def test_worker_raises_on_unknown_step(self, tmp_path):
        import asyncio
        from workers.s3_query_worker import S3QueryWorker
        mapping_path = Path(ETL_ROOT) / "config" / "step_mapping.yaml"
        worker = S3QueryWorker(
            oracle_data_manager=None,
            logger=MagicMock(),
            mapping_path=str(mapping_path),
        )
        with pytest.raises(ValueError, match="Unsupported step name"):
            asyncio.run(worker.execute_step({}, "", "", "NotAStep"))


# ── 5. Polling YAML ─────────────────────────────────────────────────────


class TestPollingQuery:
    def test_polling_query_s3_query_present(self):
        path = Path(ETL_ROOT) / "config" / "etl_polling_task_query.yaml"
        with open(path, "r") as f:
            queries = yaml.safe_load(f)
        assert "polling_query_s3_query" in queries, (
            "etl_polling_task_query.yaml must define polling_query_s3_query "
            "or s3_query_standalone.py blows up at start"
        )
        q = queries["polling_query_s3_query"]
        # Three positional binds and an ORDER BY RUN_ID, SEQ are the
        # minimum contract every polling query in this file honours.
        assert ":1" in q and ":2" in q and ":3" in q
        assert "ORDER BY RUN_ID, SEQ" in q
        # sql_query_path is what the per-task JSON config path comes
        # from — S3BaseStep._load_and_validate_config reads it.
        assert "sql_query_path" in q


# ── 6. Airflow DAG file ─────────────────────────────────────────────────


class TestAirflowDagFile:
    def test_dag_references_standalone_runner(self):
        dag_path = Path(ETL_ROOT) / "airflow_dag" / "s3_query_dag.py"
        assert dag_path.exists()
        src = dag_path.read_text(encoding="utf-8")
        assert "s3_query_standalone.py" in src
        # All four CLI args the runner exposes must be threaded
        # (matches Oracle standalone's --config_path contract).
        for arg in ("--report_id", "--business_date", "--dag_id", "--config_path"):
            assert arg in src, f"Airflow DAG missing {arg} arg"
        # SparkSubmitOperator is the contract for this DAG type
        # (Spark container, not KubernetesPodOperator).
        assert "SparkSubmitOperator" in src

    def test_dag_file_is_valid_python(self):
        """``ast.parse`` catches typos / unterminated strings / bad
        indents that the string-search test above can't.  Airflow
        won't load a DAG with a SyntaxError — this prevents shipping
        one."""
        import ast
        dag_path = Path(ETL_ROOT) / "airflow_dag" / "s3_query_dag.py"
        src = dag_path.read_text(encoding="utf-8")
        try:
            ast.parse(src)
        except SyntaxError as exc:
            raise AssertionError(
                f"s3_query_dag.py is not valid Python: {exc}"
            ) from exc


# ── 8. Sample per-task JSON configs ──────────────────────────────────────


class TestSampleConfigs:
    """The samples directory ships ready-to-edit JSON for each of the
    4 step classes.  Operators copy-paste these — broken samples would
    block testing.  Lock that each sample is (a) valid JSON, (b) carries
    every REQUIRED_FIELD of the step it documents, (c) declares the
    step name in its filename so the mapping is obvious."""

    SAMPLES_DIR = Path(ETL_ROOT) / "config" / "samples" / "s3_query"

    SAMPLE_TO_STEP = {
        "s3_iceberg_query_extract.example.json":   ("steps.s3_iceberg_query_extract",   "S3IcebergQueryExtract"),
        "s3_parquet_query_extract.example.json":   ("steps.s3_parquet_query_extract",   "S3ParquetQueryExtract"),
        "s3_iceberg_query_to_oracle.example.json": ("steps.s3_iceberg_query_to_oracle", "S3IcebergQueryToOracle"),
        "s3_parquet_query_to_oracle.example.json": ("steps.s3_parquet_query_to_oracle", "S3ParquetQueryToOracle"),
    }

    def test_samples_dir_exists_with_readme(self):
        assert self.SAMPLES_DIR.is_dir()
        assert (self.SAMPLES_DIR / "README.md").is_file()

    def test_every_step_has_a_sample(self):
        for filename in self.SAMPLE_TO_STEP:
            assert (self.SAMPLES_DIR / filename).is_file(), (
                f"missing sample {filename} for "
                f"{self.SAMPLE_TO_STEP[filename][1]}"
            )

    def test_samples_are_valid_json(self):
        import json
        for filename in self.SAMPLE_TO_STEP:
            content = (self.SAMPLES_DIR / filename).read_text(encoding="utf-8")
            try:
                json.loads(content)
            except json.JSONDecodeError as exc:
                raise AssertionError(
                    f"{filename} is not valid JSON: {exc}"
                ) from exc

    def test_samples_cover_step_required_fields(self):
        import importlib
        import json
        for filename, (mod_name, cls_name) in self.SAMPLE_TO_STEP.items():
            cfg = json.loads(
                (self.SAMPLES_DIR / filename).read_text(encoding="utf-8")
            )
            mod = importlib.import_module(mod_name)
            cls = getattr(mod, cls_name)
            missing = [
                f for f in cls.REQUIRED_FIELDS if f not in cfg
            ]
            assert not missing, (
                f"{filename} missing fields required by "
                f"{cls_name}: {missing}"
            )

    def test_samples_validate_via_loader(self):
        """End-to-end: the actual ``_load_and_validate_config`` helper
        that the step uses at run time must accept the sample.  Catches
        any divergence between the sample's shape and the loader's
        expectations."""
        import importlib
        from unittest.mock import MagicMock
        for filename, (mod_name, cls_name) in self.SAMPLE_TO_STEP.items():
            mod = importlib.import_module(mod_name)
            cls = getattr(mod, cls_name)
            step = cls(
                starburst_clients={}, oracle_data_manager=None,
                logger=MagicMock(), config={},
            )
            # _load_and_validate_config reads ``task['sql_query_path']``.
            loaded = step._load_and_validate_config(
                {"sql_query_path": str(self.SAMPLES_DIR / filename)},
                cls.REQUIRED_FIELDS,
            )
            assert loaded, f"loader returned falsy for {filename}"


# ── 7. Polling chain smoke test ──────────────────────────────────────────


class TestStandalonePollingChain:
    """End-to-end proof that the polling-query → DataFrame → per-step
    dispatch chain actually executes.  Mirrors ``oracle_standlone``
    structure exactly — inline polling in ``main()``, no claim, no
    skip set, lowercase-only column normalisation, ``break``-on-step-
    failure, ``task_id = run_id``.  Stubs ``OracleMetadataManager``
    and ``S3QueryWorker`` so the test runs without a real Oracle or
    Spark.
    """

    def _wire_runner(self, monkeypatch, tmp_path, fake_df,
                     config_yaml="oracle:\n"
                                  "  etl_connection_string: 'oracle://etl'\n"
                                  "  dest_connection_string: 'oracle://dest'\n"):
        """Stub Oracle + Worker, write config + queries YAMLs, neutralise
        the NFS-bound side-effect helpers.  Returns
        ``(runner_module, mgr_instance, dispatched_list, config_path)``.
        """
        from unittest.mock import AsyncMock, MagicMock

        import s3_query_standalone as runner

        mgr_instance = MagicMock()
        mgr_instance.execute_query_asynch = AsyncMock(return_value=fake_df)
        monkeypatch.setattr(
            runner, "OracleMetadataManager",
            MagicMock(return_value=mgr_instance),
        )

        dispatched: list = []

        class _StubWorker:
            def __init__(self, *args, **kwargs):
                pass

            async def execute_step(self, task, worker_conn, dest_conn, step_name):
                dispatched.append({
                    "step":             step_name,
                    "seq":              task.get("seq"),
                    "run_id":           task.get("run_id"),
                    "task_id":          task.get("task_id"),
                    "has_lower_key":    "run_id" in task,
                    "has_orig_key":     "RUN_ID" in task,
                })
                # Allow tests to raise from execute_step by checking
                # for a marker attribute on the task — used by the
                # break-on-failure test.
                if task.get("_should_raise"):
                    raise RuntimeError("simulated step failure")

        monkeypatch.setattr(runner, "S3QueryWorker", _StubWorker)

        config_path = tmp_path / "oracle_config.yaml"
        config_path.write_text(config_yaml, encoding="utf-8")
        queries_yaml = tmp_path / "etl_polling_task_query.yaml"
        queries_yaml.write_text(
            "polling_query_s3_query: |\n  SELECT 1 FROM dual\n",
            encoding="utf-8",
        )
        monkeypatch.setattr(runner, "QUERIES_PATH", str(queries_yaml))
        # NFS-bound helpers — neutralise on test machines.
        monkeypatch.setattr(runner, "cleanup_old_spark_uploads", lambda: None)
        monkeypatch.setattr(runner, "_attach_file_handler", lambda _lf: None)
        return runner, mgr_instance, dispatched, config_path

    def _run_main(self, runner, config_path,
                  report_id=42, business_date="02-06-26", dag_id="S3_TEST"):
        import asyncio
        argv_backup = sys.argv[:]
        try:
            sys.argv = [
                "s3_query_standalone",
                "--report_id",     str(report_id),
                "--business_date", business_date,
                "--dag_id",        dag_id,
                "--config_path",   str(config_path),
            ]
            asyncio.run(runner.main())
        finally:
            sys.argv = argv_backup

    def test_polling_chain_dispatches_each_seq_row(self, tmp_path, monkeypatch):
        import pandas as pd
        # NOTE: column names match what the polling query actually
        # produces — the SELECT renames TASK_TYPE AS Task_steps, so
        # the DataFrame's column is ``Task_steps``.  main()'s
        # ``{k.lower(): v for k, v in row.items()}`` normaliser
        # converts it to ``task_steps`` which is what execute_tasks
        # reads via ``task["task_steps"]``.
        fake_rows = [
            {"RUN_ID": 101, "SEQ": 1, "FK_REPORT_ID": 42, "FK_DAG_ID": "S3_TEST",
             "Task_steps": "S3IcebergQueryExtract",
             "BUSINESS_DATE": "2026-06-02", "sql_query_path": "/tmp/x.json"},
            {"RUN_ID": 101, "SEQ": 2, "FK_REPORT_ID": 42, "FK_DAG_ID": "S3_TEST",
             "Task_steps": "ConsolidateFiles",
             "BUSINESS_DATE": "2026-06-02", "sql_query_path": "/tmp/y.json"},
            {"RUN_ID": 101, "SEQ": 3, "FK_REPORT_ID": 42, "FK_DAG_ID": "S3_TEST",
             "Task_steps": "DeliverFiles",
             "BUSINESS_DATE": "2026-06-02", "sql_query_path": "/tmp/z.json"},
        ]
        fake_df = pd.DataFrame(fake_rows)

        runner, mgr_instance, dispatched, config_path = self._wire_runner(
            monkeypatch, tmp_path, fake_df,
        )
        self._run_main(runner, config_path, dag_id="S3_QUERY_TEST")

        # ── End-to-end assertions ─────────────────────────────────────
        assert mgr_instance.execute_query_asynch.await_count == 1, (
            "Polling query must be executed exactly once per standalone "
            "invocation (not once per task row)"
        )
        call_args = mgr_instance.execute_query_asynch.await_args
        binds = call_args.args[1] if len(call_args.args) >= 2 else call_args.kwargs.get("parameters")
        assert binds == {"1": 42, "2": "02-06-26", "3": "S3_QUERY_TEST"}, (
            f"Polling bind params must be positional {{1,2,3}} dict; got {binds}"
        )
        assert len(dispatched) == 3
        assert [d["step"] for d in dispatched] == [
            "S3IcebergQueryExtract", "ConsolidateFiles", "DeliverFiles",
        ], "Steps must be dispatched in SEQ order"
        assert [d["seq"] for d in dispatched] == [1, 2, 3]
        assert all(d["run_id"] == 101 for d in dispatched)
        # Oracle contract: task_id == run_id (NOT run_detail_id).
        assert all(d["task_id"] == 101 for d in dispatched), (
            "task_id must equal run_id (Oracle standalone shape, "
            "not SAP's run_detail_id-first preference)"
        )
        # Oracle contract: lowercase-only normalisation — uppercase
        # originals are dropped, not preserved.
        assert all(d["has_lower_key"] for d in dispatched)
        assert not any(d["has_orig_key"] for d in dispatched), (
            "Oracle standalone normalises to lowercase ONLY — uppercase "
            "originals must NOT leak through"
        )
        # Oracle standalone has NO claim logic — verify the runner
        # source doesn't reach for try_claim_run at all (stronger
        # than a runtime stub check because MagicMock auto-creates
        # attributes on access).
        import inspect
        src = inspect.getsource(runner)
        assert "try_claim_run" not in src, (
            "Oracle-shape standalone must not reference try_claim_run "
            "(that's SAP's pattern, not Oracle's)"
        )
        assert "runs_seen" not in src and "skipped_runs" not in src, (
            "Oracle-shape standalone must not maintain per-RUN_ID skip "
            "sets (that's SAP's pattern, not Oracle's)"
        )

    def test_break_on_step_failure_skips_rest_of_batch(self, tmp_path, monkeypatch):
        """Oracle's contract: when a step raises, the for-loop ``break``s.
        SAP's pattern was ``continue`` (skip same RUN_ID, keep going on
        sibling runs); we explicitly do NOT follow that pattern."""
        import pandas as pd
        fake_df = pd.DataFrame([
            {"RUN_ID": 1, "SEQ": 1, "FK_REPORT_ID": 42, "FK_DAG_ID": "X",
             "Task_steps": "S3IcebergQueryExtract",
             "BUSINESS_DATE": "2026-06-02", "sql_query_path": "/tmp/x.json",
             "_should_raise": True},
            {"RUN_ID": 1, "SEQ": 2, "FK_REPORT_ID": 42, "FK_DAG_ID": "X",
             "Task_steps": "ConsolidateFiles",
             "BUSINESS_DATE": "2026-06-02", "sql_query_path": "/tmp/y.json"},
            {"RUN_ID": 2, "SEQ": 1, "FK_REPORT_ID": 42, "FK_DAG_ID": "X",
             "Task_steps": "DeliverFiles",
             "BUSINESS_DATE": "2026-06-02", "sql_query_path": "/tmp/z.json"},
        ])
        runner, _mgr, dispatched, config_path = self._wire_runner(
            monkeypatch, tmp_path, fake_df,
        )
        self._run_main(runner, config_path)

        # Oracle's ``break`` exits the whole loop on the first failure
        # — SEQ 2 of RUN 1 AND SEQ 1 of RUN 2 are both skipped.
        # SAP would have run SEQ 1 of RUN 2 (different run); Oracle
        # does not.  Lock this contract.
        seqs = [(d["run_id"], d["seq"]) for d in dispatched]
        assert seqs == [(1, 1)], (
            f"Oracle-style break-on-failure: only the first SEQ should "
            f"run before the exception breaks the for-loop; got {seqs}"
        )

    def test_empty_result_short_circuits_without_dispatch(self, tmp_path, monkeypatch):
        """``if tasks_df is None or tasks_df.empty: return`` — same
        early exit Oracle does."""
        import pandas as pd
        fake_df = pd.DataFrame(columns=[
            "RUN_ID", "SEQ", "Task_steps", "FK_REPORT_ID", "FK_DAG_ID",
            "BUSINESS_DATE", "sql_query_path",
        ])
        runner, mgr_instance, dispatched, config_path = self._wire_runner(
            monkeypatch, tmp_path, fake_df,
        )
        self._run_main(runner, config_path)
        # Polling query fired, no rows came back, no dispatch happened.
        assert mgr_instance.execute_query_asynch.await_count == 1
        assert dispatched == []
