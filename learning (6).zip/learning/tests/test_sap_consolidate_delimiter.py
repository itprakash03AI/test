"""Phase 134-K — consolidator emits pipe-separated output by default,
matching the CTL template's ``csv-separator:|`` advertisement.

Also locks the mapping-aware ``_merge_parquet_files`` against
re-introduction of the duplicate (mapping-less) definition that was
silently shadowing it (audit SERIOUS #1, 2026-05-26).
"""
from __future__ import annotations

import asyncio
import inspect
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest


ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


def _make_step():
    from steps.consolidate_files import ConsolidateFiles
    return ConsolidateFiles(
        starburst_clients={}, oracle_data_manager=None,
        logger=MagicMock(), config={},
    )


def _make_input(tmp_path: Path, name: str, rows: list) -> Path:
    """Write a comma-separated per-group CSV (matches what
    ``_paginated_odata_to_csv`` produces via csv.DictWriter default).
    """
    p = tmp_path / name
    p.write_text("\n".join([",".join(r) for r in rows]) + "\n",
                 encoding="utf-8")
    return p


class TestConsolidatedDelimiter:
    """The data file must use the same delimiter the CTL declares —
    otherwise every downstream pipe-split reader mangles every row.
    Audit BLOCKER #1 (2026-05-26).
    """

    def test_output_default_is_pipe_separated(self, tmp_path):
        step = _make_step()
        f1 = _make_input(tmp_path, "g0.csv", [
            ["company_code", "amount", "currency"],
            ["8129", "1234.56", "USD"],
            ["8130", "9999.99", "GBP"],
        ])
        f2 = _make_input(tmp_path, "g1.csv", [
            ["company_code", "amount", "currency"],
            ["9000", "0", "EUR"],
        ])
        out = tmp_path / "merged.csv"
        n = step._merge_csv_files(
            [str(f1), str(f2)], str(out),
            mapping_spec=None,
            source_delim=",", output_delim="|",
        )
        assert n == 3
        body = out.read_text(encoding="utf-8")
        # Every line MUST be pipe-separated.
        for line in body.splitlines():
            if not line:
                continue
            assert "|" in line, f"line not pipe-separated: {line!r}"
            assert "," not in line, (
                f"line still contains a comma — delimiter swap failed: "
                f"{line!r}"
            )
        # Spot-check one row's exact shape.
        assert "8129|1234.56|USD" in body
        # Header is also pipe-separated.
        assert body.splitlines()[0] == "company_code|amount|currency"

    def test_writer_honours_explicit_output_delim(self, tmp_path):
        """Explicit override should win (e.g. ; for European-CSV consumers)."""
        step = _make_step()
        f1 = _make_input(tmp_path, "g0.csv", [
            ["a", "b"],
            ["1", "2"],
        ])
        out = tmp_path / "out.csv"
        step._merge_csv_files(
            [str(f1)], str(out),
            mapping_spec=None,
            source_delim=",", output_delim=";",
        )
        body = out.read_text(encoding="utf-8")
        assert "a;b" in body
        assert "1;2" in body

    def test_reader_handles_pipe_separated_sources(self, tmp_path):
        """When source files are already pipe-separated (re-run on
        already-consolidated output), the reader must honour the
        configured source delimiter — NOT silently mis-parse.
        """
        step = _make_step()
        # Pipe-separated source.
        f = tmp_path / "g0.csv"
        f.write_text(
            "company_code|amount|currency\n8129|100|USD\n",
            encoding="utf-8",
        )
        out = tmp_path / "out.csv"
        n = step._merge_csv_files(
            [str(f)], str(out),
            mapping_spec=None,
            source_delim="|", output_delim="|",
        )
        assert n == 1
        body = out.read_text(encoding="utf-8")
        # Round-trip preserves the 3 columns — if reader had used `,`
        # it would have seen one column "company_code|amount|currency"
        # and `out` would be ONE long pipe-less cell.
        first_data_line = body.splitlines()[1]
        assert first_data_line.split("|") == ["8129", "100", "USD"]


class TestRunIntegration:
    """End-to-end through ``_execute_step`` — verifies the config knob
    actually plumbs through to the writer (not just unit-level)."""

    def test_execute_step_honours_consolidated_csv_delimiter(self, tmp_path):
        step = _make_step()
        # Synthesise two per-group CSVs.
        f1 = _make_input(tmp_path, "mebal_group_0_2025_009.csv", [
            ["company_code", "amount"],
            ["8129", "1"],
        ])
        f2 = _make_input(tmp_path, "mebal_group_1_2025_009.csv", [
            ["company_code", "amount"],
            ["9000", "2"],
        ])
        cfg_path = tmp_path / "config.json"
        cfg_path.write_text(
            '{"output_dir":"%s",'
            '"consolidated_csv_delimiter":"|",'
            '"source_csv_delimiter":","}' % str(tmp_path).replace("\\", "/"),
        )
        task = {
            "sql_query_path": str(cfg_path),
            "downloaded_files": [str(f1), str(f2)],
            "output_dir": str(tmp_path),
            "p_gjahr": "2025",
            "p_poper": "009",
            "output_format": "csv",
            "log_file": str(tmp_path / "log.txt"),
        }
        n = asyncio.run(step._execute_step(
            task, worker_connection_string="",
            dest_connection_string="", step_name="ConsolidateFiles",
        ))
        assert n == 2
        out = Path(task["consolidated_file"])
        assert out.exists()
        body = out.read_text(encoding="utf-8")
        # CTL contract: csv-separator is `|`.
        assert "8129|1" in body
        assert "9000|2" in body


class TestNoDuplicateMergeParquet:
    """Audit SERIOUS #1 regression guard — there must be exactly ONE
    ``_merge_parquet_files`` definition on the class, and it must be
    the mapping-aware (5-arg-incl-self) signature.
    """

    def test_only_one_definition(self):
        from steps.consolidate_files import ConsolidateFiles
        # The class dict carries the WINNING definition; previously a
        # second def with a 3-arg signature shadowed the 4-arg one and
        # silently dropped column mapping for parquet output.
        fn = ConsolidateFiles.__dict__.get("_merge_parquet_files")
        assert fn is not None
        sig = inspect.signature(fn)
        params = list(sig.parameters.keys())
        # self, files, output_path, mapping_spec
        assert "mapping_spec" in params, (
            f"_merge_parquet_files lost mapping_spec parameter — "
            f"a duplicate definition may have been reintroduced. "
            f"params={params}"
        )

    def test_source_grep_only_one_def(self):
        """Belt-and-suspenders: text search of the source file."""
        src = (Path(__file__).parent.parent / "steps" / "consolidate_files.py")
        body = src.read_text(encoding="utf-8")
        defs = [
            ln for ln in body.splitlines()
            if ln.strip().startswith("def _merge_parquet_files(")
        ]
        assert len(defs) == 1, (
            f"expected exactly 1 def _merge_parquet_files, found {len(defs)}: "
            f"{defs}"
        )
