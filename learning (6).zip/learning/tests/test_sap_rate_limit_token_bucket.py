"""Phase 134-K — token-bucket rate limiter tests (audit SERIOUS #12).

The pre-Phase-134-K limiter serialised every request through a
single mutex + min-interval check.  Two parallel threads with
``rps=5`` would actually run at ~1 req/second AGGREGATE (the lock
wins).  Token-bucket lets up to ``rps`` requests fire concurrently
in the same window.

Tests prove:

  1. With rps=0 the limiter is a no-op (off-switch).
  2. A burst of N <= rps requests does NOT sleep.
  3. Burst > rps causes the (N - rps)th call onward to sleep.
  4. Two concurrent threads with rps=4 can fire 4 requests faster
     than a strict 1-per-200ms min-interval would allow.
  5. Re-configuring rps mid-run takes effect on the next call.
"""
from __future__ import annotations

import sys
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock

import pytest


ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


def _step():
    from steps.sap_odata_base import SapOdataBase

    class _Probe(SapOdataBase):
        async def _execute_step(self, *args, **kwargs):
            return 0

    return _Probe(
        starburst_clients={}, oracle_data_manager=None,
        logger=MagicMock(), config={},
    )


class TestTokenBucketBehaviour:
    def test_rps_zero_is_noop(self):
        s = _step()
        t0 = time.time()
        for _ in range(100):
            s._rate_limit(0)
        elapsed = time.time() - t0
        # 100 calls in well under 1s ⇒ no sleeping happened.
        assert elapsed < 0.5

    def test_burst_within_bucket_doesnt_sleep(self):
        """rps=10 → bucket capacity 10.  First 10 calls consume tokens
        instantly without sleeping.
        """
        s = _step()
        t0 = time.time()
        for _ in range(10):
            s._rate_limit(10)
        elapsed = time.time() - t0
        # 10 calls should land in < 100ms; with the old min-interval
        # limiter they'd take ~900ms.
        assert elapsed < 0.5, (
            f"burst within bucket capacity slept unexpectedly: {elapsed:.3f}s"
        )

    def test_over_burst_triggers_sleep(self):
        """rps=5 → 11 sequential calls should take ~1.2s (5 free,
        then 6 spaced at ~200ms each = ~1.2s minimum)."""
        s = _step()
        t0 = time.time()
        for _ in range(11):
            s._rate_limit(5)
        elapsed = time.time() - t0
        # Allow some slack: 11 calls with rps=5 ≈ at least (11-5)/5 = 1.2s
        assert elapsed >= 1.0, (
            f"burst of 11 at rps=5 finished too fast: {elapsed:.3f}s"
        )

    def test_concurrent_threads_share_bucket(self):
        """Two threads with rps=4: 4 total requests should finish
        in the same burst — strict per-thread min-interval limiter
        would take longer."""
        s = _step()
        # Prime so we know we start with a fresh bucket of 4 tokens.
        s._rate_limit(4)
        # Drain to baseline so the test isn't measuring the priming.
        time.sleep(1.2)

        results: list = []
        def worker():
            t0 = time.time()
            s._rate_limit(4)
            s._rate_limit(4)
            results.append(time.time() - t0)

        t1 = threading.Thread(target=worker)
        t2 = threading.Thread(target=worker)
        start = time.time()
        t1.start(); t2.start()
        t1.join(); t2.join()
        total = time.time() - start

        # 4 calls in 2 threads with rps=4 + fresh bucket should
        # complete in well under 1s (each thread fires 2 calls; the
        # bucket has 4 tokens to start, refills at 4/sec).
        assert total < 1.5, (
            f"2-thread × 2-call burst (rps=4) too slow: {total:.3f}s — "
            "old min-interval limiter would have taken ~1s+"
        )

    def test_rps_change_takes_effect_immediately(self):
        s = _step()
        # Saturate at rps=10.
        for _ in range(20):
            s._rate_limit(10)
        # Now switch to rps=1.  Bucket capacity drops; next call should
        # take ~1s if the previous run drained the new capacity.
        # (We accept either: the test verifies the *contract* — that
        # the new rps wins, not the old one.  We don't measure the
        # exact sleep duration to keep the test fast.)
        t0 = time.time()
        s._rate_limit(1)
        elapsed = time.time() - t0
        # Either the bucket carried over enough tokens (rare) or we
        # slept up to 1s.  Either way must NOT take >2s (which would
        # indicate the old rps=10 path is still active).
        assert elapsed < 2.0
