"""Phase 134 — tests for the SAP OData rewiring.

Three concerns:
  1. ``_load_and_validate_config`` overlays the polling-row SAP columns
     (SAPU / SAPP / SAP_COMPANY_API / SAP_ME_BALANCE_API) into config.
  2. ``_download_group`` substitutes {YEAR} / {MONTH} / {TIMESTAMP} /
     {min} / {max} placeholders in the SAP_ME_BALANCE_API URL.
  3. CreateCTLFile renders the canonical SAP-balance template with the
     exact key:value lines the user specified.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Make the ETL tree importable.
ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ── 1. Polling-row overlay ──────────────────────────────────────────


class TestLoadAndValidateConfig:
    def test_polling_row_overlays_config(self, tmp_path):
        """Task row columns SAPU / SAPP / SAP_COMPANY_API /
        SAP_ME_BALANCE_API should land on the config dict as
        sap_username / sap_password / sap_company_api /
        sap_me_balance_api."""
        from steps.sap_odata_download import SapOdataDownload
        # JSON config with the tuning knobs only — no creds, no URLs.
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({
            "output_dir": str(tmp_path),
            "page_size": 1000,
        }))
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "sql_query_path":      str(cfg_path),
            "SAPU":                "claude_user",
            "SAPP":                "claude_pw",
            "SAP_COMPANY_API":     "https://sap.example/CompanyCodes?$format=json",
            "SAP_ME_BALANCE_API":  ("https://sap.example/MEBAL("
                                    "p_gjahr='{YEAR}',p_poper='{MONTH}',"
                                    "p_timestamp=datetime'{TIMESTAMP}')/"
                                    "Data?$filter=Companycode+ge+'{min}'"),
        }
        cfg = step._load_and_validate_config(task, SapOdataDownload.REQUIRED_FIELDS)
        assert cfg["sap_username"]        == "claude_user"
        assert cfg["sap_password"]        == "claude_pw"
        assert cfg["sap_company_api"]     == "https://sap.example/CompanyCodes?$format=json"
        assert "{YEAR}" in cfg["sap_me_balance_api"]
        # Tuning knobs from JSON are preserved.
        assert cfg["page_size"] == 1000

    def test_missing_required_field_raises(self, tmp_path):
        from steps.sap_odata_download import SapOdataDownload
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({"output_dir": str(tmp_path)}))
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "sql_query_path": str(cfg_path),
            "SAPU":  "u",
            # SAPP intentionally missing
            "SAP_COMPANY_API":    "x",
            "SAP_ME_BALANCE_API": "y",
        }
        with pytest.raises(ValueError, match="Missing required config fields"):
            step._load_and_validate_config(
                task, SapOdataDownload.REQUIRED_FIELDS,
            )

    def test_sql_query_path_optional_when_all_required_on_row(self, tmp_path):
        """Phase 134 — sql_query_path is no longer mandatory when the
        task row carries every required field directly."""
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        # No sql_query_path; provide output_dir on the task row via
        # an explicit task-level merge (the user's flow injects this
        # via the JSON config so this scenario verifies the gate alone).
        task = {
            "SAPU": "u", "SAPP": "p",
            "SAP_COMPANY_API":    "x",
            "SAP_ME_BALANCE_API": "y",
        }
        # Missing output_dir → still raises (proves the gate works on
        # every required field, not just the ones from the row).
        with pytest.raises(ValueError, match="output_dir"):
            step._load_and_validate_config(
                task, SapOdataDownload.REQUIRED_FIELDS,
            )


# ── 2. URL placeholder substitution ─────────────────────────────────


class TestDownloadGroupUrlBuild:
    """``_download_group`` must substitute the 5 placeholders in
    SAP_ME_BALANCE_API.  We stub the paginator + filesystem so the
    test only verifies the URL that reaches the network call."""

    def _build_step(self, url_template):
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        step.logger = MagicMock()

        captured = {}

        def _fake_count(self, session, count_url, config):
            captured["count_url"] = count_url
            return 42  # group expected count

        def _fake_stream(self, session, base_url, params, config,
                         *, expected_count=None):
            captured["base_url"] = base_url
            captured["params"]   = dict(params) if params else {}
            # Yield ONE page of 42 rows so the per-group reconcile in
            # _download_group sees actual==expected and passes.
            yield 0, [{"k": i} for i in range(42)]

        step._fetch_odata_count = _fake_count.__get__(step, type(step))
        step._stream_odata_pages = _fake_stream.__get__(step, type(step))
        return step, captured

    def test_all_five_placeholders_substituted(self, tmp_path):
        step, captured = self._build_step(
            "https://sap.example/srv/MEBAL("
            "p_gjahr='{YEAR}',p_poper='{MONTH}',"
            "p_timestamp=datetime'{TIMESTAMP}')/Data"
            "?$filter=(+Companycode+ge+'{min}'+and+Companycode+le+'{max}')"
        )
        config = {
            "sap_me_balance_api": (
                "https://sap.example/srv/MEBAL("
                "p_gjahr='{YEAR}',p_poper='{MONTH}',"
                "p_timestamp=datetime'{TIMESTAMP}')/Data"
                "?$filter=(+Companycode+ge+'{min}'+and+Companycode+le+'{max}')"
            ),
            "output_dir": str(tmp_path),
        }
        result = step._download_group(
            session=MagicMock(), config=config,
            group=["1000", "1010", "1020"],
            group_idx=0, p_gjahr="2025", p_poper="009",
            output_dir=str(tmp_path),
        )
        assert result["row_count"] == 42
        url = captured["base_url"]
        # Placeholders gone, real values in.
        assert "{YEAR}"      not in url
        assert "{MONTH}"     not in url
        assert "{TIMESTAMP}" not in url
        assert "{min}"       not in url
        assert "{max}"       not in url
        assert "p_gjahr='2025'" in url
        assert "p_poper='009'" in url
        assert "Companycode+ge+'1000'" in url
        assert "Companycode+le+'1020'" in url
        # Params dict is empty — the URL carries its own $filter.
        assert captured["params"] == {}

    def test_legacy_path_still_works_when_template_missing(self, tmp_path):
        """When SAP_ME_BALANCE_API is absent, fall back to building
        the URL from sap_base_url + odata_service_path + entity_set
        (the pre-Phase-134 shape)."""
        step, captured = self._build_step("")
        config = {
            "sap_base_url":       "https://sap.example",
            "odata_service_path": "sap/opu/odata/sap/zfi_sapapi_srv",
            "entity_set":         "MEBALParameters",
            "output_dir":         str(tmp_path),
        }
        step._download_group(
            session=MagicMock(), config=config,
            group=["1000"], group_idx=0,
            p_gjahr="2025", p_poper="009",
            output_dir=str(tmp_path),
        )
        url = captured["base_url"]
        assert "MEBALParameters(p_gjahr='2025'" in url
        # Filter set on params dict (not URL) in the legacy path.
        assert "$filter" in captured["params"]


# ── 3. CTL template renders the exact user-specified format ─────────


class TestSapBalanceCtlTemplate:
    def test_polling_query_in_yaml(self):
        """polling_query_sap MUST be present in the YAML and reference
        the four SAP-specific columns by name."""
        import yaml
        path = (Path(__file__).parent.parent / "configs" /
                "etl_polling_task_query.yaml")
        cfg = yaml.safe_load(path.read_text())
        assert "polling_query_sap" in cfg, (
            "polling_query_sap missing from etl_polling_task_query.yaml")
        sql = cfg["polling_query_sap"]
        for col in ("SAP_ME_BALANCE_API", "SAP_COMPANY_API", "SAPU", "SAPP"):
            assert col in sql, f"polling_query_sap missing column {col}"
        # Same three bind variables as the sb-to-oracle / sb-to-file
        # queries so OracleMetadataManager can reuse the same call shape.
        for bind in (":1", ":2", ":3"):
            assert bind in sql, f"polling_query_sap missing bind {bind}"

    def test_step_mapping_has_sap_prefixed_keys(self):
        """All five SAP-flow steps MUST be exposed under Sap-prefixed
        keys so polling rows (TASK_TYPE='SapOdataDownload' etc.)
        dispatch correctly via SapOdataWorker."""
        import yaml
        path = (Path(__file__).parent.parent / "configs" /
                "step_mapping.yaml")
        cfg = yaml.safe_load(path.read_text())
        assert "sap_odata" in cfg
        for sap_step in (
            "SapOdataDownload", "SapConsolidateFiles", "SapCompressFiles",
            "SapCreateCTLFile", "SapDeliverFiles",
        ):
            assert sap_step in cfg["sap_odata"], (
                f"step_mapping.yaml > sap_odata missing key {sap_step!r}")

    def test_sap_workflow_has_no_unprefixed_aliases(self):
        """2026-06-03 mix-n-match guard: every step-name key inside the
        ``sap_odata`` workflow section MUST start with ``Sap``.  The
        previous back-compat aliases (ConsolidateFiles, CompressFiles,
        CreateCTLFile, DeliverFiles) silently routed non-Sap-prefixed
        TASK_TYPE values to SAP classes — that's the exact mix-n-match
        the operator forbade.  Reject any future regression.
        """
        import yaml
        path = (Path(__file__).parent.parent / "configs" /
                "step_mapping.yaml")
        cfg = yaml.safe_load(path.read_text())
        sap_keys = list(cfg.get("sap_odata", {}).keys())
        unprefixed = [k for k in sap_keys if not k.startswith("Sap")]
        assert not unprefixed, (
            f"step_mapping.yaml > sap_odata contains non-Sap-prefixed "
            f"step keys {unprefixed}.  SAP polling rows MUST use "
            f"Sap-prefixed TASK_TYPE values."
        )

    def test_sap_step_class_names_are_sap_prefixed(self):
        """Every Python class registered under the ``sap_odata``
        workflow MUST also be Sap-prefixed.  Defends against someone
        wiring a non-Sap impl into the SAP workflow.
        """
        import yaml
        path = (Path(__file__).parent.parent / "configs" /
                "step_mapping.yaml")
        cfg = yaml.safe_load(path.read_text())
        offenders = []
        for step_key, details in cfg.get("sap_odata", {}).items():
            cls_name = (details or {}).get("class", "")
            if not cls_name.startswith("Sap"):
                offenders.append(f"{step_key} → {cls_name}")
        assert not offenders, (
            f"step_mapping.yaml > sap_odata registers non-Sap-prefixed "
            f"classes: {offenders}.  SAP step classes MUST live in "
            f"steps/sap_*.py and use Sap* class names."
        )

    def test_polling_query_carries_new_per_run_columns(self):
        """polling_query_sap MUST select P_GJAHR / P_POPER /
        RUN_TIMESTAMP so polling-mode runs need ZERO CLI flags
        beyond report_id / business_date / dag_id.

        2026-06-07 -- NUM_GROUPS removed (Vw_otg_dag_task doesn't
        have it; CODES_PER_GROUP constant supersedes it).
        """
        import yaml
        path = (Path(__file__).parent.parent / "configs" /
                "etl_polling_task_query.yaml")
        cfg = yaml.safe_load(path.read_text())
        sql = cfg["polling_query_sap"]
        for col in ("P_GJAHR", "P_POPER", "RUN_TIMESTAMP", "CODES_PER_GROUP"):
            assert col in sql, (
                f"polling_query_sap missing new column {col!r} - "
                f"polling mode falls back to CLI flags without it"
            )

    def test_run_timestamp_and_num_groups_overlay_from_row(self, tmp_path):
        """NUM_GROUPS + RUN_TIMESTAMP on the polling row must overlay
        onto the config dict — same shape as the existing SAPU/SAPP
        overlay so polling mode needs no JSON edits to tune them."""
        from steps.sap_odata_download import SapOdataDownload
        cfg_path = tmp_path / "task.json"
        # JSON sets num_groups=5 (legacy default).  Row overrides to 8.
        cfg_path.write_text(json.dumps({
            "output_dir": str(tmp_path),
            "num_groups": 5,
        }))
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "sql_query_path":      str(cfg_path),
            "SAPU":                "u",
            "SAPP":                "p",
            "SAP_COMPANY_API":     "x",
            "SAP_ME_BALANCE_API":  "y",
            "NUM_GROUPS":          8,
            "RUN_TIMESTAMP":       "2026-06-03T14:30:00",
        }
        cfg = step._load_and_validate_config(
            task, SapOdataDownload.REQUIRED_FIELDS,
        )
        assert cfg["num_groups"]    == 8, "row NUM_GROUPS must win"
        assert cfg["run_timestamp"] == "2026-06-03T14:30:00"

    def test_url_uses_row_timestamp_when_present(self, tmp_path):
        """``{TIMESTAMP}`` substitution prefers config['run_timestamp']
        (which the overlay sourced from the polling row) over the
        live datetime.now() clock."""
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        config = {
            "sap_me_balance_api":
                "https://sap.example/srv/MEBAL(p_timestamp='{TIMESTAMP}')/Data",
            "output_dir":    str(tmp_path),
            "run_timestamp": "2026-06-03T14:30:00",
        }
        base_url, _params, _mn, _mx = step._build_group_url(
            config, ["1000"], "2026", "006",
        )
        assert "p_timestamp='2026-06-03T14:30:00'" in base_url

    def test_url_falls_back_to_live_clock_when_row_timestamp_missing(self, tmp_path):
        """When the polling row leaves RUN_TIMESTAMP NULL, the
        substitution falls back to the live UTC clock — same
        behaviour as before 2026-06-03."""
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        config = {
            "sap_me_balance_api":
                "https://sap.example/srv/MEBAL(p_timestamp='{TIMESTAMP}')/Data",
            "output_dir": str(tmp_path),
            # no run_timestamp
        }
        base_url, _params, _mn, _mx = step._build_group_url(
            config, ["1000"], "2026", "006",
        )
        # Live clock = ISO-8601 like '2026-06-03T14:30:00' — assert the
        # SHAPE, not the value (test runs at arbitrary clock time).
        import re
        m = re.search(r"p_timestamp='(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})'",
                      base_url)
        assert m, f"timestamp substitution missing or wrong shape: {base_url}"

    def test_standalone_is_strict_oracle_shape(self):
        """2026-06-03 — Airflow triggers ONE pod per RUN_ID for SAP,
        same as oracle.  The standalone MUST be a strict structural
        mirror of oracle_standlone.py — no 3-mode picker, no
        try_claim_run, no per-row claim tracking, no continue-on-
        failure.  Cross-pod safety lives in the polling-service
        poller (which has its own try_claim_run path), not here.
        """
        sap_src = (Path(__file__).parent.parent /
                   "sap_odata_standalone.py").read_text()
        # No DBMS_LOCK claim in standalone (oracle doesn't have it).
        assert "try_claim_run" not in sap_src, (
            "SAP standalone must not reference try_claim_run — "
            "Airflow guarantees one invocation per RUN_ID, and the "
            "polling service owns cross-pod safety separately."
        )
        # No multi-mode picker — polling mode only.  Test detects the
        # legacy argparse declarations + helper-function defs rather
        # than bare strings, so the docstring can still describe what
        # was removed without tripping the guard.
        for legacy in (
            "def _run_polling_mode", "def _run_file_mode",
            "add_argument(\"--task_id\"",
            "add_argument(\"--period_mode\"",
            "add_argument(\"--num_groups\"",
            "db_task_mode = bool", "file_mode    = bool",
        ):
            assert legacy not in sap_src, (
                f"SAP standalone must not contain {legacy!r} — "
                f"strict oracle-standalone parity (single polling mode)."
            )
        # Required oracle-shape primitives MUST be present.
        for primitive in (
            "polling_query_sap",
            "execute_query_asynch",
            "SapOdataWorker",
            "task[\"task_id\"] = task[\"run_id\"]",
            "break",  # break-on-failure inside execute_tasks loop
        ):
            assert primitive in sap_src, (
                f"SAP standalone missing oracle-shape primitive "
                f"{primitive!r}"
            )

    def test_sap_workers_do_not_load_non_sap_workflows(self):
        """SapOdataWorker.__init__ MUST hard-code workflow='sap_odata'.
        OracleWorker / S3QueryWorker MUST NOT load the sap_odata
        section.  Cross-workflow loads would re-introduce mix-n-match.
        """
        sap_src = (Path(__file__).parent.parent / "workers" /
                   "sap_odata_worker.py").read_text()
        assert "load_step_mapping('sap_odata')" in sap_src, (
            "SapOdataWorker must hard-code workflow='sap_odata'.")
        ora_src = (Path(__file__).parent.parent / "workers" /
                   "oracle_worker.py").read_text()
        assert "sap_odata" not in ora_src, (
            "OracleWorker must NOT reference sap_odata workflow.")
        s3_src = (Path(__file__).parent.parent / "workers" /
                  "s3_query_worker.py").read_text()
        assert "sap_odata" not in s3_src, (
            "S3QueryWorker must NOT reference sap_odata workflow.")

    def test_standalone_uses_polling_query_sap(self):
        """sap_odata_standalone.py MUST reference polling_query_sap (not
        the synthetic-task pattern) — the user's whole point of this
        rewrite."""
        path = Path(__file__).parent.parent / "sap_odata_standalone.py"
        src = path.read_text()
        assert "polling_query_sap" in src, (
            "sap_odata_standalone.py no longer references "
            "polling_query_sap — DB polling flow was removed?")
        assert "execute_query_asynch" in src, (
            "sap_odata_standalone.py should call "
            "OracleMetadataManager.execute_query_asynch like "
            "oracle_standlone.py does")

    def test_ctl_template_renders_all_keys(self, tmp_path):
        """End-to-end: load the canonical SAP-balance config, build a
        task with task_id + checksum + record count, render the
        template, verify every line matches the user's spec."""
        from steps.create_ctl_file import CreateCTLFile
        # Canonical template from the repo.
        cfg_path = (
            Path(__file__).parent.parent / "configs" /
            "sap_balance_ctl_template.json"
        )
        cfg = json.loads(cfg_path.read_text())
        # Build a fake data file that CreateCTLFile needs to derive
        # FILENAME from.
        data_file = tmp_path / "sapbalance_20250930.csv.gz"
        data_file.write_bytes(b"")
        cfg["output_dir"] = str(tmp_path)

        step = CreateCTLFile(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config=cfg,
        )

        # Stash the rendered template directly without going through
        # _execute_step (which is async + DB-touching).  We replicate
        # the variable map the step would have built.
        import asyncio
        # Drop in a per-task JSON config file that points to our knobs.
        per_task_cfg = tmp_path / "task.json"
        per_task_cfg.write_text(json.dumps(cfg))
        task = {
            "sql_query_path":   str(per_task_cfg),
            "consolidated_file": str(data_file),
            "totalcount":       9304512,
            "checksum":         "52FA2A1B8104FB1E4CA5E235E33FD6A2",
            "business_date":    "2025-09-30",
            "task_id":          994665,
            "output_dir":       str(tmp_path),
            "run_id":           111, "run_detail_id": 994665,
        }
        asyncio.run(step._execute_step(
            task, worker_connection_string="",
            dest_connection_string="", step_name="SapCreateCTLFile",
        ))
        ctl_path = task.get("ctl_file") or ""
        assert ctl_path, "CreateCTLFile didn't emit a ctl_file path"
        body = Path(ctl_path).read_text()
        # Verify each required line is present with the user's exact value.
        expected_lines = [
            "businessDate:2025-09-30",
            "type:sapbalance",
            "md5Checksum:52FA2A1B8104FB1E4CA5E235E33FD6A2",
            "Content-Type:text/csv",
            "dataType:sapbalance",
            "recordCount:9304512",
            "CloudCompliant:Y",
            "content-encoding:gz",
            "csv-separator:|",
            "TaskID:994665",
        ]
        for ln in expected_lines:
            assert ln in body, f"missing CTL line: {ln!r}\nGOT:\n{body}"
