# ETL JDBC JARs

Place JDBC driver JARs here for **local dev** with the polling service Docker Compose setup.

In production these JARs live on a Kubernetes PVC mounted at `/usr/local/spark/pvc/jars/`.
The `docker-compose.polling.yml` volume-mounts this directory to the same path inside the container.

## Required JARs

| JAR | Source | Required for |
|-----|--------|-------------|
| `ojdbc11.jar` | Baked into Docker image (Oracle CDN) | Oracle JDBC — all pipelines |
| `trino-jdbc-<version>.jar` | [Maven Central](https://repo1.maven.org/maven2/io/trino/trino-jdbc/) | StarburstBase steps (createJob / file dag types) |

## Getting the Trino JDBC JAR

Ask your DBA for the Trino server version, then download the matching JAR:

```bash
# Example: version 435
curl -O https://repo1.maven.org/maven2/io/trino/trino-jdbc/435/trino-jdbc-435.jar
mv trino-jdbc-435.jar ETL/jars/trino-jdbc.jar
```

Alternatively, uncomment the `ARG TRINO_JDBC_VERSION` lines in `Dockerfile.polling-service`
to bake it into the image at build time.

## Pipeline Config (`spark_jars`)

Each pipeline JSON config specifies the JARs it needs via the `spark_jars` field:

```json
{
  "spark_jars": "/opt/spark/jars/ojdbc11.jar,/usr/local/spark/pvc/jars/trino-jdbc.jar"
}
```

- `/opt/spark/jars/` — always on JVM classpath (Spark built-in dir); ojdbc11.jar lives here
- `/usr/local/spark/pvc/jars/` — PVC mount; Trino JAR and any custom JARs go here
