import asyncio
import re
import oracledb
import yaml
import logging
from typing import List, Dict, Optional
from airflow import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.models.param import Param
from airflow.models import Variable
from datetime import datetime, timedelta

logging.basicConfig(
    filename=f"/usr/local/airflow/logs/dag_genration_{datetime.now().strftime('%Y-%m-%d')}.log",
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)


def parse_oracle_connection_string(conn_str):
    match = re.match(r'^(.*); User Id = ([^;]+);Password =([^;]+);$', conn_str)
    if not match:
        raise ValueError("Invalid connection string format in db.yaml")
    dsn = match.group(1).strip()
    user = match.group(2).strip()
    password = match.group(3).strip()
    return dsn, user, password


def load_db_config(yaml_file: str = "/usr/local/spark/pvc/code/db.yaml"):
    try:
        with open(yaml_file, "r") as f:
            config = yaml.safe_load(f)
            oracle_cfg = config["oracle"]
            conn_str = oracle_cfg["etl_connection_string"]
            dsn, user, password = parse_oracle_connection_string(conn_str)
            return dsn, user, password
    except Exception as e:
        logging.error(f"Error loading db.yaml: {e}", exc_info=True)
        return None, None, None


# Spark config loader
def get_spark_confs(spark_conf_path: str, delimiter: str = ':::') -> Dict[str, str]:
    spark_conf = {
        'spark.kubernetes.driverEnv.PYTHONPATH': '/usr/local/spark/pvc:/usr/local/spark/pvc/code',
        'spark.kubernetes.executorEnv.PYTHONPATH': '/usr/local/spark/pvc:/usr/local/spark/pvc/code'
    }
    try:
        overrides = {
            'spark.kubernetes.driverEnv.SPARK_DIST_CLASSPATH': '/usr/local/spark/pvc/jars/*',
            'spark.kubernetes.executorEnv.SPARK_DIST_CLASSPATH': '/usr/local/spark/pvc/jars/*',
            'spark.kubernetes.driverEnv.PYTHONPATH': '/usr/local/spark/pvc:/usr/local/spark/pvc/code',
            'spark.kubernetes.executorEnv.PYTHONPATH': '/usr/local/spark/pvc:/usr/local/spark/pvc/code',
        }
        spark_conf = overrides.copy()
        with open(spark_conf_path) as spark_props:
            for line in spark_props:
                line = line.strip()
                if line and delimiter in line:
                    key, value = line.split(delimiter, 1)
                    key = key.strip()
                    value = value.strip()
                    # Only add if not already overridden
                    if key not in spark_conf:
                        spark_conf[key] = value
    except Exception as e:
        logging.error(f"Error reading spark properties from {spark_conf_path}: {e}")
    return spark_conf


# Default DAG arguments
def get_default_args(email: List[str]) -> Dict:
    return {
        'owner': Variable.get("dag_owner", default_var="Output Gateway"),
        'depends_on_past': False,
        'start_date': datetime(2025, 7, 14),
        'retries': 0,
        'retry_delay': timedelta(minutes=5),
        'email_on_failure': True,
        'email': email,
    }


def get_dag_configs_async(batch_size: int = 1000) -> List[Dict]:
    configs = []
    dsn, user, password = load_db_config("/usr/local/spark/pvc/code/db.yaml")
    if not all([user, password, dsn]):
        logging.error("Incomplete Oracle DB config.")
        return []

    try:
        with oracledb.connect(user=user, password=password, dsn=dsn) as connection:
            with connection.cursor() as cursor:
                # Query for DAG configurations
                query = """
                    Select DISTINCT DAG_ID, FK_REPORT_ID, DESCRIPTION,
                        SCHEDULE_INTERVAL, TAGS, FK_DEST_APPID, OTG_DAG_ID, SYSTEM_ENTITY,
                        CONFIG_PATH, LOG_FILE_PATH, SPARK_PROPERTY, SUPPORT_EMAIL_ID, EXECUTABLE_FILE, DAG_TYPE
                    from VW_OTG_DAG_Gen_CONFIG
                """
                offset = 0
                while True:
                    paginated_query = f"{query} OFFSET {offset} ROWS FETCH NEXT {batch_size} ROWS ONLY"
                    cursor.execute(paginated_query)
                    rows = cursor.fetchall()
                    if not rows:
                        break
                    columns = [col[0].lower() for col in cursor.description]
                    for row in rows:
                        row_dict = dict(zip(columns, row))
                        schedule = None if row_dict['schedule_interval'] == 'None' else row_dict['schedule_interval']
                        config = {
                            'DAG_ID': row_dict['dag_id'],
                            'FK_REPORT_ID': int(row_dict['fk_report_id']),
                            'DESCRIPTION': row_dict['description'],
                            'SCHEDULE_INTERVAL': schedule,
                            'TAGS': row_dict['tags'].split(',') if row_dict['tags'] else [],
                            'FK_DEST_APPID': int(row_dict['fk_dest_appid']),
                            'OTG_DAG_ID': row_dict['otg_dag_id'],
                            'APPLICATION_PATH': row_dict['executable_file'],
                            'CONFIG_PATH': row_dict['config_path'],
                            'SPARK_CONF_PATH': row_dict['spark_property'],
                            'EMAIL': row_dict['support_email_id'].split(',') if row_dict['support_email_id'] else ['CLAUDE#claude.c'],
                            'LOG_FILE_PATH': row_dict['log_file_path'],
                            'DAG_TYPE': row_dict['dag_type']
                        }
                        if not all([config['DAG_ID'], config['APPLICATION_PATH'], config['CONFIG_PATH']]):
                            continue
                        configs.append(config)
                    offset += batch_size
            logging.info(f"Fetched {len(configs)} valid DAG configurations")
            return configs
    except Exception as e:
        logging.error(f"Error fetching DAG configurations: {e}")
        raise


# Create a single DAG
def create_dag(config: Dict) -> Optional[DAG]:
    try:
        dag_id = config['DAG_ID']

        # Create DAG
        dag = DAG(
            dag_id=dag_id,
            default_args=get_default_args(config['EMAIL']),
            description=config['DESCRIPTION'],
            schedule_interval=config['SCHEDULE_INTERVAL'],
            catchup=False,
            is_paused_upon_creation=True,
            tags=config['TAGS'],
            params={
                'report_id': Param(
                    config['FK_REPORT_ID'],
                    type='integer',
                    description='Report ID to process'
                ),
                'business_event': Param(
                    default='SOD',
                    type='string',
                    title='Business Event ID',
                    description='Dag Instance ID to process',
                    enum=['SOD', 'EOD', 'INTRADAY'],
                    values_display={
                        'SOD': 'Start of Day',
                        'EOD': 'End of Day',
                        'INTRADAY': 'Intraday'
                    }
                ),
                'business_date': Param(
                    Variable.get("default_business_date", default_var="14-07-2025"),
                    type='string',
                    description='Business date to process (DD-MM-YYYY)'
                )
            },
            render_template_as_native_obj=True
        )

        # Define SparkSubmit task
        spark_submit_task = SparkSubmitOperator(
            task_id=config['DAG_TYPE'],
            application=config['APPLICATION_PATH'],
            conn_id=Variable.get("spark_conn_id", default_var="spark_on_prem"),
            application_args=[
                '--report_id', '"{{ params.report_id }}"',
                '--business_date', '"{{ params.business_date }}"',
                '--dag_id',
                '"{{ dag.dag_id }}'
                '{% if params.report_id == 76 and params.business_event in ["SOD", "EOD", "INTRADAY"] %}'
                '_finance_sl_balance_{{ params.business_event }}'
                '{% elif params.report_id == 77 and params.business_event in ["SOD", "EOD", "INTRADAY"] %}'
                '_finance_sl_balance_ext_{{ params.business_event }}'
                '{% endif %}"',
                '--config_path', config['CONFIG_PATH']
            ],
            conf=get_spark_confs(config['SPARK_CONF_PATH']),
            dag=dag,
        )
        logging.info(f"Created DAG: {dag_id}")
        return dag
    except Exception as e:
        logging.error(f"Error creating DAG {config.get('DAG_ID', 'unknown')}: {e}")
        return None


# DEPRECATED: This module creates one DAG per system entity (4000+ DAGs).
# Use parameterized_dags.py instead — 3 static DAGs with Dynamic Task Mapping.
# Kept for rollback only. Will be removed in a future release.
import warnings
warnings.warn(
    "dynamic_dags.py is DEPRECATED. Use parameterized_dags.py (3 DAGs with "
    "Dynamic Task Mapping) instead. This file creates 4000+ DAGs and causes "
    "Airflow scheduler overload.",
    DeprecationWarning,
    stacklevel=1,
)


def main():
    dag_configs = get_dag_configs_async(batch_size=1000)
    globals_dict = globals()
    for config in dag_configs:
        dag = create_dag(config)
        if dag:
            globals_dict[config['DAG_ID']] = dag


main()