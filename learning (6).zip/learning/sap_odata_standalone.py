"""SAP OData polling-driven entry point.

Structural clone of ``oracle_standlone.py`` / ``s3_query_standalone.py``.
Airflow triggers ONE pod per RUN_ID (--report_id + --business_date +
--dag_id); cross-pod safety is owned by the polling SERVICE (poller.py),
not the standalone — Airflow already guarantees one invocation per
RUN_ID.

Differences vs Oracle:
  * Loads ``polling_query_sap`` instead of ``polling_query_sb_to_oracle``.
  * Uses ``SapOdataWorker`` (no Starburst clients — SAP OData is the source).
  * No ``cleanup_old_spark_uploads()`` — SAP runs via KubernetesPodOperator
    in a lightweight Python pod (HTTP download), not spark-submit.

All per-row knobs (SAPU / SAPP / SAP_*_API URLs / P_GJAHR / P_POPER /
RUN_TIMESTAMP / NUM_GROUPS) live on the polling row.  The standalone
takes only the three polling-query bind values plus the oracle-config
YAML path.
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

import yaml

# Make the ETL tree importable when run as a script.
ETL_ROOT = str(Path(__file__).resolve().parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)

from log_config import get_log_dir as _get_log_dir, set_run_log_file
from managers.oracle_metadata_manager import OracleMetadataManager
from workers.sap_odata_worker import SapOdataWorker


LOG_DIR = _get_log_dir()
LOG_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# Default paths.  Prod (pod) layout first; falls back to the in-repo
# ``config/`` folder so local Windows runs work without a /usr/local/...
# mount.  CLI flags still override.
_PROD_CONFIG_PATH = "/usr/local/spark/pvc/code/configs/oracle_config.yaml"
_PROD_QUERIES_PATH = "/usr/local/spark/pvc/code/configs/etl_polling_task_query.yaml"
_LOCAL_CONFIG_PATH = os.path.join(ETL_ROOT, "configs", "oracle_config.yaml")
_LOCAL_QUERIES_PATH = os.path.join(ETL_ROOT, "configs", "etl_polling_task_query.yaml")


def _resolve_path(prod: str, local: str) -> str:
    """Return prod path if it exists, otherwise the in-repo local path."""
    return prod if os.path.exists(prod) else local

# Console-only logger at startup (file handler added after args parsed).
logger = logging.getLogger("sap_odata_standalone")
logger.setLevel(logging.INFO)
_sh = logging.StreamHandler(sys.stdout)
_sh.setFormatter(logging.Formatter(LOG_FMT))
logger.addHandler(_sh)


def _build_log_file(dag_id: str, report_id: int, business_date: str) -> str:
    """Build a log filename that identifies this batch execution.

    Format: ``sap_odata_{dag_id}_{report_id}_{business_date}_{HHMMSS}.log``
    """
    safe_dag = str(dag_id).replace("/", "_").replace("\\", "_").replace(" ", "_")[:60]
    ts = datetime.now().strftime("%H%M%S")
    safe_date = str(business_date).replace("/", "-").replace(" ", "_")[:20]
    filename = f"sap_odata_{safe_dag}_{report_id}_{safe_date}_{ts}.log"
    return os.path.join(LOG_DIR, filename)


def _attach_file_handler(log_file: str) -> None:
    """Add file handler to the module logger after we know the batch context."""
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        fh = logging.FileHandler(log_file)
        fh.setFormatter(logging.Formatter(LOG_FMT))
        logger.addHandler(fh)
        logger.info(f"Logging to: {log_file}")
    except OSError as e:
        logger.warning(f"Cannot create log file {log_file}: {e} — console only")


async def execute_tasks(
    tasks: List[Dict],
    config: Dict,
    worker_connection_string: str,
    dest_connection_string: str,
    log_file: str,
) -> None:
    """Execute all SAP OData task steps for one RUN_ID based on dynamic sequence.

    Tasks are ordered by SEQ from the polling query.  Each row is one
    step (SapOdataDownload SEQ=1, SapConsolidateFiles SEQ=2, …).  All
    tasks share the same Oracle ETL connection, so we create
    OracleMetadataManager + SapOdataWorker ONCE for the entire run.

    Mirrors ``oracle_standlone.execute_tasks`` — same loop shape, same
    ``break``-on-failure semantics, just no Starburst client setup
    because SAP OData is the source.
    """
    if not tasks or not worker_connection_string:
        raise ValueError("Tasks and worker_connection_string are required")

    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # Create SapOdataWorker ONCE — reused for all steps in this run.
    worker = SapOdataWorker(oracle_data_manager, logger)

    for task in tasks:
        task["log_file"] = log_file

        logger.info(
            f"Executing task {task.get('run_id')} with DAG_ID: {task.get('fk_dag_id')} "
            f"and FK_REPORT_ID: {task.get('fk_report_id')} for step {task.get('task_steps')} "
            f"(SEQ: {task.get('seq')})"
        )

        try:
            await worker.execute_step(
                task,
                worker_connection_string,
                dest_connection_string,
                task["task_steps"],
            )
        except Exception as e:
            logger.error(
                f"Step {task['task_steps']} for task {task['run_id']} failed: {str(e)}"
            )
            # Stop further execution for this RUN_ID — sequential steps depend on each other.
            break


async def main() -> None:
    """Main function — mirrors ``oracle_standlone.main`` exactly."""
    parser = argparse.ArgumentParser(
        description="Execute a SAP OData task for a specific report ID and business date.",
    )
    parser.add_argument(
        "--report_id", type=int, required=True,
        help="The report ID to process.",
    )
    parser.add_argument(
        "--business_date", type=str, required=True,
        help='The business date to process (e.g., "2025-07-10").',
    )
    parser.add_argument(
        "--dag_id", type=str, required=True,
        help="The DAG ID to process.",
    )
    parser.add_argument(
        "--config_path", type=str,
        default=_resolve_path(_PROD_CONFIG_PATH, _LOCAL_CONFIG_PATH),
        help="Path to the configuration file.",
    )
    parser.add_argument(
        "--queries_path", type=str,
        default=_resolve_path(_PROD_QUERIES_PATH, _LOCAL_QUERIES_PATH),
        help="Path to etl_polling_task_query.yaml.",
    )

    args = parser.parse_args()

    log_file = _build_log_file(args.dag_id, args.report_id, args.business_date)
    _attach_file_handler(log_file)
    # Pin EVERY build_module_logger() call (oracle_metadata_manager,
    # step_executor, …) to this exact file so the whole run lives in
    # one log file end-to-end.
    set_run_log_file(log_file)

    logger.info(
        f"Starting SAP OData batch: dag_id={args.dag_id}, "
        f"report_id={args.report_id}, business_date={args.business_date}"
    )

    # Load configuration
    config_path = args.config_path
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    if not config or "oracle" not in config:
        raise ValueError("Invalid configuration file: missing 'oracle' section")

    # Load queries from YAML
    queries_path = args.queries_path
    if not os.path.exists(queries_path):
        raise FileNotFoundError(f"Queries file not found: {queries_path}")

    with open(queries_path, "r") as qf:
        queries = yaml.safe_load(qf)

    if "polling_query_sap" not in queries:
        raise ValueError(
            "polling_query_sap not found in etl_polling_task_query.yaml"
        )

    # Establish database connections.  dest_connection_string is optional
    # for SAP (no SAP step writes to a destination Oracle); kept as a
    # positional arg for interface parity with OracleWorker.execute_step.
    worker_connection_string = config["oracle"]["etl_connection_string"]
    dest_connection_string = config["oracle"].get("dest_connection_string", "")

    # Fetch all tasks from database using OracleMetadataManager
    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # execute_query_asynch returns a DataFrame — convert to list of dicts
    tasks_df = await oracle_data_manager.execute_query_asynch(
        queries["polling_query_sap"],
        {
            "1": args.report_id,
            "2": args.business_date,
            "3": args.dag_id,
        },
        worker_connection_string,
    )

    if tasks_df is None or tasks_df.empty:
        logger.info(
            f"No tasks found for report_id {args.report_id}, "
            f"business_date {args.business_date}, dag_id {args.dag_id}"
        )
        return

    # Convert DataFrame rows to list of dicts for downstream consumption
    tasks = tasks_df.to_dict(orient='records')

    # Normalize column names to lowercase for consistent access
    tasks = [{k.lower(): v for k, v in row.items()} for row in tasks]

    # Normalize tasks
    for task in tasks:
        task["task_id"] = task["run_id"]
        task["dag_run_id"] = f"run_{task['run_id']}"

    await execute_tasks(
        tasks, config, worker_connection_string, dest_connection_string, log_file,
    )


if __name__ == "__main__":
    asyncio.run(main())
