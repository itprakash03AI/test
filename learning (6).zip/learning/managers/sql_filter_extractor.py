"""Phase 134-P (supplement pruning) — extract per-column predicates
from a raw SQL ``WHERE`` clause.

This is the Spark-side counterpart to QueryStudio's
``backend/core/sql_partition_extractor.py`` — kept intentionally
separate (no backend import) so the ETL container stays decoupled
from the QS backend.  The two extractors target the same SQL idioms
but neither implementation references the other.

What gets extracted
===================

Simple binary comparisons:

  * ``col = value``      → ``("=", value)``
  * ``col != value``     → ``("!=", value)``
  * ``col > value``      → ``(">", value)``
  * ``col >= value``     → ``(">=", value)``
  * ``col < value``      → ``("<", value)``
  * ``col <= value``     → ``("<=", value)``

``BETWEEN``:

  * ``col BETWEEN a AND b``   → ``(">=", a)`` + ``("<=", b)``

``IN``:

  * ``col IN (v1, v2, …)``    → ``("in", [v1, v2, …])``

What is intentionally NOT extracted
====================================

The supplement pruner consumes simple per-column bounds, so anything
more complex than the above is dropped from extraction (the user's
WHERE still runs server-side via Spark — we just don't use it for
file-level pruning).

  * Subqueries (``IN (SELECT …)``) — Spark handles via subquery broadcast
  * Function calls (``UPPER(col) = 'X'``) — bound predicates only
  * OR within a single predicate — supplement pruning is conservative
  * NULL checks — supplement tracks null_count separately
  * LIKE / regex — not bound-friendly

Multi-column AND
================

Top-level AND is supported — each conjunct that matches one of the
simple shapes above is extracted independently.  A query mixing
extractable + non-extractable predicates extracts the supported ones
and lets Spark handle the rest.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Tuple


logger = logging.getLogger(__name__)


def extract_predicates(sql: str) -> Dict[str, List[Tuple[str, Any]]]:
    """Parse ``sql``'s WHERE clause and return per-column predicates.

    Returns ``{column_name: [(op, value), …]}``.  Returns an empty
    dict when:

      * sqlglot is not installed (caller falls back to no pruning)
      * The SQL has no WHERE clause
      * The WHERE clause has no extractable predicates
    """
    if not sql:
        return {}
    try:
        import sqlglot
        import sqlglot.expressions as exp
    except ImportError:
        logger.warning(
            "sqlglot not installed — supplement pruning disabled, "
            "falling back to standard Spark+Iceberg path"
        )
        return {}

    try:
        parsed = sqlglot.parse_one(sql, read="spark")
    except Exception as exc:
        logger.warning(f"sqlglot failed to parse SQL: {exc}")
        return {}

    where = parsed.find(exp.Where)
    if not where:
        return {}

    predicates: Dict[str, List[Tuple[str, Any]]] = {}
    _walk_and(where.this, predicates)
    return predicates


# ── Internals ───────────────────────────────────────────────────────────


def _walk_and(node, predicates: Dict[str, List[Tuple[str, Any]]]) -> None:
    """Recursively walk top-level AND conjuncts and dispatch each leaf
    to ``_extract_one``.  Anything that isn't a simple binary / IN /
    BETWEEN comparison gets silently skipped (Spark still evaluates
    it server-side — we just don't use it for pruning).
    """
    import sqlglot.expressions as exp
    if isinstance(node, exp.And):
        _walk_and(node.left, predicates)
        _walk_and(node.right, predicates)
        return
    _extract_one(node, predicates)


def _extract_one(node, predicates: Dict[str, List[Tuple[str, Any]]]) -> None:
    """Try every supported shape on ``node``; bail silently if none
    match (the predicate is too complex for supplement pruning).
    """
    import sqlglot.expressions as exp

    # Binary comparison: col OP value (or value OP col).
    _BINARY_OPS = {
        exp.EQ: "=",
        exp.NEQ: "!=",
        exp.GT: ">",
        exp.GTE: ">=",
        exp.LT: "<",
        exp.LTE: "<=",
    }
    for cls, op in _BINARY_OPS.items():
        if isinstance(node, cls):
            col, val, col_was_on_right = _resolve_col_value(node.left, node.right)
            if col is not None and val is not None:
                # When the column was on the RIGHT (e.g. ``100 < col``),
                # flip the operator so the predicate reads as col-first
                # (``col > 100``).
                if col_was_on_right:
                    op = _flip_op(op)
                predicates.setdefault(col, []).append((op, _literal_value(val)))
            return

    # BETWEEN: col BETWEEN low AND high → col >= low AND col <= high
    if isinstance(node, exp.Between):
        col = _column_name(node.this)
        low = _literal_value(node.args.get("low"))
        high = _literal_value(node.args.get("high"))
        if col is not None and low is not None and high is not None:
            predicates.setdefault(col, []).append((">=", low))
            predicates.setdefault(col, []).append(("<=", high))
        return

    # IN: col IN (v1, v2, …) — only when every list entry is a literal.
    if isinstance(node, exp.In):
        col = _column_name(node.this)
        expressions = node.args.get("expressions") or []
        if col is None or not expressions:
            return
        values: List[Any] = []
        for e in expressions:
            v = _literal_value(e)
            if v is None:
                return  # subquery or non-literal — bail entirely
            values.append(v)
        predicates.setdefault(col, []).append(("in", values))
        return

    # Anything else (OR, NOT, function call, subquery) — silently skip.


def _resolve_col_value(left, right):
    """Identify which side is the column and which is the literal.

    Returns ``(column_name, value_node, col_was_on_right)`` or
    ``(None, None, False)`` when neither side is a bare column or
    the other side isn't a literal.  ``col_was_on_right`` lets the
    caller flip the operator so the predicate always reads
    column-first.
    """
    left_col = _column_name(left)
    right_col = _column_name(right)
    if left_col is not None and right_col is None:
        return left_col, right, False
    if right_col is not None and left_col is None:
        return right_col, left, True
    return None, None, False


def _column_name(node) -> str:
    """Return the lowercased column name when ``node`` is a bare column
    reference (``col`` or ``tbl.col``); ``None`` otherwise.
    """
    import sqlglot.expressions as exp
    if isinstance(node, exp.Column):
        return node.name.lower() if node.name else None
    return None


def _literal_value(node) -> Any:
    """Extract a Python literal from a sqlglot Literal node.  ``None``
    for non-literals (subqueries, function calls, columns).  Numeric
    literals come back as int/float; strings come back unquoted.
    """
    import sqlglot.expressions as exp
    if isinstance(node, exp.Literal):
        s = node.this  # the raw string value
        if node.is_number:
            try:
                return int(s)
            except ValueError:
                try:
                    return float(s)
                except ValueError:
                    return s
        return s
    if isinstance(node, exp.Boolean):
        return bool(node.this)
    if isinstance(node, exp.Null):
        return None
    return None


def _flip_op(op: str) -> str:
    """Flip a binary comparison so the column reads as the left side."""
    flipped = {">": "<", ">=": "<=", "<": ">", "<=": ">="}
    return flipped.get(op, op)
