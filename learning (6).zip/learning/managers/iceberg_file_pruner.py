"""Phase 134-P (supplement pruning) — file-level pruning for iceberg
reads, combining manifest bounds + QS supplement bounds + the user's
WHERE-clause predicates.

Given a list of data files (each with manifest-extracted lower/upper
bounds per column) and a set of predicates extracted from the user's
WHERE, this module returns the subset of files that COULD match.

Always conservative: if we can't prove a file is excluded, it stays
in the result.  False positives (keeping a file that won't actually
have matching rows) are harmless — the row-level filter on the
Spark read drops them.  False negatives (dropping a file that
WOULD have matched) are correctness bugs and must not happen.

Comparison semantics
====================

Bound values arrive from manifest / supplement as strings.  The
user's filter values arrive from sqlglot as Python int / float /
str.  ``_coerce_for_compare`` walks both to a common comparable
shape:

  * Integer + numeric string                       → both int
  * Float + numeric string                         → both float
  * Anything that can't be coerced compatibly      → string compare
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple


logger = logging.getLogger(__name__)


# (lower_bound, upper_bound, null_count, row_count) — both bound strings
# nullable.
FileBounds = Tuple[Optional[str], Optional[str], int, int]


def prune_files(
    files: Iterable[str],
    manifest_bounds: Dict[str, Dict[str, FileBounds]],
    supplement_bounds: Dict[str, Dict[str, FileBounds]],
    predicates: Dict[str, List[Tuple[str, Any]]],
) -> List[str]:
    """Return the subset of ``files`` whose bounds permit at least one
    row matching every predicate.

    Args:
        files: candidate iceberg data file paths.
        manifest_bounds: ``{column: {file_path: (low, high, nulls, rows)}}``
            built from iceberg manifest stats.
        supplement_bounds: same shape, sourced from
            ``iceberg_column_stats_supplement_v2``.  Used to augment
            ``manifest_bounds`` — supplement values OVERRIDE manifest
            values for the same (file, column) pair only when manifest
            bounds are missing or NULL.
        predicates: per-column predicate list from
            ``sql_filter_extractor.extract_predicates``.

    Returns:
        Sorted list of files that survived pruning.  Empty list means
        the WHERE has no matches — caller can short-circuit the scan.
    """
    file_list = list(files)
    if not predicates:
        return sorted(file_list)
    if not file_list:
        return []

    # Per-file × per-column bound resolver: prefer manifest, fall back
    # to supplement when manifest is missing or has NULL bounds.
    def _bounds_for(col: str, fp: str) -> FileBounds:
        m_col = manifest_bounds.get(col, {})
        s_col = supplement_bounds.get(col, {})
        m = m_col.get(fp)
        s = s_col.get(fp)
        if m is None and s is None:
            return (None, None, 0, 0)
        if m is None:
            return s
        if s is None:
            return m
        # Both present — manifest wins UNLESS its bounds are NULL.
        m_low, m_high, m_null, m_rows = m
        s_low, s_high, _s_null, _s_rows = s
        return (
            m_low if m_low is not None else s_low,
            m_high if m_high is not None else s_high,
            m_null, m_rows,
        )

    survivors: List[str] = []
    for fp in file_list:
        if _file_could_match(fp, predicates, _bounds_for):
            survivors.append(fp)
    return sorted(survivors)


# ── Internals ───────────────────────────────────────────────────────────


def _file_could_match(
    file_path: str,
    predicates: Dict[str, List[Tuple[str, Any]]],
    bounds_resolver,
) -> bool:
    """A file could match iff every column's predicates are individually
    satisfiable against that file's bounds.  Any column that conclusively
    excludes the file fails the whole file.
    """
    for col, col_predicates in predicates.items():
        low_str, high_str, _nulls, _rows = bounds_resolver(col, file_path)
        if low_str is None and high_str is None:
            # No bounds for this column on this file — can't exclude.
            continue
        for op, val in col_predicates:
            if _predicate_excludes_file(op, val, low_str, high_str):
                return False
    return True


def _predicate_excludes_file(
    op: str,
    val: Any,
    low_str: Optional[str],
    high_str: Optional[str],
) -> bool:
    """Return True iff the (op, val) predicate CANNOT match any row in a
    file with bounds [low_str, high_str].  Conservative: missing bounds
    or coercion failure returns False (= "keep the file").
    """
    if op == "in":
        if not isinstance(val, list) or not val:
            return False
        # An IN clause excludes only when EVERY value falls outside
        # [low, high].  Conservative: if even one value could match,
        # keep the file.
        return all(
            _predicate_excludes_file("=", v, low_str, high_str)
            for v in val
        )

    low, high = _coerce_bounds(low_str, high_str, val)
    if low is None and high is None:
        return False

    try:
        if op == "=" and low is not None and high is not None:
            return val < low or val > high
        if op == "!=" and low is not None and high is not None:
            # Excludes only when bounds collapse to exactly val.
            return low == high == val
        if op == ">":
            return high is not None and val >= high
        if op == ">=":
            return high is not None and val > high
        if op == "<":
            return low is not None and val <= low
        if op == "<=":
            return low is not None and val < low
    except TypeError:
        # Cross-type compare (e.g. int vs str) — can't prove exclusion.
        return False
    return False


def _coerce_bounds(
    low_str: Optional[str],
    high_str: Optional[str],
    val: Any,
) -> Tuple[Optional[Any], Optional[Any]]:
    """Coerce string bounds to the same type as the comparison value
    when safe.  Returns ``(low, high)`` — either may be None if the
    original bound was None.
    """
    def _coerce(s: Optional[str]) -> Optional[Any]:
        if s is None:
            return None
        if isinstance(val, bool):
            # bool BEFORE int — Python bool subclasses int.
            sl = s.strip().lower()
            if sl in ("true", "1", "yes"): return True
            if sl in ("false", "0", "no"): return False
            return s
        if isinstance(val, int):
            try:
                return int(s)
            except ValueError:
                return None
        if isinstance(val, float):
            try:
                return float(s)
            except ValueError:
                return None
        # Default: string compare.
        return s

    low = _coerce(low_str)
    high = _coerce(high_str)
    return low, high
