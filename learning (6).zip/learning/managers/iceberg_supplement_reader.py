"""Phase 134-P (supplement pruning) — read QueryStudio's
``iceberg_column_stats_supplement_v2`` table from inside the ETL
Spark container.

QS scans iceberg snapshots in the background and persists per-file
column min/max/null counts to a supplement table keyed on
``(bucket, table_prefix, snapshot_id, file_path, column_name)``.
The standalone iceberg-via-Spark path normally has access only to
column bounds Iceberg writers emit in manifests; this reader makes
the QS-scanned supplement bounds available too, so file-level
pruning is possible on columns lacking manifest bounds.

Decoupling
==========

This module imports from ``oracledb`` ONLY — no SQLAlchemy, no
backend coupling.  When the QS DB is something other than Oracle
(SQLite for dev / Postgres for newer deploys), the operator points
``querystudio_db_*`` config at an Oracle-protocol equivalent or
disables supplement pruning via ``use_supplement_pruning: false``.
A future session can add Postgres support via a thin connector
abstraction; for now Oracle-only matches QS's production deployment.

Schema (from backend/core/db/models.py:1060)
============================================
::

  CREATE TABLE iceberg_column_stats_supplement_v2 (
      id            INTEGER PRIMARY KEY,
      bucket        VARCHAR(255)  NOT NULL,
      table_prefix  VARCHAR(512)  NOT NULL,
      snapshot_id   VARCHAR(64)   NOT NULL,
      file_path     VARCHAR(1024) NOT NULL,
      column_name   VARCHAR(255)  NOT NULL,
      connection_id INTEGER       NULL,
      table_name    VARCHAR(255)  NULL,
      lower_bound   VARCHAR(512)  NULL,
      upper_bound   VARCHAR(512)  NULL,
      null_count    BIGINT        DEFAULT 0,
      row_count     BIGINT        DEFAULT 0,
      scanned_at    TIMESTAMP
  );

  -- Indexed by (bucket, table_prefix, snapshot_id, column_name) so
  -- the per-column range-scan below is O(matching rows).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple


logger = logging.getLogger(__name__)


_SELECT_BY_COLUMN_SQL = """
    SELECT file_path, lower_bound, upper_bound, null_count, row_count
      FROM iceberg_column_stats_supplement_v2
     WHERE bucket = :1
       AND table_prefix = :2
       AND snapshot_id = :3
       AND column_name = :4
"""


class IcebergSupplementReader:
    """Per-(bucket, table_prefix, snapshot_id) supplement-bound reader.

    Instantiate once per Spark job, then call ``bounds_for(column)``
    on each column the WHERE clause references.  Results cached
    in-memory for the lifetime of the reader so a multi-predicate
    query queries the DB at most ``N_filter_columns`` times.

    Fail-OPEN: any error reading the supplement (driver missing,
    connection refused, table missing, query timeout) returns an
    empty dict — caller falls back to using only manifest bounds.
    """

    def __init__(
        self,
        connection_string: str,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
    ):
        self._conn_str = connection_string
        self._bucket = bucket or ""
        self._table_prefix = table_prefix or ""
        self._snapshot_id = str(snapshot_id) if snapshot_id is not None else ""
        # column_name (lowercased) → {file_path: (lower, upper, nulls, rows)}
        self._cache: Dict[str, Dict[str, Tuple[Optional[str], Optional[str], int, int]]] = {}

    def bounds_for(self, column_name: str) -> Dict[str, Tuple[Optional[str], Optional[str], int, int]]:
        """Return ``{file_path: (lower_bound, upper_bound, null_count, row_count)}``
        for the supplement rows matching this reader's identity tuple
        and the given column.

        Empty dict on missing config, driver, or query failure —
        caller treats absence as "use manifest bounds only".
        """
        if not (self._conn_str and self._bucket and self._snapshot_id):
            return {}
        key = column_name.lower()
        if key in self._cache:
            return self._cache[key]

        try:
            import oracledb
        except ImportError:
            logger.warning(
                "oracledb not installed — supplement pruning disabled, "
                "falling back to manifest bounds only"
            )
            self._cache[key] = {}
            return {}

        rows: Dict[str, Tuple[Optional[str], Optional[str], int, int]] = {}
        try:
            with oracledb.connect(self._conn_str) as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        _SELECT_BY_COLUMN_SQL,
                        {
                            "1": self._bucket,
                            "2": self._table_prefix,
                            "3": self._snapshot_id,
                            "4": column_name,
                        },
                    )
                    for file_path, lower, upper, nulls, rcount in cur:
                        rows[file_path] = (
                            lower, upper,
                            int(nulls or 0), int(rcount or 0),
                        )
        except Exception as exc:
            logger.warning(
                f"Supplement read failed for column={column_name}: {exc} — "
                f"falling back to manifest bounds only"
            )
            self._cache[key] = {}
            return {}

        logger.info(
            f"Supplement: {len(rows)} bound row(s) for column={column_name} "
            f"in snapshot={self._snapshot_id}"
        )
        self._cache[key] = rows
        return rows

    # ── Test seam ──────────────────────────────────────────────────────

    def _seed_cache(
        self,
        column_name: str,
        bounds: Dict[str, Tuple[Optional[str], Optional[str], int, int]],
    ) -> None:
        """Pre-seed the cache so tests can skip the DB call."""
        self._cache[column_name.lower()] = bounds
