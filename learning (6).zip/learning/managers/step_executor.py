import asyncio
import json
from typing import Dict, Callable, Any, List
import logging
import time

from log_config import build_module_logger


logger = build_module_logger(__name__, "step_executor")


class StepExecutor:
    def __init__(self, worker: Any, logger: logging.Logger = None, max_retries: int = 3):
        self.worker = worker
        self.logger = logger or logging.getLogger(__name__)
        self.logger.info(f"Initializing StepExecutor with worker: {worker}")
        self.max_retries = max_retries

    async def execute_step(
        self,
        step_class: Callable,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> Any:
        task_id = task.get("run_detail_id")
        dag_run_id = task.get("run_id")
        fk_report_id = task.get("fk_report_id", 0)
        if not task_id or not step_name:
            raise ValueError("task_id and step_name are required")
        self.logger.info(
            f"Starting step {step_name} for task {task_id} (DAG Run: {dag_run_id}, Report: {fk_report_id})"
        )
        try:
            step_instance = step_class(
                self.worker.starburst_clients,
                self.worker.oracle_data_manager,
                self.worker.logger,
            )
            result = await step_instance.execute(
                task, worker_connection_string, dest_connection_string, step_name,
                *args, event_id=kwargs.get("event_id", task_id),
                dag_run_id=dag_run_id, fk_report_id=fk_report_id,
            )
            self.logger.info(f"Completed step {step_name} for task {task_id} successfully")
            return result
        except Exception as e:
            self.logger.error(f"Step {step_name} failed for task {task_id}: {str(e)}")
            raise Exception(f"Step {step_name} failed: {str(e)}") from e

    async def execute_step_with_retry(
        self,
        step_class: Callable,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> Any:
        """Execute a step with retry logic using exponential backoff."""
        last_exception = None
        for attempt in range(1, self.max_retries + 1):
            try:
                result = await self.execute_step(
                    step_class, task, worker_connection_string,
                    dest_connection_string, step_name, *args, **kwargs,
                )
                return result
            except Exception as e:
                last_exception = e
                if attempt < self.max_retries:
                    wait_time = min(2 ** attempt, 60)  # exponential backoff, max 60s
                    self.logger.warning(
                        f"Step {step_name} failed (attempt {attempt}/{self.max_retries}), "
                        f"retrying in {wait_time}s: {str(e)}"
                    )
                    await asyncio.sleep(wait_time)
                else:
                    self.logger.error(
                        f"Step {step_name} failed after {self.max_retries} attempts: {str(e)}"
                    )
        raise last_exception

    async def execute_steps(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_mapping: Dict[str, Callable],
    ) -> Dict[str, Any]:
        task_id = task.get("run_detail_id")
        dag_run_id = task.get("run_id")
        fk_report_id = task.get("fk_report_id", 0)
        if not task_id or not worker_connection_string or not dest_connection_string:
            raise ValueError("task_id, worker_connection_string, and dest_connection_string are required")
        results = {}

        # Parse task_events — support JSON string, list, or fallback to single step
        raw_events = task.get("task_events", None)
        if raw_events is None:
            # Fallback: single step from task_steps field
            step_name = task.get("task_steps", "")
            if step_name:
                task_events = [{"task_steps": step_name, "SEQ": task.get("seq", 1)}]
            else:
                raise ValueError(f"No task events or task_steps defined for task {task_id}")
        elif isinstance(raw_events, str):
            try:
                task_events = json.loads(raw_events)
            except json.JSONDecodeError:
                raise ValueError(f"Invalid JSON in task_events for task {task_id}: {raw_events}")
        elif isinstance(raw_events, list):
            task_events = raw_events
        else:
            raise ValueError(f"Unexpected task_events type for task {task_id}: {type(raw_events)}")

        if not task_events:
            raise ValueError(f"No task events defined for task {task_id}")

        # Sort events by SEQ
        task_events.sort(key=lambda x: x.get("SEQ", 0))
        task_event_names = [event["task_steps"] for event in task_events]
        task_event_ids = [str(event.get("SEQ", i)) for i, event in enumerate(task_events)]

        # Validate that all event names have corresponding functions
        unsupported = [name for name in task_event_names if name not in step_mapping]
        if unsupported:
            raise ValueError(f"Task {task_id} has unsupported step names: {unsupported}")

        for event_id, event_name in zip(task_event_ids, task_event_names):
            step_start = time.time()
            try:
                results[event_name] = await self.execute_step_with_retry(
                    step_mapping[event_name], task, worker_connection_string,
                    dest_connection_string, event_name, event_id=event_id,
                    dag_run_id=dag_run_id, fk_report_id=fk_report_id,
                )
                step_duration = time.time() - step_start
                self.logger.info(
                    f"Step {event_name} completed in {step_duration:.2f}s for task {task_id}"
                )

                # Verify step completion before proceeding
                # execute_query_asynch is async and returns DataFrame
                status_df = await self.worker.oracle_data_manager.execute_query_asynch(
                    "SELECT TASK_STATUS AS STATUS FROM OTG_AIRFLOW_DAG_RUN_DETAIL "
                    "WHERE FK_RUN_ID = :1 AND RUN_DETAIL_ID = :2",
                    {"1": dag_run_id, "2": task_id},
                    worker_connection_string,
                )
                if status_df is not None and not status_df.empty and status_df["STATUS"].iloc[0] == "COMPLETED":
                    self.logger.info(f"Step {event_name} verified COMPLETED, proceeding to next step")
                else:
                    raise RuntimeError(f"Step {event_name} did not complete successfully, halting workflow")
            except Exception as e:
                step_duration = time.time() - step_start
                self.logger.error(
                    f"Step {event_name} failed after {step_duration:.2f}s for task {task_id}: {str(e)}"
                )
                try:
                    await self.worker.oracle_data_manager.update_otg_etl_batch_status(
                        dag_run_id, task_id, "FAILED", event_name, 0, str(e),
                        worker_connection_string,
                    )
                except Exception as update_err:
                    self.logger.error(f"Failed to update FAILED status: {update_err}")
                raise

        # All steps completed
        try:
            await self.worker.oracle_data_manager.update_otg_etl_batch_status(
                dag_run_id, task_id, "COMPLETED", "ALL_STEPS", 0, "",
                worker_connection_string,
            )
        except Exception as update_err:
            self.logger.error(f"Failed to update final COMPLETED status: {update_err}")
        return results
