"""
Per-run step timing and row count aggregation for ETL metrics.
Collects metrics during execution and provides summary for QS bridge reporting.
"""
import time
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class StepMetric:
    """Metrics for a single step execution."""

    def __init__(self, step_name: str):
        self.step_name = step_name
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None
        self.row_count: int = 0
        self.status: str = "pending"
        self.error: str = ""

    def start(self):
        self.start_time = time.time()
        self.status = "running"

    def complete(self, row_count: int = 0):
        self.end_time = time.time()
        self.row_count = row_count
        self.status = "completed"

    def fail(self, error: str = ""):
        self.end_time = time.time()
        self.status = "failed"
        self.error = error

    @property
    def duration_seconds(self) -> float:
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_name": self.step_name,
            "status": self.status,
            "row_count": self.row_count,
            "duration_seconds": round(self.duration_seconds, 2),
            "error": self.error,
        }


class MetricsCollector:
    """Collects step-level metrics for an entire ETL run."""

    def __init__(self, run_id: str, dag_id: str = "", report_id: int = 0):
        self.run_id = run_id
        self.dag_id = dag_id
        self.report_id = report_id
        self.started_at = datetime.utcnow().isoformat()
        self.run_start = time.time()
        self.steps: Dict[str, StepMetric] = {}

    def start_step(self, step_name: str) -> StepMetric:
        """Record start of a step."""
        metric = StepMetric(step_name)
        metric.start()
        self.steps[step_name] = metric
        logger.info(f"[metrics] Step started: {step_name}")
        return metric

    def complete_step(self, step_name: str, row_count: int = 0):
        """Record successful completion of a step."""
        if step_name in self.steps:
            self.steps[step_name].complete(row_count)
            logger.info(
                f"[metrics] Step completed: {step_name} "
                f"({row_count} rows, {self.steps[step_name].duration_seconds:.2f}s)"
            )

    def fail_step(self, step_name: str, error: str = ""):
        """Record failure of a step."""
        if step_name in self.steps:
            self.steps[step_name].fail(error)
            logger.error(f"[metrics] Step failed: {step_name} — {error}")

    @property
    def total_duration_seconds(self) -> float:
        return time.time() - self.run_start

    @property
    def total_row_count(self) -> int:
        return sum(s.row_count for s in self.steps.values())

    @property
    def completed_steps(self) -> int:
        return sum(1 for s in self.steps.values() if s.status == "completed")

    @property
    def failed_steps(self) -> int:
        return sum(1 for s in self.steps.values() if s.status == "failed")

    @property
    def overall_status(self) -> str:
        if self.failed_steps > 0:
            return "failed"
        if self.completed_steps == len(self.steps):
            return "completed"
        return "running"

    def get_summary(self) -> Dict[str, Any]:
        """Get summary metrics for QS bridge reporting."""
        return {
            "run_id": self.run_id,
            "dag_id": self.dag_id,
            "report_id": self.report_id,
            "started_at": self.started_at,
            "completed_at": datetime.utcnow().isoformat(),
            "duration_seconds": round(self.total_duration_seconds, 2),
            "output_row_count": self.total_row_count,
            "status": self.overall_status,
            "steps_completed": self.completed_steps,
            "steps_failed": self.failed_steps,
            "steps_total": len(self.steps),
            "step_details": [s.to_dict() for s in self.steps.values()],
        }

    def get_qs_webhook_payload(self) -> Dict[str, Any]:
        """Get payload formatted for QueryStudio webhook callback."""
        summary = self.get_summary()
        return {
            "state": summary["status"],
            "output_row_count": summary["output_row_count"],
            "duration_seconds": summary["duration_seconds"],
            "error": next(
                (s.error for s in self.steps.values() if s.error), ""
            ),
        }
