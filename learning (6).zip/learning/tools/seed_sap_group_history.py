"""Bootstrap CompanyCodeGrouper history from C# SAP-ETL task output.

The C# pipeline has been running for a year and already has accurate
per-group row counts.  Rather than make Python "learn" weights from
scratch (which would take N runs to converge), parse the existing C#
task table and seed ``group_history.json`` directly.

Input format
------------

A text file (or stdin) where each line carries a C# task name and a
total row count.  Two accepted shapes match the C# tooling output:

    TASKID | TASKNAME                                           | COUNT
    1381346 | IMPORT ME SAP BALANCE FOR SCP (GROUP21_C Eq: 8115) | 974441
    1381355 | IMPORT ME SAP BALANCE FOR SCP (GROUP23 Min: 8248 Max: 8809) | 103629
    1381350 | IMPORT ME SAP BALANCE FOR SCP (GROUP19 Min: 7740)  | 97160

Recognised group descriptors (case-insensitive):
  * ``Eq: N``           -> single code N gets the full weight
  * ``Min: N``          -> single code N gets the full weight (no Max)
  * ``Min: A Max: B``   -> codes A..B get total/(B-A+1) each (even split)

Output format
-------------

``group_history.json`` with the shape ``CompanyCodeGrouper`` expects::

    {
      "runs": [
        {"timestamp": "...", "total_groups": N, "total_rows": N,
         "source": "seed_from_csharp"}
      ],
      "code_weights": {"1319": 684981.0, "8115": 974441.0, ...}
    }

Subsequent Python runs WILL update these weights via
``CompanyCodeGrouper.record_results`` (exponential moving average,
alpha=0.3), so the seed converges to Python's actual measurements
over a few runs without ever needing to be re-seeded.

Usage
-----

    # From a file
    python -m tools.seed_sap_group_history \\
        --input /tmp/csharp_tasks.txt \\
        --output /usr/local/spark/nfs/bcp/batch/sap_mebal/group_history.json

    # From stdin (paste C# output, Ctrl-D / Ctrl-Z)
    python -m tools.seed_sap_group_history --output /path/group_history.json

    # Print to stdout for inspection
    python -m tools.seed_sap_group_history --input tasks.txt --output -
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple


# (?ix) = case-insensitive + verbose.
# Captures: kind ('eq' | 'min'), the min value, optional max value.
_PATTERN = re.compile(
    r"""
    (?:                                   # non-capturing wrapper
        \b Eq \s* : \s* (?P<eq>\d+)        # 'Eq: N'  -> single
      |
        \b Min \s* : \s* (?P<min>\d+)      # 'Min: A'
        (?:                                 #   optional 'Max: B'
            \s+ Max \s* : \s* (?P<max>\d+)
        )?
    )
    """,
    re.IGNORECASE | re.VERBOSE,
)


def parse_lines(lines: Iterable[str]) -> List[Tuple[str, str, int]]:
    """Yield ``(min_code, max_code, total_count)`` per input line.

    Skips lines that don't match (headers, separators, blanks).
    ``max_code`` equals ``min_code`` for the single-code shapes
    (Eq / Min-only).
    """
    out: List[Tuple[str, str, int]] = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        # Total count: take the last integer-looking token after the
        # final pipe.  Handles "TASKID | TASKNAME | COUNT" format AND
        # "TASKNAME COUNT" (no pipes).
        parts = line.rsplit("|", 1)
        tail = parts[-1].strip()
        m_count = re.search(r"(\d+)\s*$", tail)
        if not m_count:
            continue
        total = int(m_count.group(1))
        # Group descriptor: scan the line for Eq/Min/Max
        m = _PATTERN.search(line)
        if not m:
            continue
        if m.group("eq"):
            code = m.group("eq")
            out.append((code, code, total))
        else:
            mn = m.group("min")
            mx = m.group("max") or mn   # Min-only -> single code
            out.append((mn, mx, total))
    return out


def distribute_weights(
    rows: List[Tuple[str, str, int]],
    *,
    range_inflate_for_min_only: bool = False,
) -> Dict[str, float]:
    """Convert parsed rows into per-code weights.

    For range rows (min != max), the total weight is split evenly
    across every integer code in ``[min, max]``.  This is an
    approximation -- the C# data doesn't tell us per-code counts
    inside a range -- but it's accurate ENOUGH to identify HEAVY
    codes (the ones we want to isolate via ``SINGLE_CODE_LIST``).
    Subsequent Python runs will refine via EMA.

    When two rows touch the same code (rare with the C# output),
    the LATER weight wins -- intentional, mirrors how the EMA in
    ``record_results`` overwrites stale weights.
    """
    weights: Dict[str, float] = {}
    for mn, mx, total in rows:
        try:
            lo, hi = int(mn), int(mx)
        except ValueError:
            # Non-numeric code -- treat as single, full weight
            weights[mn] = float(total)
            continue
        if lo == hi:
            weights[str(lo).zfill(len(mn))] = float(total)
            continue
        n = hi - lo + 1
        per = total / n
        zwidth = max(len(mn), len(mx))
        for c in range(lo, hi + 1):
            weights[str(c).zfill(zwidth)] = per
    return weights


def build_history(
    weights: Dict[str, float],
    *,
    source: str = "seed_from_csharp",
) -> Dict:
    total_rows = int(sum(weights.values()))
    return {
        "runs": [
            {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "total_groups": 0,           # bootstrap, no actual run
                "total_rows": total_rows,
                "source": source,
                "code_count": len(weights),
            }
        ],
        "code_weights": {k: round(v, 1) for k, v in weights.items()},
    }


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(
        description="Seed CompanyCodeGrouper history from C# task table."
    )
    p.add_argument(
        "--input", "-i", type=str, default=None,
        help="Path to C# task table file (default: read stdin)",
    )
    p.add_argument(
        "--output", "-o", type=str, required=True,
        help="Path to write group_history.json ('-' for stdout)",
    )
    p.add_argument(
        "--merge", action="store_true",
        help="If output file exists, merge new weights into existing "
             "code_weights (later seed wins per code).",
    )
    args = p.parse_args(argv)

    if args.input:
        with open(args.input, encoding="utf-8") as f:
            lines = f.readlines()
    else:
        lines = sys.stdin.readlines()

    rows = parse_lines(lines)
    if not rows:
        print(
            "ERROR: no recognisable group descriptors found in input.  "
            "Expected lines containing 'Eq: N' or 'Min: A [Max: B]'.",
            file=sys.stderr,
        )
        return 2

    weights = distribute_weights(rows)
    new_hist = build_history(weights)

    if args.merge and args.output != "-" and Path(args.output).exists():
        try:
            with open(args.output, encoding="utf-8") as f:
                old = json.load(f)
            existing = old.get("code_weights", {})
            existing.update(new_hist["code_weights"])
            new_hist["code_weights"] = existing
            new_hist.setdefault("runs", []).extend(old.get("runs", []))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"WARN: could not merge existing {args.output}: {exc}",
                  file=sys.stderr)

    blob = json.dumps(new_hist, indent=2, default=str)
    if args.output == "-":
        print(blob)
    else:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(blob)

    n_single = sum(1 for v in weights.values() if v > 100_000)
    print(
        f"OK seeded {len(weights)} codes "
        f"({n_single} weigh > 100K rows -- candidates for SINGLE_CODE_LIST).  "
        f"Total approx rows: {int(sum(weights.values())):,}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
