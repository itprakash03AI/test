"""
SAP OData Download step.

Count-driven streaming extract -- one strategic abstraction end-to-end:

  1. Fetch company codes (small master-data set).
  2. Group via smart bin-packing (history-weighted).
  3. Pre-flight: GET ``/Data/$count`` WITHOUT $filter -- full-period
     expected row count.  Used post-flight to reconcile the SUM of
     per-group counts against the unfiltered total (proves the
     company-code partitioning didn't miss any rows).
  4. Per group, in parallel:
       a. GET ``/Data/$count?$filter=(...)`` -- group expected count.
       b. Stream ``/Data?$filter=(...)`` page-by-page directly to a
          CSV or Parquet sink.  Peak memory = one page.
       c. Per-group reconcile: rows-written MUST equal $count.
  5. Sum-reconcile: Sum(per-group $count) MUST equal full $count.

Group-level checkpointing survives crashes -- already-completed group
files are reused on retry.
"""
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional

from steps.sap_odata_base import SapOdataBase
from steps.sap_odata_sinks import make_sink, file_extension_for
from steps.sap_odata_report import RunReport
from managers.company_code_grouper import CompanyCodeGrouper


class SapOdataDownload(SapOdataBase):
    """Download SAP Month End Balance data via OData API."""

    LOG_PREFIX = "sap_mebal_download"

    # Phase 134 -- required fields are now the four polling-row columns
    # (overlaid into config in the base class) + output_dir which still
    # comes from the JSON tuning config.  ``sap_base_url`` /
    # ``odata_service_path`` / ``company_code_endpoint`` are deprecated
    # in favour of the two full-URL columns ``sap_me_balance_api`` and
    # ``sap_company_api``.
    REQUIRED_FIELDS = [
        'sap_username', 'sap_password',
        'sap_me_balance_api', 'sap_company_api',
        'output_dir',
    ]

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        # -- Run banner: one block at the top of the log so an operator
        # opening the file mid-batch immediately sees URLs / period /
        # group target / output location --
        self.logger.info("=" * 72)
        self.logger.info("SAP OData download -- run context")
        self.logger.info("=" * 72)
        self.logger.info(f"  run_id            : {task.get('run_id')}")
        self.logger.info(f"  run_detail_id     : {task.get('run_detail_id')}")
        self.logger.info(f"  fk_dag_id         : {task.get('fk_dag_id')}")
        self.logger.info(f"  fk_report_id      : {task.get('fk_report_id')}")
        self.logger.info(f"  log_file          : {task.get('log_file', '<console>')}")
        self.logger.info(f"  sap_company_api   : {config.get('sap_company_api', '<unset>')}")
        self.logger.info(f"  sap_me_balance_api: {config.get('sap_me_balance_api', '<unset>')}")
        self.logger.info(f"  num_groups target : {config.get('num_groups', 5)}")
        self.logger.info(f"  max_parallel_grp  : {config.get('max_parallel_groups', 3)}")
        # Resolve via the same clamp the streamer uses so the banner
        # shows the EFFECTIVE chunk size (after MAX_TOP=50000 ceiling)
        # not just whatever the row / JSON requested.
        _effective_top = self._resolve_page_size(config)
        self.logger.info(
            f"  page_size ($top)  : {_effective_top} "
            f"(requested {config.get('page_size', self.DEFAULT_TOP)}, "
            f"max {self.MAX_TOP})"
        )
        self.logger.info(f"  rate_limit_rps    : {config.get('rate_limit_rps', self.DEFAULT_RATE_LIMIT_RPS)}")
        self.logger.info(f"  output_dir (root) : {config.get('output_dir', '<unset>')}")
        self.logger.info(f"  output_format     : {(config.get('output_format') or 'csv').lower()}")
        self.logger.info("=" * 72)

        # Normalise output_format early so every downstream branch sees
        # the same lower-case value.  Accepts:
        #   'csv'             -- per-group + consolidated CSV only
        #   'parquet'         -- per-group + consolidated Parquet only
        #   'csv,parquet'     -- BOTH formats produced at each stage
        #                         (consolidate writes one of each).
        # Default 'csv'.  Splits on ',' so '  csv , parquet ' also works.
        raw_fmt = (config.get("output_format") or "csv").strip().lower()
        fmt_parts = [p.strip() for p in raw_fmt.split(",") if p.strip()]
        bad = [p for p in fmt_parts if p not in ("csv", "parquet")]
        if bad:
            raise ValueError(
                f"OUTPUT_FORMAT {raw_fmt!r} contains unsupported values "
                f"{bad} -- expected 'csv', 'parquet', or 'csv,parquet'."
            )
        # Per-group sink uses the FIRST listed format (it's the streaming
        # source of truth; consolidate produces additional formats from it).
        output_format = fmt_parts[0] if fmt_parts else "csv"
        config["output_format"] = output_format
        config["output_formats"] = fmt_parts  # full list (consolidate uses this)

        # -- Run report (HTML + text + optional email) --------------
        # Created BEFORE any HTTP work so a failure mid-fetch still
        # leaves a partial report on disk.  ``finally:`` clause below
        # always writes the report + sends the finish-email -- success
        # OR exception.
        report = RunReport(output_dir="", logger=self.logger)
        report.set_context(
            period="<TBD>",  # filled after fiscal-period resolution
            run_id=task.get("run_id"),
            run_detail_id=task.get("run_detail_id"),
            dag_id=task.get("fk_dag_id"),
            report_id=task.get("fk_report_id"),
            business_date=task.get("business_date"),
            log_file=task.get("log_file", "<console>"),
        )
        report.set_urls(
            SAP_COMPANY_API=config.get("sap_company_api", "<unset>"),
            SAP_ME_BALANCE_API_TEMPLATE=config.get("sap_me_balance_api", "<unset>"),
        )
        report.set_runtime_knobs(
            page_size_effective=_effective_top,
            page_size_requested=config.get("page_size", self.DEFAULT_TOP),
            max_top_ceiling=self.MAX_TOP,
            rate_limit_rps=config.get("rate_limit_rps", self.DEFAULT_RATE_LIMIT_RPS),
            max_parallel_groups=config.get("max_parallel_groups", 3),
            codes_per_group=config.get("codes_per_group", "default 100"),
            group_max_retries=config.get("group_max_retries", 3),
            group_retry_backoff=config.get("group_retry_backoff", 5.0),
            output_format=output_format,
            output_formats=fmt_parts,
            verify_ssl=config.get("verify_ssl", True),
        )

        email_cfg = self._extract_email_cfg(config)

        session = self._build_session(config)
        try:
            # 1. Fetch company codes from separate SAP OData endpoint
            company_codes = self._fetch_company_codes(session, config)
            self.logger.info(
                f"Fetched {len(company_codes)} company codes "
                f"[{company_codes[0] if company_codes else '-'}..."
                f"{company_codes[-1] if company_codes else '-'}]"
            )

            if not company_codes:
                # Default behaviour: fail loud.  An empty company-code
                # response from SAP is almost always a real error (auth
                # failure that returned HTTP-200 with no ``d`` envelope,
                # misconfigured filter, wrong fiscal period).  Bypass
                # via ``allow_empty_company_codes: true`` in the JSON
                # config for the rare legitimate case.
                msg = (
                    "SAP OData download: company-code endpoint returned 0 "
                    "codes (URL: "
                    + str(config.get('sap_company_api', config.get('company_code_endpoint', '<unset>')))
                    + ").  Likely an auth failure, misconfigured filter, "
                    "or wrong period.  Set allow_empty_company_codes=true "
                    "in the JSON config to bypass."
                )
                if not config.get('allow_empty_company_codes', False):
                    raise ValueError(msg)
                self.logger.warning(msg + " -- proceeding anyway per config")
                task['totalcount'] = 0
                return 0

            # 2. Resolve fiscal period FIRST -- needed to stamp the
            # output_dir with the real period (no more TBD_TBD).
            row_year  = task.get('p_gjahr') or task.get('P_GJAHR')
            row_month = task.get('p_poper') or task.get('P_POPER')
            if row_year not in (None, "") and row_month not in (None, ""):
                p_gjahr = str(row_year).strip()
                try:
                    p_poper = f"{int(row_month):03d}"
                except (TypeError, ValueError):
                    p_poper = str(row_month).strip()
                self.logger.info(
                    f"Fiscal period from polling row: year={p_gjahr}, "
                    f"period={p_poper}"
                )
            else:
                period_mode = config.get('period_mode', 'current')
                p_gjahr, p_poper = self._derive_fiscal_period(period_mode)
                self.logger.info(
                    f"Fiscal period derived: year={p_gjahr}, "
                    f"period={p_poper} (mode={period_mode})"
                )

            # 2.5 FORCE_FRESH_RUN cleanup (before resolve_output_dir
            # so the sidecar-based resume doesn't pick up the
            # to-be-deleted run_subdir).
            self._force_fresh_cleanup(task, config)

            # 3. Output dir with REAL period (or resume via sidecar).
            run_subdir = self._resolve_output_dir(
                task, config, p_gjahr=p_gjahr, p_poper=p_poper,
            )

            # 4. Smart grouping by codes_per_group (default 100).
            # group_history_path defaults to ``<ETL_DATA_ROOT>/sap_mebal/
            # group_history.json``.
            from log_config import get_data_root as _data_root
            history_path = config.get(
                'group_history_path',
                os.path.join(_data_root(), 'sap_mebal', 'group_history.json'),
            )
            codes_per_group = config.get('codes_per_group')
            num_groups = config.get('num_groups')
            rows_per_group_target = config.get('rows_per_group_target')
            # SINGLE_CODE_LIST arrives as a comma-separated string from
            # the polling row; split + trim into a list here so the
            # grouper takes a clean ``List[str]``.  Empty / NULL ->
            # empty list -> no codes force-isolated.
            scl_raw = config.get('single_code_list') or ''
            single_code_list = [
                c.strip() for c in str(scl_raw).split(',') if c.strip()
            ]
            grouper = CompanyCodeGrouper(
                history_path,
                num_groups=num_groups,
                codes_per_group=codes_per_group,
                rows_per_group_target=(
                    int(rows_per_group_target)
                    if rows_per_group_target else None
                ),
                single_code_list=single_code_list or None,
            )
            groups = grouper.group_codes(company_codes)
            self.logger.info(
                f"Created {len(groups)} download groups from "
                f"{len(company_codes)} codes "
                f"(codes_per_group={codes_per_group or 'default 100'}, "
                f"history: {history_path})"
            )
            # Per-group breakdown so an operator can see exactly which
            # codes landed in which bucket and whether the bin-packer
            # produced lopsided groups.
            for gi, grp in enumerate(groups):
                sorted_grp = sorted(grp)
                preview = (
                    ", ".join(sorted_grp)
                    if len(sorted_grp) <= 12
                    else f"{', '.join(sorted_grp[:5])} ... {', '.join(sorted_grp[-5:])}"
                )
                self.logger.info(
                    f"  group {gi:>2}: {len(sorted_grp):>4} codes "
                    f"[{sorted_grp[0]}..{sorted_grp[-1]}]  "
                    f"({preview})"
                )

            # 4. Dump codes + groups to CSVs BEFORE any further HTTPS.
            # When SAP is flaky an operator opening the run_subdir
            # immediately sees what WAS planned -- no need for a
            # successful run to debug grouping decisions.
            self._dump_codes_csv(run_subdir, company_codes)
            self._dump_groups_csv(run_subdir, groups)

            # Report now has a real output_dir and real period -- update
            # context and SEND THE START EMAIL.  An operator who has
            # email but not log-aggregation will see the run kicked off
            # within seconds of step launch.
            report.output_dir = run_subdir
            report.set_context(period=f"{p_gjahr}/{p_poper}",
                                output_dir=run_subdir)
            report.set_urls(
                COMPANY_CODES_CSV=os.path.join(run_subdir, 'company_codes.csv'),
                GROUPS_CSV=os.path.join(run_subdir, 'groups.csv'),
            )
            report.mark_started()
            report.write()                 # initial HTML+txt on disk
            report.send_email(email_cfg)    # START email (no-op if flag off)

            # Persist EARLY so subsequent SAP steps (Consolidate etc.)
            # can hydrate state via the sidecar even when this step
            # crashes mid-stream.  Carries enough to debug a partial
            # run from the consolidate side without re-running download.
            task['run_subdir']    = run_subdir
            task['p_gjahr']       = p_gjahr
            task['p_poper']       = p_poper
            task['output_format'] = output_format
            task['output_formats'] = fmt_parts
            self._save_sidecar(task, config)

            # 6. Pre-flight: full $count (no $filter).
            #
            # Hits ``/Data/$count`` with EVERY query param stripped
            # except the (p_gjahr/p_poper/p_timestamp) function call in
            # the path itself.  This is the source-of-truth row count
            # the entire run will be reconciled against.  Captured
            # BEFORE the group loop so a long extract doesn't race
            # against late-arriving SAP postings -- if data shifts under
            # us we want to see the mismatch and fail loud.
            full_count = self._fetch_full_count(
                session, config, p_gjahr, p_poper,
            )
            self.logger.info(
                f"Full $count (no company-code filter): {full_count:,} rows"
            )
            task['full_count'] = full_count

            # 6. Load checkpoint (skip already-completed groups on resume)
            checkpoint = self._load_checkpoint(run_subdir)

            # 7. Download groups (parallel or sequential), skipping completed
            max_parallel = config.get('max_parallel_groups', 3)
            group_results = self._download_all_groups(
                session, config, groups, p_gjahr, p_poper,
                run_subdir, max_parallel, checkpoint,
            )

            # 8. Record results (EMA over group totals -- approximate
            # per-code via group_total / group_size).
            grouper.record_results(group_results)

            # 9. Auto-discovery probe runs AFTER record_results so the
            # probe's EXACT per-code counts OVERRIDE the EMA estimates
            # for the codes in oversized groups.  Best-effort -- a
            # probe failure must NOT block CTL / Deliver, the download
            # itself has already succeeded.
            try:
                self._probe_oversized_groups_per_code(
                    session, config, group_results,
                    p_gjahr, p_poper, grouper,
                )
            except Exception as probe_exc:
                self.logger.warning(
                    "Auto-discovery probe raised (continuing): %s",
                    probe_exc,
                )

            total_rows = sum(r['row_count'] for r in group_results)
            sum_expected = sum(
                r.get('expected_count', r['row_count']) for r in group_results
            )
            task['totalcount'] = total_rows
            task['per_group_counts'] = [
                {
                    'group_idx':      r['group_idx'],
                    'codes':          r['codes'],
                    'expected_count': r.get('expected_count'),
                    'actual_count':   r['row_count'],
                    'file_path':      r['file_path'],
                }
                for r in sorted(group_results, key=lambda x: x['group_idx'])
            ]

            # -- Summation reconcile ----------------------------------
            # Sum(per-group $count)  MUST equal  full $count.  If the
            # company-code partitioning is complete + non-overlapping
            # these are identical by construction; a mismatch means we
            # dropped (or double-counted) at least one company code.
            #
            # Sum(per-group actual)  MUST equal  full $count too -- the
            # per-group reconcile already guarantees actual == expected
            # per group, so this is belt-and-braces (catches a race
            # against late SAP postings between the full-count fetch
            # and the group-count fetches).
            self._reconcile_full_vs_sum(
                full_count=full_count,
                sum_expected=sum_expected,
                sum_actual=total_rows,
                config=config,
            )

            # -- Completeness ledger ----------------------------------
            # Single visible block summarising every completeness gate
            # the download stage enforces.  An operator opening the log
            # post-run sees the verdict for each scenario without
            # scrolling.  Re-emitted by SapCheckCompleteness so the
            # END-OF-PIPELINE ledger persists past consolidate/compress.
            self._log_completeness_ledger(
                full_count=full_count,
                sum_expected=sum_expected,
                sum_actual=total_rows,
                group_results=group_results,
                period=f"{p_gjahr}/{p_poper}",
            )
            task['completeness_ledger'] = {
                'full_count':   full_count,
                'sum_expected': sum_expected,
                'sum_actual':   total_rows,
                'groups_total': len(group_results),
                'period':       f"{p_gjahr}/{p_poper}",
            }

            # Fail loud when every group returned 0 rows.  Same logic as
            # empty-company-codes: a true empty extract is almost always
            # an upstream failure (auth expired mid-run, fiscal period
            # has no data, OData filter excluded everything).  Bypass
            # via ``allow_empty_extract: true`` for the rare legit case.
            if total_rows == 0 and not config.get('allow_empty_extract', False):
                raise ValueError(
                    f"SAP OData download: 0 total rows across all "
                    f"{len(groups)} groups for period {p_gjahr}/{p_poper}.  "
                    f"Likely an auth / period / filter problem.  Set "
                    f"allow_empty_extract=true in the JSON config to bypass."
                )

            # Final per-group count breakdown -- quick visual for
            # post-mortem "which group brought the rows", with the
            # expected-vs-actual reconcile column for transparency.
            self.logger.info("-" * 84)
            self.logger.info(
                "SAP OData download -- per-group reconcile "
                "(expected = group $count, actual = streamed rows)"
            )
            self.logger.info("-" * 84)
            for r in sorted(group_results, key=lambda x: x['group_idx']):
                pct = (r['row_count'] / total_rows * 100) if total_rows else 0
                expected = r.get('expected_count')
                expected_str = f"{expected:>10,}" if expected is not None else "       ???"
                self.logger.info(
                    f"  group {r['group_idx']:>2}: "
                    f"expected={expected_str}  actual={r['row_count']:>10,} "
                    f"({pct:5.1f}%)  -> {r['file_path']}"
                )
            self.logger.info("-" * 84)
            self.logger.info(
                f"Download complete: {total_rows:,} total rows (full $count "
                f"{full_count:,}) across {len(groups)} groups, "
                f"output_dir={run_subdir}"
            )

            # Pass state to next steps via task dict
            task['downloaded_files'] = [r['file_path'] for r in group_results]
            task['output_dir'] = run_subdir
            task['p_gjahr'] = p_gjahr
            task['p_poper'] = p_poper
            task['output_format'] = output_format

            # Persist FINAL state to the sidecar -- this is what
            # Consolidate / Compress / CTL / Deliver / CheckCompleteness
            # will hydrate from when they run on their separate task dicts.
            self._save_sidecar(task, config)

            # Clear checkpoint -- all groups succeeded
            self._clear_checkpoint(run_subdir)

            if self.oracle_data_manager:
                await self.oracle_data_manager.update_otg_etl_batch_status(
                    task.get("run_id"), task.get("run_detail_id"),
                    'UPDATE_TASK_RECORDCOUNT', step_name,
                    total_rows, "", worker_connection_string
                )

            # Capture EVERY group's final state into the report (HTML
            # row per group, used for both the on-disk report and the
            # finish email body).
            for r in sorted(group_results, key=lambda x: x['group_idx']):
                report.add_group_result(r)
            report.set_counts(
                full_count=full_count,
                sum_expected=sum_expected,
                sum_actual=total_rows,
            )
            for r in group_results:
                report.add_output_file(r['file_path'])
            # Surface ONE example data + count URL per run (operator can
            # correlate with the SAP audit log without spelunking).
            if groups:
                ex_base, ex_params, _, _ = self._build_group_url(
                    config, groups[0], p_gjahr, p_poper,
                )
                report.set_urls(
                    EXAMPLE_GROUP_DATA_URL=ex_base,
                    EXAMPLE_GROUP_COUNT_URL=self.derive_count_url(
                        ex_base, ex_params,
                    ),
                    FULL_COUNT_URL=self.derive_count_url(
                        ex_base, ex_params, strip_filter=True,
                    ),
                )
            report.mark_success()
            return total_rows

        except Exception as e:
            self.logger.error(f"SAP OData download failed: {e}", exc_info=True)
            # Even on failure: capture whatever we know + persist the
            # report so the operator opens output_dir/run_report.html
            # and sees the partial state without grepping logs.
            try:
                report.mark_failed(error_message=f"{type(e).__name__}: {e}")
            except Exception:
                pass
            raise
        finally:
            # ALWAYS write the report + (optionally) send the finish
            # email -- success OR exception path lands here.
            try:
                report.write()
            except Exception as wexc:
                self.logger.warning(
                    "Could not persist run_report: %s", wexc,
                )
            try:
                report.send_email(email_cfg)
            except Exception as eexc:
                self.logger.warning(
                    "Could not send finish email: %s -- run continues",
                    eexc,
                )
            session.close()

    # -- Checkpoint helpers ----------------------------------------------

    def _checkpoint_path(self, run_dir: str) -> str:
        return os.path.join(run_dir, ".checkpoint.json")

    def _load_checkpoint(self, run_dir: str) -> Dict:
        """Load checkpoint file (tracks completed groups)."""
        cp_path = self._checkpoint_path(run_dir)
        if os.path.exists(cp_path):
            try:
                with open(cp_path, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return {"completed_groups": {}}

    def _save_checkpoint(self, run_dir: str, group_idx: int, result: Dict):
        """Save a single group's completion to checkpoint.

        Audit SERIOUS #6 -- atomic write.  Pre-Phase-134-K code did
        ``json.dump`` directly to .checkpoint.json; a mid-write crash
        (SIGKILL/OOM/power-loss) produced a corrupt JSON that
        _load_checkpoint silently swallowed (returns empty), forcing
        a full re-download of every group.  Hours of work lost.

        Fix: write to ``.checkpoint.json.tmp`` then ``os.replace()`` --
        atomic on POSIX, atomic-when-on-same-FS on Windows.  A crash
        before the replace leaves the OLD checkpoint intact.
        """
        cp = self._load_checkpoint(run_dir)
        cp["completed_groups"][str(group_idx)] = {
            "file_path":      result["file_path"],
            "row_count":      result["row_count"],
            "codes":          result["codes"],
            # 2026-06-06 -- persist expected_count so a resumed run
            # can still summation-reconcile against the full $count
            # without re-fetching every per-group $count.
            "expected_count": result.get("expected_count"),
        }
        target = self._checkpoint_path(run_dir)
        tmp = target + ".tmp"
        with open(tmp, 'w') as f:
            json.dump(cp, f, indent=2)
            # Defensive -- fsync so the bytes are on the disk platter
            # before os.replace makes them visible.  Otherwise on some
            # filesystems a crash between write() and replace() could
            # still leave a zero-byte file post-rename.
            try:
                f.flush()
                os.fsync(f.fileno())
            except (AttributeError, OSError):
                pass  # fsync unavailable (e.g. some VFS fuse mounts)
        os.replace(tmp, target)

    def _clear_checkpoint(self, run_dir: str):
        """Remove checkpoint after all groups succeed."""
        cp_path = self._checkpoint_path(run_dir)
        if os.path.exists(cp_path):
            os.remove(cp_path)
            self.logger.info("Cleared group checkpoint (all groups complete)")

    # -- Company codes ---------------------------------------------------

    def _fetch_company_codes(self, session, config: Dict) -> List[str]:
        """Fetch company codes from the SAP_COMPANY_API URL.

        Company-code master (``CocodemasterSet`` etc.) is a small set --
        single-shot fetch, no ``$top/$skip`` injection.  Follows the
        OData ``__next`` link if the server volunteers one (rare for
        master-data endpoints) so very large rosters still complete.

        Pre-2026-06-05 code routed this through ``_paginated_odata_get``
        which appended ``$top=100000&$skip=0&spnego=disabled`` --
        producing a duplicate-param URL that some SAP services rejected
        with 400/401.  Now we hit the URL exactly as the polling row
        provides it.
        """
        url = config.get('sap_company_api') \
            or config.get('company_code_endpoint', '')
        if not url:
            raise ValueError(
                "missing SAP_COMPANY_API on the task row "
                "(or company_code_endpoint in the JSON config)"
            )
        # Legacy path: relative endpoint joined with sap_base_url.
        if not url.startswith('http') and config.get('sap_base_url'):
            base = config['sap_base_url'].rstrip('/')
            url = f"{base}/{url.lstrip('/')}"

        code_field = config.get('company_code_field', 'Companycode')
        timeout = config.get('timeout_seconds', self.DEFAULT_TIMEOUT_SECONDS)
        all_codes: List[str] = []
        next_url = url
        page = 0

        while next_url:
            self.logger.info(f"Fetching company codes from: {next_url}")
            resp = session.get(next_url, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()

            # Same HTTP-200-error-envelope guard as _paginated_odata_get.
            if not isinstance(data, dict) or 'd' not in data:
                err = (data or {}).get('error') if isinstance(data, dict) else None
                err_msg = (
                    (err.get('message') or {}).get('value')
                    if isinstance(err, dict) else str(data)[:300]
                )
                raise ValueError(
                    f"SAP company-code response missing ``d`` envelope "
                    f"(URL: {next_url}).  Likely an auth failure or "
                    f"malformed request.  Server said: {err_msg!r}"
                )

            d_env = data.get('d') or {}
            results = d_env.get('results', []) or []
            for r in results:
                v = r.get(code_field)
                if v:
                    all_codes.append(str(v))

            self.logger.info(f"  page {page}: {len(results)} codes (cumulative: {len(all_codes)})")

            # Follow OData __next only if server volunteers one.
            next_url = d_env.get('__next')
            if next_url is None:
                meta = d_env.get('__metadata') or {}
                if isinstance(meta, dict):
                    next_url = meta.get('__next')
            page += 1
            if page > 200:  # safety cap -- master data shouldn't paginate this deep
                self.logger.warning(
                    "Company-code pagination cap (200 pages) hit -- stopping."
                )
                break

        return sorted(set(all_codes))

    # -- Download orchestration ------------------------------------------

    def _download_all_groups(
        self, session, config: Dict, groups: List[List[str]],
        p_gjahr: str, p_poper: str, output_dir: str, max_parallel: int,
        checkpoint: Dict,
    ) -> List[Dict]:
        """Download all groups, skipping already-completed ones (resume support)."""
        completed = checkpoint.get("completed_groups", {})

        # Separate completed vs pending groups.  Two extra guards beyond
        # plain "checkpoint row exists":
        #   (a) the on-disk file the checkpoint points at must still
        #       exist (catches a wiped output_dir).
        #   (b) the group's company-code set on THIS run must match the
        #       checkpointed code set bit-for-bit.  Otherwise the
        #       grouper has rebalanced (different NUM_GROUPS, different
        #       company-code roster, etc.) and the file's data covers a
        #       DIFFERENT slice of company codes than the new group
        #       expects.  Silent-reuse would ship the wrong rows.
        pending_indices = []
        results = []
        for i, group in enumerate(groups):
            cp_entry = completed.get(str(i))
            if not cp_entry:
                pending_indices.append(i)
                continue
            if not os.path.exists(cp_entry.get("file_path", "")):
                self.logger.info(
                    f"Group {i}: checkpoint says complete but "
                    f"{cp_entry.get('file_path')!r} missing -- re-downloading"
                )
                pending_indices.append(i)
                continue
            # Codes fingerprint guard.  sorted() because the bin-packer
            # output order isn't stable across runs even when the set
            # is identical.
            cp_codes = sorted(cp_entry.get('codes') or [])
            cur_codes = sorted(group)
            if cp_codes != cur_codes:
                self.logger.warning(
                    f"Group {i}: company-code set changed since checkpoint "
                    f"(was {len(cp_codes)} codes, now {len(cur_codes)}) "
                    f"-- discarding stale file {cp_entry.get('file_path')!r} "
                    f"and re-downloading.  This run will use the new grouping."
                )
                # Wipe the stale file so the new sink doesn't accidentally
                # honour-and-append; the streamer opens with 'w' anyway
                # but be explicit.
                try:
                    os.remove(cp_entry["file_path"])
                except OSError:
                    pass
                pending_indices.append(i)
                continue
            self.logger.info(
                f"Group {i}: SKIPPED (checkpoint -- {cp_entry['row_count']} "
                f"rows, codes match, file present)"
            )
            results.append({
                'group_idx':      i,
                'codes':          cp_entry['codes'],
                'row_count':      cp_entry['row_count'],
                'expected_count': cp_entry.get('expected_count', cp_entry['row_count']),
                'file_path':      cp_entry['file_path'],
            })

        if not pending_indices:
            self.logger.info("All groups already completed from checkpoint")
            results.sort(key=lambda r: r['group_idx'])
            return results

        self.logger.info(f"{len(pending_indices)} groups pending, {len(results)} from checkpoint")

        if max_parallel <= 1:
            for i in pending_indices:
                result = self._download_group(
                    session, config, groups[i], i, p_gjahr, p_poper, output_dir
                )
                self._save_checkpoint(output_dir, i, result)
                results.append(result)
        else:
            # Track succeeded / failed groups separately so when one
            # group raises we can give the operator a STATUS LEDGER
            # (which groups completed, which were in flight, which
            # never started) instead of just the failed group's
            # traceback.  Helps decide whether to retry or escalate.
            succeeded: List[int] = []
            failed: Dict[int, str] = {}
            first_error: Optional[BaseException] = None
            with ThreadPoolExecutor(max_workers=max_parallel) as executor:
                futures = {}
                for i in pending_indices:
                    thread_session = self._build_session(config)
                    future = executor.submit(
                        self._download_group,
                        thread_session, config, groups[i], i,
                        p_gjahr, p_poper, output_dir
                    )
                    futures[future] = (i, thread_session)

                for future in as_completed(futures):
                    group_idx, thread_session = futures[future]
                    try:
                        result = future.result()
                        self._save_checkpoint(output_dir, group_idx, result)
                        results.append(result)
                        succeeded.append(group_idx)
                    except Exception as e:
                        failed[group_idx] = str(e)
                        if first_error is None:
                            first_error = e
                        self.logger.error(
                            "Group %d FAILED: %s -- other in-flight groups "
                            "will be allowed to drain before re-raising",
                            group_idx, e,
                        )
                    finally:
                        thread_session.close()

            if failed:
                # Status ledger -- ops opens the log post-mortem and
                # immediately sees the full picture (not just the
                # first stack trace).
                self.logger.error("-" * 72)
                self.logger.error("Parallel download status ledger")
                self.logger.error("-" * 72)
                self.logger.error(
                    "  SUCCEEDED (%d): %s",
                    len(succeeded), sorted(succeeded),
                )
                self.logger.error(
                    "  FAILED    (%d): %s",
                    len(failed), sorted(failed.keys()),
                )
                for gi in sorted(failed.keys()):
                    self.logger.error(f"    group {gi}: {failed[gi]}")
                self.logger.error("-" * 72)
                self.logger.error(
                    "Re-running this step resumes from checkpoint -- the "
                    "%d succeeded groups will be skipped, only the %d "
                    "failed groups will re-download.",
                    len(succeeded), len(failed),
                )
                raise first_error  # type: ignore[misc]

        results.sort(key=lambda r: r['group_idx'])
        return results

    # -- Email config extraction ------------------------------------

    def _extract_email_cfg(self, config: Dict) -> Dict[str, Any]:
        """Lift the email-related keys out of config.

        Local-dev path: leave ``send_email`` unset / False on the row
        and the report still lands on disk but nothing leaves the pod.
        Prod path: polling row carries SEND_EMAIL='TRUE' + the SMTP /
        recipient knobs and the start + finish emails fire.

        All keys lowercase in config; SAP base class overlay handles
        the upper/lower transformation when row columns are present.
        """
        send = config.get("send_email", False)
        if isinstance(send, str):
            send = send.strip().upper() in ("TRUE", "1", "YES", "Y")
        return {
            "send_email":    bool(send),
            "smtp_host":     config.get("smtp_host", ""),
            "smtp_port":     int(config.get("smtp_port", 25) or 25),
            "smtp_user":     config.get("smtp_user", ""),
            "smtp_password": config.get("smtp_password", ""),
            "smtp_use_tls":  bool(config.get("smtp_use_tls", False)),
            "email_from":    config.get("email_from", ""),
            "email_to":      config.get("email_to", ""),
            "email_subject": config.get("email_subject", ""),
        }

    # -- Auto-discovery: probe oversized groups for true per-code counts -

    def _probe_oversized_groups_per_code(
        self, session, config: Dict, group_results: List[Dict],
        p_gjahr: str, p_poper: str, grouper,
    ) -> int:
        """Per-code $count probe for groups that ran heavy.

        Pre-fix limitation: ``CompanyCodeGrouper.record_results`` does
        EMA on the GROUP TOTAL divided by group size -- a heavy code
        bundled with 99 light ones gets weight ``total/100`` not its
        true weight.  The walker NEVER discovers it as heavy because
        EMA hides the per-code signal.

        Probe approach:
          1. Pick groups where ``actual > rows_per_group_target * 1.5``
             AND ``len(codes) > 1`` (single-code groups already
             isolated; nothing to discover).
          2. For each code in those groups, fire one ``$count?
             $filter=(Companycode eq 'X')`` GET in parallel.
          3. Ingest TRUE per-code counts into the grouper's history,
             replacing the EMA estimates.
          4. Codes whose true count exceeds target get added to
             ``learned_heavies`` immediately -- next run isolates them.

        Cost: only the codes IN oversized groups are probed (not the
        whole roster).  After 1-2 runs, no group should be oversized
        because heavies are now isolated -- probing naturally stops.

        Failure-tolerant: any individual probe error is logged WARN
        and skipped; the rest continue.  Probing failure never
        propagates -- the download already succeeded by the time we
        run, and analytics/CTL/Deliver mustn't be blocked.

        Returns the number of codes successfully probed (for caller's
        diagnostics).
        """
        if not bool(config.get("probe_enabled", True)):
            self.logger.info(
                "Auto-discovery probe DISABLED (probe_enabled=false).  "
                "Heavies will only be detected when operator-listed "
                "via SINGLE_CODE_LIST."
            )
            return 0

        target = config.get("rows_per_group_target") or 0
        try:
            target = int(target)
        except (TypeError, ValueError):
            target = 0
        if target <= 0:
            return 0  # no target -> no notion of "oversized"

        ratio = float(config.get("probe_oversized_ratio", 1.5))
        oversized = [
            r for r in group_results
            if len(r.get("codes", [])) > 1
            and r.get("row_count", 0) > target * ratio
        ]
        if not oversized:
            self.logger.info(
                "Auto-discovery probe: no oversized groups "
                "(target=%d x %.1f).  Heavies already isolated.",
                target, ratio,
            )
            return 0

        total_codes = sum(len(r["codes"]) for r in oversized)
        parallel = max(1, int(config.get("probe_parallel", 10)))
        est_sec = max(1, total_codes // max(parallel, 1))
        self.logger.info(
            "Auto-discovery probe: %d oversized groups -> %d codes "
            "to probe at parallel=%d (~%d sec).",
            len(oversized), total_codes, parallel, est_sec,
        )

        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _probe(code: str):
            # Build per-code URL: substitute {min}={max}=code so the
            # range filter collapses to one-code-only.  Then derive
            # the $count companion.  Uses the EXACT same machinery as
            # group-level $count -- fresh session, retries, rate limit.
            try:
                base, params, _, _ = self._build_group_url(
                    config, [code], p_gjahr, p_poper,
                )
                count_url = self.derive_count_url(
                    base, params, strip_filter=False,
                )
                n = self._fetch_odata_count(session, count_url, config)
                return code, n, None
            except Exception as exc:
                return code, None, str(exc)

        accurate: Dict[str, int] = {}
        failures: List[str] = []
        with ThreadPoolExecutor(
            max_workers=parallel, thread_name_prefix="sap-probe",
        ) as ex:
            futures = []
            for og in oversized:
                for code in og["codes"]:
                    futures.append(ex.submit(_probe, code))
            for fut in as_completed(futures):
                code, n, err = fut.result()
                if n is not None:
                    accurate[code] = n
                elif err:
                    failures.append(f"{code}: {err}")

        if failures:
            self.logger.warning(
                "Auto-discovery probe: %d probes failed (continuing): %s",
                len(failures), failures[:5],  # log first 5 only
            )
        if not accurate:
            self.logger.warning(
                "Auto-discovery probe: every probe failed -- no history "
                "update.  Run continues; try again next run."
            )
            return 0

        # Top heavies for operator visibility
        top = sorted(accurate.items(), key=lambda kv: -kv[1])[:5]
        self.logger.info(
            "Auto-discovery: probed %d codes successfully.  Top 5 by "
            "TRUE row count:", len(accurate),
        )
        for code, n in top:
            tag = " [will isolate next run]" if n > target else ""
            self.logger.info("  %s -> %d rows%s", code, n, tag)

        # Push into history -- replaces EMA estimates; future runs
        # use these accurate counts to drive walk-pack isolation.
        grouper.ingest_accurate_weights(accurate)
        return len(accurate)

    # -- Output dir + planning artefacts ----------------------------

    def _force_fresh_cleanup(self, task: Dict, config: Dict) -> None:
        """ALWAYS-FRESH semantics (2026-06-07): every download run wipes
        any prior state for this RUN_ID and starts on a clean slate.
        Operator's mental model is "each invocation is independent" --
        no sidecar resume, no checkpoint reuse, no stale-file landmines.

        Files deleted:
          * ``<base>/_sap_state_<run_id>.json`` (sidecar)
          * The run_subdir the sidecar pointed at (per-group CSVs,
            company_codes.csv, groups.csv, run_report.*, .checkpoint.json,
            partial consolidated/compressed/parquet outputs).

        Best-effort -- log warnings on permission errors but never
        raise.  Operator can always manually ``rm -rf`` if needed.
        """
        import shutil
        from steps.sap_odata_state import load_state, state_path

        base = config.get('output_dir') or ''
        run_id = task.get('run_id') or task.get('RUN_ID')
        if not base or run_id is None:
            return
        self.logger.info(
            "Always-fresh: wiping any prior state for run_id=%s",
            run_id,
        )

        # 1. Find + delete the prior run_subdir
        state = load_state(base, run_id, logger=self.logger)
        if state and state.get('run_subdir'):
            prior = state['run_subdir']
            if os.path.isdir(prior):
                try:
                    shutil.rmtree(prior)
                    self.logger.warning(
                        "  removed prior run_subdir: %s", prior,
                    )
                except OSError as exc:
                    self.logger.warning(
                        "  could not rmtree %s: %s", prior, exc,
                    )

        # 2. Delete the sidecar itself
        sidecar = state_path(base, run_id)
        if os.path.exists(sidecar):
            try:
                os.remove(sidecar)
                self.logger.warning(
                    "  removed prior sidecar: %s", sidecar,
                )
            except OSError as exc:
                self.logger.warning(
                    "  could not remove %s: %s", sidecar, exc,
                )

        # 3. Belt-and-braces: also clear any analytics dir for this run
        # (not strictly necessary since it's under run_subdir, but
        # protect against operator-set ANALYTICS_DIR pointing outside).
        adir = config.get('analytics_dir')
        if adir and os.path.isdir(adir) and adir != base:
            try:
                shutil.rmtree(adir)
                self.logger.warning(
                    "  removed analytics dir: %s", adir,
                )
            except OSError:
                pass

    def _resolve_output_dir(
        self, task: Dict, config: Dict,
        p_gjahr: Optional[str], p_poper: Optional[str],
        existing: Optional[str] = None,
    ) -> str:
        """Always-fresh: every run creates a NEW timestamped subdir.

        2026-06-07 simplification: removed sidecar-driven resume and
        the legacy "task['output_dir'] as subdir hint" path.  Each
        download invocation produces a fresh ``<base>/<gjahr>_<poper>_<ts>``
        directory.  ``_force_fresh_cleanup`` already wiped any prior
        run_subdir + sidecar for this RUN_ID before this method runs.

        ``existing`` short-circuit retained ONLY for the in-process
        re-stamp call (when fiscal-period resolution happens AFTER
        the first call -- we keep the dir we just made instead of
        creating a second one).
        """
        if existing and os.path.isdir(existing):
            return existing
        root = config['output_dir']
        gjahr = p_gjahr or 'TBD'
        poper = p_poper or 'TBD'
        subdir = os.path.join(
            root,
            f"{gjahr}_{poper}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        )
        os.makedirs(subdir, exist_ok=True)
        return subdir

    def _dump_codes_csv(self, run_subdir: str, codes: List[str]) -> str:
        """Write the fetched company-code roster to
        ``<run_subdir>/company_codes.csv`` BEFORE any per-group HTTPS
        call.  Lets an operator see what was planned even when the
        SAP service drops the connection mid-run.

        One column: ``Companycode``.  Sorted, deduped (already done by
        ``_fetch_company_codes``).
        """
        import csv
        path = os.path.join(run_subdir, 'company_codes.csv')
        try:
            with open(path, 'w', newline='', encoding='utf-8') as f:
                w = csv.writer(f)
                w.writerow(['Companycode'])
                for c in codes:
                    w.writerow([c])
            self.logger.info(
                "Wrote %d company codes to %s (planning artefact, "
                "safe to inspect during a failed run)",
                len(codes), path,
            )
        except OSError as exc:
            self.logger.warning(
                "Could not write company_codes.csv to %s: %s", path, exc,
            )
        return path

    def _dump_groups_csv(
        self, run_subdir: str, groups: List[List[str]],
    ) -> str:
        """Write the group composition to ``<run_subdir>/groups.csv``
        BEFORE any per-group HTTPS call.

        Columns: ``group_idx, code_position, Companycode, group_min, group_max``.
        One row per (group, code) pair.  An operator can ``grep`` for a
        specific Companycode and see exactly which group's $filter
        range will fetch it.
        """
        import csv
        path = os.path.join(run_subdir, 'groups.csv')
        try:
            with open(path, 'w', newline='', encoding='utf-8') as f:
                w = csv.writer(f)
                w.writerow([
                    'group_idx', 'code_position', 'Companycode',
                    'group_min', 'group_max', 'group_size',
                ])
                for gi, grp in enumerate(groups):
                    sgrp = sorted(grp)
                    gmin = sgrp[0]
                    gmax = sgrp[-1]
                    gsize = len(sgrp)
                    for pos, code in enumerate(sgrp):
                        w.writerow([gi, pos, code, gmin, gmax, gsize])
            self.logger.info(
                "Wrote %d groups (%d total code rows) to %s",
                len(groups), sum(len(g) for g in groups), path,
            )
        except OSError as exc:
            self.logger.warning(
                "Could not write groups.csv to %s: %s", path, exc,
            )
        return path

    # -- URL building (shared by group + full-count paths) --------------

    def _resolve_timestamp(self, config: Dict) -> str:
        """Polling-row RUN_TIMESTAMP wins over live UTC clock -- re-runs
        of the SAME row hit SAP with the same ``{TIMESTAMP}`` placeholder
        for deterministic replay."""
        return (
            (config.get('run_timestamp') or "").strip()
            or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
        )

    def _build_group_url(
        self, config: Dict, group: List[str],
        p_gjahr: str, p_poper: str,
    ) -> tuple:
        """Substitute ``{min}`` / ``{max}`` (and optionally ``{YEAR}`` /
        ``{MONTH}`` / ``{TIMESTAMP}``) into the polling-row
        ``SAP_ME_BALANCE_API`` URL.

        Contract (2026-06-06 -- user-confirmed): the polling row supplies
        the FULL URL with every value already bound EXCEPT the per-group
        company-code range -- only ``{min}`` and ``{max}`` MUST appear.
        Example:

            https://.../claude12Bal(p_gjahr='2026',p_poper='005',
            p_timestamp=datetime'2026-06-05T12:04:21')/Data?
            $filter=( Companycode ge '{min}' and Companycode le '{max}')
            &$format=json

        For back-compat (and the legacy file-mode runner) we ALSO
        substitute ``{YEAR}`` / ``{MONTH}`` / ``{TIMESTAMP}`` when
        present -- ``str.replace`` is a no-op on placeholders not in
        the URL so the simpler ``{min}``/``{max}``-only form wins
        without code changes when the DB sends a fully-bound URL.

        Returns ``(base_url, params_dict, cc_min, cc_max)``.
        ``params_dict`` is empty for the Phase 134 URL-template path
        (filter / format already baked in); populated only on the
        legacy ``sap_base_url + entity_set`` build path.
        """
        template_url = config.get('sap_me_balance_api') or ''
        timestamp = self._resolve_timestamp(config)
        sorted_codes = sorted(group)
        cc_min = sorted_codes[0]
        cc_max = sorted_codes[-1]

        if template_url:
            url = (template_url
                   .replace("{YEAR}",      p_gjahr)
                   .replace("{MONTH}",     p_poper)
                   .replace("{TIMESTAMP}", timestamp)
                   .replace("{min}",       cc_min)
                   .replace("{max}",       cc_max))
            return url, {}, cc_min, cc_max

        # Legacy build path (pre-Phase-134 configs).
        base_url_root = config.get('sap_base_url', '').rstrip('/')
        service_path = config.get('odata_service_path', '')
        entity_set = config.get('entity_set') or 'MEBALParameters'
        filter_style = (config.get('filter_style') or 'eq').lower()
        cc_field = config.get('company_code_field') or 'Companycode'

        base_url = (
            f"{base_url_root}/{service_path}/"
            f"{entity_set}(p_gjahr='{p_gjahr}',p_poper='{p_poper}',"
            f"p_timestamp=datetime'{timestamp}')/Data"
        )
        if filter_style == 'range' and len(group) >= 1:
            code_filter = (
                f"{cc_field} ge '{cc_min}' and "
                f"{cc_field} le '{cc_max}'"
            )
        else:
            code_filter = " or ".join(
                f"{cc_field} eq '{code}'" for code in group
            )
        params = {
            '$filter': f"({code_filter})",
            '$format': 'json',
        }
        return base_url, params, cc_min, cc_max

    def _fetch_full_count(
        self, session, config: Dict, p_gjahr: str, p_poper: str,
    ) -> int:
        """Fetch the unfiltered ``/Data/$count`` for the fiscal period.

        Builds the URL by substituting placeholders as if for a sentinel
        group (the company-code values get stripped along with the
        ``$filter`` query param) so we re-use exactly the same template
        as the data path -- no second source of truth.
        """
        # Use the first group's URL as the template; strip $filter at
        # derive_count_url time.  If we have NO groups (empty company
        # codes) the caller never reaches here -- _execute_step handles
        # empty-codes earlier.
        sentinel_group = ["0000"]
        base_url, params, _, _ = self._build_group_url(
            config, sentinel_group, p_gjahr, p_poper,
        )
        count_url = self.derive_count_url(base_url, params, strip_filter=True)
        return self._fetch_odata_count(session, count_url, config)

    def _reconcile_full_vs_sum(
        self, *, full_count: int, sum_expected: int, sum_actual: int,
        config: Dict,
    ) -> None:
        """Strategic completeness gate.

        Three values must agree:
          * ``full_count``   -- /Data/$count with NO filter
          * ``sum_expected`` -- Sum of per-group /Data/$count?$filter=...
          * ``sum_actual``   -- Sum of rows actually written to disk

        A mismatch between full and sum_expected means the company-code
        partitioning is incomplete (codes missed at the boundary).  A
        mismatch between sum_expected and sum_actual means a paging gap
        -- but the per-group reconcile already catches that, so this is
        belt-and-braces.

        Bypass via ``allow_count_mismatch: true`` in the JSON config
        for the rare legitimate case (a late-arriving SAP posting
        between the full-count fetch and the per-group fetch races
        the totals -- operator decision whether to ship or retry).
        """
        bypass = bool(config.get('allow_count_mismatch', False))
        problems = []

        if sum_expected != full_count:
            problems.append(
                f"Sum(per-group $count)={sum_expected:,} != "
                f"full $count={full_count:,} -- company-code partitioning "
                f"is incomplete (codes outside any group, or boundary "
                f"races between $count calls)"
            )
        if sum_actual != full_count:
            problems.append(
                f"Sum(per-group rows written)={sum_actual:,} != "
                f"full $count={full_count:,} -- downloaded set does not "
                f"cover the full period"
            )

        if not problems:
            self.logger.info(
                "Summation reconcile OK: full=%d == Sumexpected=%d == Sumactual=%d",
                full_count, sum_expected, sum_actual,
            )
            return

        msg = "SAP completeness summation failed: " + "; ".join(problems)
        if bypass:
            self.logger.warning(msg + " -- proceeding per allow_count_mismatch=true")
            return
        raise ValueError(msg)

    def _log_completeness_ledger(
        self, *, full_count: int, sum_expected: int, sum_actual: int,
        group_results: List[Dict], period: str,
    ) -> None:
        """Single visible ledger block -- every completeness gate, every
        verdict.  Operator sees the full picture without scrolling.

        Five gates summarised:

          [G1] Full $count          -- pre-flight reference total
          [G2] Sum(per-group $count)  -- must equal G1
          [G3] Sum(actual rows)       -- must equal G1 (and Sumexpected)
          [G4] Per-group reconcile  -- every group's actual == its $count
          [G5] All groups completed -- no skips, no errors
        """
        ok = "[OK]   "
        bad = "[FAIL] "

        g1 = full_count
        g2 = sum_expected
        g3 = sum_actual
        g2_ok = (g2 == g1)
        g3_ok = (g3 == g1)
        # Per-group: actual==expected enforced inside _download_group,
        # but re-derive here for the ledger so the operator's source of
        # truth is one block of log lines, not "check the per-group
        # exception traceback above for which group fired."
        per_group_mismatch = [
            r for r in group_results
            if r.get('expected_count') is not None
            and r['row_count'] != r['expected_count']
        ]
        g4_ok = not per_group_mismatch
        # All present + no zero-marker without justification.
        groups_with_data = [r for r in group_results if r['row_count'] > 0]
        g5_ok = len(group_results) > 0

        self.logger.info("=" * 72)
        self.logger.info(
            "SAP completeness ledger -- period %s (download stage)", period,
        )
        self.logger.info("=" * 72)
        self.logger.info(
            "  G1 full $count                : %s%d",
            ok, g1,
        )
        self.logger.info(
            "  G2 Sum(per-group $count) == G1  : %s%d vs %d (delta %+d)",
            ok if g2_ok else bad, g2, g1, g2 - g1,
        )
        self.logger.info(
            "  G3 Sum(actual rows)      == G1  : %s%d vs %d (delta %+d)",
            ok if g3_ok else bad, g3, g1, g3 - g1,
        )
        self.logger.info(
            "  G4 per-group actual == $count : %s%d of %d groups match",
            ok if g4_ok else bad,
            len(group_results) - len(per_group_mismatch),
            len(group_results),
        )
        if per_group_mismatch:
            for r in per_group_mismatch:
                self.logger.info(
                    "       group %d: expected %d, actual %d, delta %+d",
                    r['group_idx'], r['expected_count'], r['row_count'],
                    r['row_count'] - r['expected_count'],
                )
        self.logger.info(
            "  G5 all groups present         : %s%d groups total, "
            "%d with data, %d empty (zero-$count)",
            ok if g5_ok else bad,
            len(group_results), len(groups_with_data),
            len(group_results) - len(groups_with_data),
        )
        self.logger.info("=" * 72)

    # -- Per-group orchestration: count -> stream -> reconcile ------------

    def _download_group(
        self, session, config: Dict, group: List[str],
        group_idx: int, p_gjahr: str, p_poper: str, output_dir: str,
    ) -> Dict:
        """One company-code group: $count -> stream -> reconcile, with
        AUTOMATIC RETRY on mismatch.

        Per-group completeness is enforced HERE -- not in a downstream
        step.  If actual != expected (or a network/parse exception
        fires mid-stream), the group is retried in-place:

          * Each retry re-fetches ``$count`` (so we adapt if SAP data
            has changed between attempts).
          * Each retry restreams from page 0 (sink opens with ``'w'``
            which truncates the partial file).
          * Exponential backoff: 5s, 10s, 20s, ... between retries so
            we don't hammer a struggling SAP server.
          * ``group_max_retries`` (default 3) total attempts.
          * If the FINAL attempt still mismatches, raise -- the caller
            does NOT save a checkpoint for this group, so a later
            outer-pipeline retry will start fresh.

        Tunables (polling-row JSON or per-task config):
          group_max_retries     int  default 3   max attempts per group
          group_retry_backoff   float default 5  seconds before 2nd attempt
                                                 (doubles each attempt)
          allow_count_mismatch  bool  default False  ship anyway after retries
        """
        base_url, params, cc_min, cc_max = self._build_group_url(
            config, group, p_gjahr, p_poper,
        )
        output_format = (config.get('output_format') or 'csv').strip().lower()

        # Banner with EXACT URL (placeholders substituted) so an
        # operator can correlate against the SAP audit log.
        self.logger.info(
            f"Group {group_idx}: {len(group)} codes [{cc_min}..{cc_max}] "
            f"for period {p_gjahr}/{p_poper}  format={output_format}"
        )
        self.logger.info(f"Group {group_idx}: data URL = {base_url}")
        if params:
            self.logger.info(f"Group {group_idx}: extra params = {params}")

        count_url = self.derive_count_url(base_url, params, strip_filter=False)
        self.logger.info(f"Group {group_idx}: count URL = {count_url}")

        ext = file_extension_for(output_format)
        file_name = f"mebal_group_{group_idx}_{p_gjahr}_{p_poper}.{ext}"
        file_path = os.path.join(output_dir, file_name)

        max_attempts = max(1, int(config.get('group_max_retries', 3)))
        retry_backoff = float(config.get('group_retry_backoff', 5.0))
        bypass = bool(config.get('allow_count_mismatch', False))

        last_expected: Optional[int] = None
        last_actual: Optional[int] = None
        last_failure: Optional[str] = None

        for attempt in range(1, max_attempts + 1):
            if attempt > 1:
                wait = retry_backoff * (2 ** (attempt - 2))  # 5, 10, 20...
                self.logger.warning(
                    f"Group {group_idx}: waiting {wait:.1f}s before "
                    f"attempt {attempt}/{max_attempts}..."
                )
                time.sleep(wait)
                # -- Explicit chunk cleanup between retries ------
                # The sink would truncate via mode='w' on its next open,
                # but on Windows a slow-released file handle from the
                # previous attempt (Parquet writer holding the footer
                # write) can occasionally block the truncate.  Delete
                # explicitly so the retry starts from a guaranteed-empty
                # slate.  Also prevents a half-written Parquet footer
                # from masquerading as a valid file if the run crashes
                # after the retry's sink open but before any page
                # writes.
                if os.path.exists(file_path):
                    try:
                        os.remove(file_path)
                        self.logger.info(
                            "Group %d: removed partial file %s from "
                            "previous attempt", group_idx, file_path,
                        )
                    except OSError as exc:
                        self.logger.warning(
                            "Group %d: could not remove partial file "
                            "%s (%s) -- sink will truncate on next open",
                            group_idx, file_path, exc,
                        )

            try:
                # -- 1. Pre-flight $count (per attempt) -------------
                # Re-fetch every retry so SAP data drift is visible.
                expected = self._fetch_odata_count(session, count_url, config)
                self.logger.info(
                    f"Group {group_idx} attempt {attempt}: "
                    f"$count = {expected:,} rows expected"
                )

                # -- 2. Zero-expected short-circuit -----------------
                if expected == 0:
                    self.logger.info(
                        f"Group {group_idx}: $count=0 -- writing empty marker"
                    )
                    open(file_path, 'w', encoding='utf-8').close()
                    return {
                        'group_idx':      group_idx,
                        'codes':          group,
                        'expected_count': 0,
                        'row_count':      0,
                        'file_path':      file_path,
                        'attempts':       attempt,
                    }

                # -- 3. Stream pages -> sink (truncates partial file) --
                # If ``intra_group_parallel > 1`` we fire N page fetches
                # in flight at once (mirrors the C# 5-concurrent
                # pattern that finishes 9 M rows in 9 minutes).  Sink
                # writes still happen on the main thread, so the sink
                # itself does NOT need to be thread-safe.
                intra_parallel = max(1, int(config.get(
                    'intra_group_parallel', 1,
                )))
                sink = make_sink(file_path, output_format, logger=self.logger)
                try:
                    if intra_parallel > 1 and expected > 0:
                        page_iter = self._stream_odata_pages_parallel(
                            session, base_url, params, config,
                            expected_count=expected,
                            parallel=intra_parallel,
                        )
                    else:
                        page_iter = self._stream_odata_pages(
                            session, base_url, params, config,
                            expected_count=expected,
                        )
                    for _page_idx, results in page_iter:
                        sink.write_page(results)
                    actual = sink.total_rows
                finally:
                    sink.close()

                last_expected = expected
                last_actual = actual

                # -- 4. Per-group reconcile -------------------------
                if actual == expected:
                    self.logger.info(
                        f"Group {group_idx}: SUCCESS on attempt {attempt} -- "
                        f"streamed {actual:,} rows == $count {expected:,}  "
                        f"-> {file_path}"
                    )
                    return {
                        'group_idx':      group_idx,
                        'codes':          group,
                        'expected_count': expected,
                        'row_count':      actual,
                        'file_path':      file_path,
                        'attempts':       attempt,
                    }

                # Mismatch -- log and loop for next attempt
                last_failure = (
                    f"count mismatch: $count={expected:,} streamed={actual:,} "
                    f"delta={actual - expected:+,}"
                )
                self.logger.warning(
                    f"Group {group_idx} attempt {attempt}/{max_attempts}: "
                    f"{last_failure} -- will retry"
                )

            except Exception as e:
                # Network drop, JSON parse error, $count parse error,
                # SAP returned non-d envelope -- all caught here so the
                # group can retry instead of killing the whole run.
                last_failure = f"{type(e).__name__}: {e}"
                self.logger.warning(
                    f"Group {group_idx} attempt {attempt}/{max_attempts}: "
                    f"{last_failure} -- will retry"
                )

        # -- All retries exhausted ----------------------------------
        msg = (
            f"Group {group_idx} FAILED after {max_attempts} attempts.  "
            f"Last failure: {last_failure}.  "
            f"Last expected={last_expected}, actual={last_actual}.  "
            f"File: {file_path}"
        )
        if bypass and last_actual is not None:
            self.logger.warning(
                msg + " -- proceeding per allow_count_mismatch=true"
            )
            return {
                'group_idx':      group_idx,
                'codes':          group,
                'expected_count': last_expected or 0,
                'row_count':      last_actual,
                'file_path':      file_path,
                'attempts':       max_attempts,
            }
        raise ValueError(msg)
