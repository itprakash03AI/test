"""SAP-flow compress-files step.

Self-contained -- no inheritance from the generic ``CompressFiles``.
Inherits only from ``SapOdataBase`` for the SAP-specific config loader
+ logger setup.

GZips the consolidated CSV (streaming, 64 MB chunks) and computes the
MD5 checksum the SAP CTL contract requires.  FIPS-strict hosts refuse
``hashlib.md5()`` without ``usedforsecurity=False`` -- the kwarg makes
this work on Python 3.9+ while staying compatible with earlier Pythons.
"""
import gzip
import hashlib
import os
from typing import Dict, List

from steps.sap_odata_base import SapOdataBase


class SapCompressFiles(SapOdataBase):
    """GZip the SAP consolidated CSV + compute MD5 for the CTL file."""

    LOG_PREFIX = "sap_compress_files"

    REQUIRED_FIELDS: List[str] = []

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)
        self._hydrate_from_sidecar(task, config)

        source_file = task.get('consolidated_file', '')
        if not source_file or not os.path.exists(source_file):
            raise ValueError(
                f"Consolidated file not found: {source_file!r} -- "
                f"SapConsolidateFiles must run first AND its sidecar "
                f"must point at the consolidated file."
            )

        gzip_level = config.get('gzip_level', 6)
        chunk_size = config.get('gzip_chunk_size', 64 * 1024 * 1024)
        delete_source = config.get('delete_uncompressed', True)

        gz_path = f"{source_file}.gz"
        self.logger.info(
            f"Compressing {source_file} -> {gz_path} (level={gzip_level})"
        )

        # Compute MD5 of the COMPRESSED GZ file (what gets transmitted).
        # Matches the standard SAP BCP "content-encoding:gz" CTL contract
        # where the checksum validates the transmitted bytes.  If your
        # receiver hashes the underlying CSV instead, set
        # ``checksum_source: 'uncompressed'`` in JSON config.
        checksum_source = (
            config.get('checksum_source') or 'compressed'
        ).strip().lower()
        source_size = os.path.getsize(source_file)

        # Hash-while-writing helper: wraps the raw output stream so we
        # capture the GZIPPED bytes as they're produced, no second pass.
        class _HashingStream:
            def __init__(self, inner, hasher):
                self._inner = inner
                self._hasher = hasher

            def write(self, data):
                self._hasher.update(data)
                return self._inner.write(data)

            def flush(self):
                return self._inner.flush()

            def close(self):
                return self._inner.close()

        # FIPS-safe MD5 -- the CTL checksum is integrity, not crypto.
        # OpenShift's FIPS-enabled hosts refuse ``hashlib.md5()``
        # without ``usedforsecurity=False`` (Py 3.9+).  Try the kwarg
        # first, fall back for older Pythons.
        def _md5():
            try:
                return hashlib.md5(usedforsecurity=False)
            except TypeError:  # pragma: no cover -- Py < 3.9
                return hashlib.md5()

        md5_hash = _md5()

        if checksum_source == 'compressed':
            # Hash the gz bytes as they're written
            with open(source_file, 'rb') as f_in:
                with open(gz_path, 'wb') as raw_out:
                    hashed_out = _HashingStream(raw_out, md5_hash)
                    with gzip.GzipFile(
                        fileobj=hashed_out, mode='wb',
                        compresslevel=gzip_level,
                    ) as f_out:
                        while True:
                            chunk = f_in.read(chunk_size)
                            if not chunk:
                                break
                            f_out.write(chunk)
        else:  # 'uncompressed' -- hash the CSV input bytes
            with open(source_file, 'rb') as f_in:
                with gzip.open(
                    gz_path, 'wb', compresslevel=gzip_level,
                ) as f_out:
                    while True:
                        chunk = f_in.read(chunk_size)
                        if not chunk:
                            break
                        md5_hash.update(chunk)
                        f_out.write(chunk)

        compressed_size = os.path.getsize(gz_path)
        # UPPERCASE per SAP CTL convention (matches the example checksum
        # ``52FA2A1B8104FB1E4CA5E235E33FD6A2`` the user shared).
        checksum = md5_hash.hexdigest().upper()
        ratio = (1 - compressed_size / source_size) * 100 if source_size > 0 else 0

        self.logger.info(
            f"Compression complete: {source_size:,} -> {compressed_size:,} bytes "
            f"({ratio:.1f}% reduction), MD5={checksum} "
            f"(source={checksum_source})"
        )

        # 2026-06-07 -- POST-COMPRESS VERIFICATION.  User reported
        # "gz has files same as total record counts" -- ambiguous,
        # could mean:
        #   (a) the gz contains 9M files (would mean multi-stream gz)
        #   (b) the gz extracts to a CSV with 9M lines (CORRECT)
        # This block reads back the gz + counts:
        #   * gzip magic numbers (=== number of concatenated streams)
        #   * lines in the decompressed content
        # If streams > 1, that's a bug; if streams == 1 + lines ~
        # row count, the gz is correct and the operator's tooling is
        # mis-rendering.
        try:
            with open(gz_path, 'rb') as gf:
                raw = gf.read()
            stream_count = 0
            for i in range(len(raw) - 1):
                if raw[i:i+2] == b'\x1f\x8b':
                    stream_count += 1
            line_count = 0
            with gzip.open(gz_path, 'rt', encoding='utf-8',
                            errors='replace') as gf:
                for _ in gf:
                    line_count += 1
            expected_lines = int(task.get('totalcount', 0)) + 1  # +header
            verdict = (
                "OK" if (stream_count == 1
                          and abs(line_count - expected_lines) <= 1)
                else "MISMATCH -- INVESTIGATE"
            )
            self.logger.info(
                "Gz verification: %s "
                "(gzip streams=%d [expect 1], "
                "decompressed lines=%d [expect ~%d = rows+header])",
                verdict, stream_count, line_count, expected_lines,
            )
            if stream_count != 1:
                self.logger.error(
                    "MULTI-STREAM GZ DETECTED at %s -- some extraction "
                    "tools render concatenated gz streams as multiple "
                    "files.  This is a real bug.  Streams=%d.",
                    gz_path, stream_count,
                )
        except Exception as exc:
            self.logger.warning(
                "Gz verification failed (not fatal): %s", exc,
            )

        task['compressed_file'] = gz_path
        task['checksum'] = checksum
        task['checksum_source'] = checksum_source  # for CTL transparency
        task['compressed_size'] = compressed_size
        task['uncompressed_size'] = source_size

        # Persist compress state to sidecar for CTL / Deliver /
        # CheckCompleteness on their separate task dicts.
        self._save_sidecar(task, config)

        if delete_source:
            os.remove(source_file)
            self.logger.info(f"Deleted uncompressed file: {source_file}")

        return task.get('totalcount', 0)
