"""
Smart company code grouping for SAP OData parallel downloads.
First run: even distribution across N groups.
Subsequent runs: greedy bin-packing based on historical per-code row counts.
History persisted to JSON on NFS.
"""
import json
import os
import logging
from typing import Dict, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class CompanyCodeGrouper:
    """Groups SAP company codes into download batches.

    Policy (post-2026-06-07): groups are sized by **codes per group**,
    not by a fixed bucket count.  Operator specifies how many codes
    fit comfortably in ONE OData ``$filter`` (default 100); we then
    compute ``ceil(total_codes / codes_per_group)`` buckets.

    Why: SAP services rate-limit on per-request payload + render time;
    a single group with 1000 codes in the ``$filter`` clause times out,
    a group with 100 codes responds reliably.  Fixing the codes-per-
    group ceiling gives predictable per-request latency regardless of
    how many codes the tenant has.

    Back-compat: ``num_groups`` is still accepted; ``codes_per_group``
    wins when both are set.  A request for ``codes_per_group=0`` falls
    back to ``num_groups`` (legacy bucket-count behaviour).
    """

    DEFAULT_CODES_PER_GROUP = 100

    def __init__(
        self, history_path: str,
        num_groups: Optional[int] = None,
        codes_per_group: Optional[int] = None,
    ):
        self.history_path = history_path
        self.num_groups = num_groups
        self.codes_per_group = (
            codes_per_group
            if codes_per_group is not None
            else self.DEFAULT_CODES_PER_GROUP
        )
        self.history = self._load_history()

    def _effective_num_groups(self, total_codes: int) -> int:
        """Resolve final bucket count from total + codes_per_group + num_groups.

        Precedence:
          1. ``codes_per_group > 0`` -> ceil(total / codes_per_group)
          2. ``num_groups``         -> that exact count (legacy)
          3. default                -> DEFAULT_CODES_PER_GROUP
        """
        if self.codes_per_group and self.codes_per_group > 0:
            import math
            n = max(1, math.ceil(total_codes / self.codes_per_group))
            logger.info(
                "Grouper: codes_per_group=%d, total_codes=%d -> %d groups",
                self.codes_per_group, total_codes, n,
            )
            return n
        if self.num_groups and self.num_groups > 0:
            logger.info(
                "Grouper: legacy num_groups=%d (codes_per_group not set)",
                self.num_groups,
            )
            return self.num_groups
        import math
        n = max(1, math.ceil(total_codes / self.DEFAULT_CODES_PER_GROUP))
        logger.info(
            "Grouper: defaulting to %d codes/group -> %d groups",
            self.DEFAULT_CODES_PER_GROUP, n,
        )
        return n

    def _load_history(self) -> Dict:
        """Load grouping history from NFS JSON file."""
        if os.path.exists(self.history_path):
            try:
                with open(self.history_path, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                logger.warning(f"Failed to load history from {self.history_path}: {e}")
        return {"runs": [], "code_weights": {}}

    def _save_history(self):
        """Persist history to NFS."""
        os.makedirs(os.path.dirname(self.history_path), exist_ok=True)
        with open(self.history_path, 'w') as f:
            json.dump(self.history, f, indent=2, default=str)

    def group_codes(self, company_codes: List[str]) -> List[List[str]]:
        """Group company codes into balanced groups.

        First run (no history): codes-per-group ceiling, contiguous split
        (preserves natural code ordering -- codes 8100..8199 in group 0,
        8200..8299 in group 1, etc.) so the per-group ``$filter`` uses
        a tight range bound.
        Subsequent runs: greedy bin-packing by historical weight, with
        the SAME total bucket count.
        """
        if not company_codes:
            return []

        n = min(self._effective_num_groups(len(company_codes)), len(company_codes))

        if not self.history.get("code_weights"):
            logger.info(
                f"First run: {len(company_codes)} codes -> "
                f"{n} groups (~{self.codes_per_group or '?'} codes/group)"
            )
            return self._contiguous_split(company_codes, n)

        weights = self.history["code_weights"]
        logger.info(
            f"Using historical weights for {len(weights)} codes, "
            f"bin-packing {len(company_codes)} codes into {n} groups"
        )
        return self._bin_pack(company_codes, weights, n)

    def record_results(self, group_results: List[Dict]):
        """Record per-group results after a download run.

        group_results: [{"codes": ["1001", "1002"], "row_count": 150000}, ...]

        Updates per-code weights using exponential moving average (α=0.3).
        """
        alpha = 0.3

        for result in group_results:
            codes = result["codes"]
            total_rows = result["row_count"]
            per_code = total_rows / max(len(codes), 1)

            for code in codes:
                old_weight = self.history["code_weights"].get(code, per_code)
                new_weight = alpha * per_code + (1 - alpha) * old_weight
                self.history["code_weights"][code] = round(new_weight, 1)

        self.history["runs"].append({
            "timestamp": datetime.utcnow().isoformat(),
            "total_groups": len(group_results),
            "total_rows": sum(r["row_count"] for r in group_results),
        })

        # Keep only last 30 runs
        if len(self.history["runs"]) > 30:
            self.history["runs"] = self.history["runs"][-30:]

        self._save_history()
        logger.info(f"Recorded results for {len(group_results)} groups, weights updated")

    @staticmethod
    def _even_split(items: List[str], n: int) -> List[List[str]]:
        """Round-robin split (legacy).  Scatters codes across groups so
        each gets a similar count.  **Unsafe with range $filter** --
        produces overlapping ranges (group 0 = '1000','8116', group 1
        = '1010','8117' -> range '1000'..'8116' overlaps with
        '1010'..'8117').  Kept for back-compat with the old num_groups
        path.  New runs use ``_contiguous_split`` instead.
        """
        groups = [[] for _ in range(n)]
        for i, item in enumerate(items):
            groups[i % n].append(item)
        return [g for g in groups if g]

    @staticmethod
    def _contiguous_split(items: List[str], n: int) -> List[List[str]]:
        """Split items into n contiguous slices preserving sort order.

        With ``items = sorted(codes)`` and ``n = ceil(len/codes_per_group)``,
        adjacent groups never overlap in code space:

            items = ['1000','1010','8116','8117','8128']  (sorted)
            n = 3, codes_per_group = 2
            -> group 0: ['1000','1010']  range '1000'..'1010'
              group 1: ['8116','8117']  range '8116'..'8117'
              group 2: ['8128']         range '8128'..'8128'

        This is the safe partition for range-filter ``$filter=(
        Companycode ge '{min}' and Companycode le '{max}')`` because
        groups never reach into each other's space.  Per-group $count
        responses sum exactly to the full $count IF the
        SAP_COMPANY_API roster includes EVERY code that has MEBAL
        data -- see the gap warning in the class docstring.
        """
        if n <= 0 or not items:
            return []
        # Ceiling chunk size so the LAST group doesn't get
        # disproportionately fewer codes when len(items) % n != 0.
        import math
        chunk = max(1, math.ceil(len(items) / n))
        return [items[i:i + chunk] for i in range(0, len(items), chunk)]

    @staticmethod
    def _bin_pack(
        codes: List[str], weights: Dict[str, float], num_groups: int
    ) -> List[List[str]]:
        """Greedy bin-packing: largest-first-fit-decreasing.
        Assigns heaviest codes first to the lightest group.
        """
        default_weight = sum(weights.values()) / max(len(weights), 1) if weights else 1.0

        weighted_codes = [
            (code, weights.get(code, default_weight))
            for code in codes
        ]
        weighted_codes.sort(key=lambda x: x[1], reverse=True)

        groups = [[] for _ in range(num_groups)]
        group_weights = [0.0] * num_groups

        for code, weight in weighted_codes:
            min_idx = group_weights.index(min(group_weights))
            groups[min_idx].append(code)
            group_weights[min_idx] += weight

        # Log balance quality
        non_empty = [w for w in group_weights if w > 0]
        if non_empty:
            max_w = max(non_empty)
            min_w = min(non_empty)
            imbalance = (max_w - min_w) / max_w * 100 if max_w > 0 else 0
            logger.info(
                f"Bin-packed {len(codes)} codes into {num_groups} groups. "
                f"Weight range: {min_w:.0f} - {max_w:.0f} (imbalance: {imbalance:.1f}%)"
            )

        return [g for g in groups if g]
