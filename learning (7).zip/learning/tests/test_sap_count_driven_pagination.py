"""Phase 134-N — count-driven streaming pagination + summation reconcile.

Exercises the strategic abstractions added to the SAP OData pipeline:

  * ``derive_count_url``           — URL transform: /Data → /Data/$count,
                                      strip $format/$top/$skip, retain
                                      $filter (or strip on demand).
  * ``_fetch_odata_count``         — parses plain-text + JSON-envelope
                                      $count responses.
  * ``_stream_odata_pages``        — generator yields page-by-page (no
                                      aggregation).
  * ``make_sink('csv'|'parquet')`` — strategy selector, page-streaming
                                      writers.
  * Per-group reconcile            — actual rows MUST equal $count.
  * Summation reconcile            — Σ(per-group $count) MUST equal
                                      unfiltered /Data/$count.
"""
from __future__ import annotations

import csv
import json
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest


ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ── derive_count_url ────────────────────────────────────────────────


class TestDeriveCountUrl:
    def test_basic_data_to_count(self):
        from steps.sap_odata_base import SapOdataBase
        url = (
            "https://sap.example.com/sap/opu/odata/sap/zfi_srv/"
            "Bal(p_gjahr='2026',p_poper='005',p_timestamp=datetime'2026-06-05T12:04:21')"
            "/Data?$filter=(Companycode%20ge%20%278116%27%20and%20"
            "Companycode%20le%20%278128%27)&$format=json"
        )
        count = SapOdataBase.derive_count_url(url)
        # Path got /$count appended.
        assert "/Data/%24count" in count or "/Data/$count" in count
        # $filter retained (urlencoded or not, the substring is there).
        assert "%24filter" in count or "$filter" in count
        # $format stripped.
        assert "format=json" not in count

    def test_strip_filter_for_full_count(self):
        from steps.sap_odata_base import SapOdataBase
        url = (
            "https://sap.example.com/Bal(p_gjahr='2026',p_poper='005')/Data"
            "?$filter=(X%20eq%20%27Y%27)&$format=json"
        )
        full = SapOdataBase.derive_count_url(url, strip_filter=True)
        assert "filter" not in full  # filter gone
        assert "format" not in full  # format gone
        assert full.endswith("/Data/$count") or full.endswith("/Data/%24count")

    def test_count_url_strips_top_and_skip(self):
        from steps.sap_odata_base import SapOdataBase
        url = "https://sap.example/Bal/Data?$filter=(X%20eq%20%271%27)&$top=500&$skip=2000"
        count = SapOdataBase.derive_count_url(url)
        assert "top=500" not in count
        assert "skip=2000" not in count

    def test_count_url_merges_params_dict(self):
        from steps.sap_odata_base import SapOdataBase
        # Legacy build path passes params as a dict.
        url = "https://sap.example/Bal/Data"
        params = {"$filter": "(X eq '1')", "$format": "json"}
        count = SapOdataBase.derive_count_url(url, params)
        assert "filter" in count
        assert "format=json" not in count


# ── _fetch_odata_count ──────────────────────────────────────────────


class TestFetchOdataCount:
    def _step(self):
        from steps.sap_odata_base import SapOdataBase

        class _Probe(SapOdataBase):
            async def _execute_step(self, *args, **kwargs):
                return 0

        return _Probe(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def _resp(self, *, text=None, json_body=None):
        r = MagicMock()
        r.raise_for_status.return_value = None
        if text is not None:
            r.text = text
        if json_body is not None:
            r.text = json.dumps(json_body)
        return r

    def test_plain_text_integer(self):
        step = self._step()
        sess = MagicMock()
        sess.get.return_value = self._resp(text="125000\n")
        n = step._fetch_odata_count(
            sess, "https://sap.example/Bal/Data/$count",
            {"rate_limit_rps": 1000},
        )
        assert n == 125000

    def test_json_envelope_d_integer(self):
        step = self._step()
        sess = MagicMock()
        sess.get.return_value = self._resp(json_body={"d": "42"})
        n = step._fetch_odata_count(sess, "https://x", {"rate_limit_rps": 1000})
        assert n == 42

    def test_json_envelope_inner_count(self):
        step = self._step()
        sess = MagicMock()
        sess.get.return_value = self._resp(
            json_body={"d": {"__count": "9876"}}
        )
        n = step._fetch_odata_count(sess, "https://x", {"rate_limit_rps": 1000})
        assert n == 9876

    def test_invalid_body_raises(self):
        step = self._step()
        sess = MagicMock()
        sess.get.return_value = self._resp(text="<html>error</html>")
        with pytest.raises(ValueError, match="not an integer"):
            step._fetch_odata_count(sess, "https://x", {"rate_limit_rps": 1000})

    def test_sets_text_plain_accept(self):
        step = self._step()
        sess = MagicMock()
        sess.get.return_value = self._resp(text="7")
        step._fetch_odata_count(sess, "https://x", {"rate_limit_rps": 1000})
        # The session.get must have been called with Accept: text/plain
        args, kwargs = sess.get.call_args
        assert kwargs["headers"]["Accept"] == "text/plain"


# ── _stream_odata_pages ─────────────────────────────────────────────


class TestStreamOdataPages:
    def _step(self):
        from steps.sap_odata_base import SapOdataBase

        class _Probe(SapOdataBase):
            async def _execute_step(self, *args, **kwargs):
                return 0

        return _Probe(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def _build_session(self, page_responses):
        sess = MagicMock()
        resps = []
        for p in page_responses:
            r = MagicMock()
            r.raise_for_status.return_value = None
            r.json.return_value = {"d": p}
            resps.append(r)
        sess.get.side_effect = resps
        return sess

    def test_generator_yields_pages(self):
        step = self._step()
        sess = self._build_session([
            {"results": [{"i": 0}, {"i": 1}]},
            {"results": [{"i": 2}]},
        ])
        pages = list(step._stream_odata_pages(
            sess, "https://x", {}, {"page_size": 2, "rate_limit_rps": 1000},
        ))
        assert [p[0] for p in pages] == [0, 1]
        assert sum(len(p[1]) for p in pages) == 3

    def test_empty_first_page_yields_nothing(self):
        step = self._step()
        sess = self._build_session([{"results": []}])
        # First page IS the data envelope; empty results → no yield, no error.
        # _stream_odata_pages validates the ``d`` envelope before checking
        # results, so an empty d.results is the "no data" path.
        pages = list(step._stream_odata_pages(
            sess, "https://x", {}, {"page_size": 10, "rate_limit_rps": 1000},
        ))
        assert pages == []


# ── Sinks (CSV + Parquet) ───────────────────────────────────────────


class TestPageSinks:
    def test_csv_sink_streams_pages_to_file(self, tmp_path):
        from steps.sap_odata_sinks import CsvPageSink

        path = tmp_path / "out.csv"
        sink = CsvPageSink(str(path))
        sink.write_page([{"a": "1", "b": "2"}])
        sink.write_page([{"a": "3", "b": "4"}, {"a": "5", "b": "6"}])
        sink.close()

        with open(path, newline="") as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == 3
        assert sink.total_rows == 3

    def test_csv_sink_drops_odata_metadata(self, tmp_path):
        from steps.sap_odata_sinks import CsvPageSink

        path = tmp_path / "out.csv"
        sink = CsvPageSink(str(path))
        sink.write_page([{
            "a": "x",
            "__metadata": {"id": "foo"},
            "__deferred": "bar",
            "": "blank-key",
        }])
        sink.close()
        with open(path, newline="") as f:
            header = next(csv.reader(f))
        assert header == ["a"]

    def test_csv_sink_late_columns_dropped(self, tmp_path):
        from steps.sap_odata_sinks import CsvPageSink

        path = tmp_path / "out.csv"
        sink = CsvPageSink(str(path))
        sink.write_page([{"a": "1"}])           # schema = ["a"]
        sink.write_page([{"a": "2", "x": "9"}])  # x dropped
        sink.close()
        with open(path, newline="") as f:
            rows = list(csv.DictReader(f))
        assert rows == [{"a": "1"}, {"a": "2"}]

    def test_parquet_sink_one_rowgroup_per_page(self, tmp_path):
        pq = pytest.importorskip("pyarrow.parquet")
        from steps.sap_odata_sinks import ParquetPageSink

        path = tmp_path / "out.parquet"
        sink = ParquetPageSink(str(path))
        sink.write_page([{"a": 1, "b": "x"}, {"a": 2, "b": "y"}])
        sink.write_page([{"a": 3, "b": "z"}])
        sink.close()
        assert sink.total_rows == 3
        pf = pq.ParquetFile(str(path))
        # Two pages → two row-groups.
        assert pf.num_row_groups == 2

    def test_make_sink_strategy_selector(self, tmp_path):
        from steps.sap_odata_sinks import (
            CsvPageSink, ParquetPageSink, make_sink,
        )
        assert isinstance(make_sink(str(tmp_path / "a.csv"), "csv"),
                          CsvPageSink)
        # Parquet sink only if pyarrow is available.
        pytest.importorskip("pyarrow")
        assert isinstance(make_sink(str(tmp_path / "a.parquet"), "parquet"),
                          ParquetPageSink)
        with pytest.raises(ValueError):
            make_sink(str(tmp_path / "a.bad"), "ndjson")


# ── Download integration: per-group count→stream→reconcile ─────────


class TestDownloadGroupCountFlow:
    def _step(self):
        from steps.sap_odata_download import SapOdataDownload
        return SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def _session(self, *, count_value: int, pages: list):
        """Build a session whose .get returns count text first then
        the data pages in order."""
        sess = MagicMock()
        responses = []
        count_resp = MagicMock()
        count_resp.raise_for_status.return_value = None
        count_resp.text = str(count_value)
        responses.append(count_resp)
        for p in pages:
            r = MagicMock()
            r.raise_for_status.return_value = None
            r.json.return_value = {"d": p}
            responses.append(r)
        sess.get.side_effect = responses
        return sess

    def test_group_actual_matches_expected_passes(self, tmp_path):
        step = self._step()
        # 3 rows expected; 2 pages of 2 + 1 = 3 rows.
        sess = self._session(
            count_value=3,
            pages=[
                {"results": [{"k": "v1"}, {"k": "v2"}]},
                {"results": [{"k": "v3"}]},
            ],
        )
        cfg = {
            "sap_me_balance_api": (
                "https://sap.example/Bal(p_gjahr='2026',p_poper='005',"
                "p_timestamp=datetime'2026-06-05T12:04:21')/Data?"
                "$filter=( Companycode ge '{min}' and Companycode le '{max}')"
                "&$format=json"
            ),
            "page_size": 2,
            "rate_limit_rps": 1000,
            "output_format": "csv",
            "group_retry_backoff": 0,
        }
        result = step._download_group(
            sess, cfg, ["8116", "8120", "8128"], 0, "2026", "005",
            str(tmp_path),
        )
        assert result["expected_count"] == 3
        assert result["row_count"] == 3
        assert result["attempts"] == 1

    def test_group_mismatch_retries_then_raises(self, tmp_path):
        step = self._step()
        # Count says 5; every attempt streams only 2.
        # With max_attempts=2 the second attempt also fails → raise.
        sess = self._session(
            count_value=5,
            pages=[
                {"results": [{"k": "v1"}, {"k": "v2"}]},
                {"results": []},
                # Retry attempt — re-fetches $count, restreams
                {"results": [{"k": "v1"}, {"k": "v2"}]},
                {"results": []},
            ],
        )
        # Refresh side_effect with count → pages → count → pages pattern
        responses = []
        count_resp = MagicMock(); count_resp.raise_for_status.return_value = None
        count_resp.text = "5"
        for _ in range(2):  # 2 attempts × ($count + 2 pages)
            responses.append(count_resp)
            for p in [{"results": [{"k": "v1"}, {"k": "v2"}]},
                       {"results": []}]:
                r = MagicMock(); r.raise_for_status.return_value = None
                r.json.return_value = {"d": p}
                responses.append(r)
        sess.get.side_effect = responses

        cfg = {
            "sap_me_balance_api": (
                "https://sap.example/Bal/Data?$filter=("
                " Companycode ge '{min}' and Companycode le '{max}')"
            ),
            "page_size": 2,
            "rate_limit_rps": 1000,
            "output_format": "csv",
            "group_max_retries": 2,
            "group_retry_backoff": 0,   # no sleeps in tests
        }
        with pytest.raises(ValueError, match="FAILED after 2 attempts"):
            step._download_group(
                sess, cfg, ["8116"], 0, "2026", "005", str(tmp_path),
            )

    def test_group_mismatch_recovers_on_second_attempt(self, tmp_path):
        """Transient SAP race: attempt 1 streams 2/5, attempt 2 streams
        5/5.  The download step should SUCCEED with attempts=2."""
        step = self._step()
        sess = MagicMock()
        # 1st attempt: count=5, stream 2 → mismatch
        # 2nd attempt: count=5, stream 5 → success
        responses = []
        # $count for attempt 1
        c1 = MagicMock(); c1.raise_for_status.return_value = None
        c1.text = "5"
        responses.append(c1)
        # 2 pages of 2 each then empty (attempt 1 streams 2, then empty,
        # because the empty page terminates)
        for p in [{"results": [{"k": 1}, {"k": 2}]},
                  {"results": []}]:
            r = MagicMock(); r.raise_for_status.return_value = None
            r.json.return_value = {"d": p}
            responses.append(r)
        # $count for attempt 2
        c2 = MagicMock(); c2.raise_for_status.return_value = None
        c2.text = "5"
        responses.append(c2)
        # 3 pages: 2+2+1 = 5 rows (matches expected)
        for p in [{"results": [{"k": 1}, {"k": 2}]},
                  {"results": [{"k": 3}, {"k": 4}]},
                  {"results": [{"k": 5}]}]:
            r = MagicMock(); r.raise_for_status.return_value = None
            r.json.return_value = {"d": p}
            responses.append(r)
        sess.get.side_effect = responses

        cfg = {
            "sap_me_balance_api": (
                "https://sap.example/Bal/Data?$filter=("
                " Companycode ge '{min}' and Companycode le '{max}')"
            ),
            "page_size": 2,
            "rate_limit_rps": 1000,
            "output_format": "csv",
            "group_max_retries": 3,
            "group_retry_backoff": 0,
        }
        result = step._download_group(
            sess, cfg, ["8116"], 0, "2026", "005", str(tmp_path),
        )
        assert result["row_count"] == 5
        assert result["expected_count"] == 5
        assert result["attempts"] == 2  # succeeded on 2nd try

    def test_group_network_exception_retries(self, tmp_path):
        """A connection-drop mid-stream on attempt 1 should still let
        attempt 2 succeed (no whole-pipeline failure)."""
        step = self._step()
        sess = MagicMock()
        # Attempt 1: $count OK then page fetch raises
        c1 = MagicMock(); c1.raise_for_status.return_value = None
        c1.text = "2"
        # Attempt 2: $count OK + 1 page of 2 rows
        c2 = MagicMock(); c2.raise_for_status.return_value = None
        c2.text = "2"
        page_ok = MagicMock(); page_ok.raise_for_status.return_value = None
        page_ok.json.return_value = {"d": {"results": [{"k": 1}, {"k": 2}]}}
        page_end = MagicMock(); page_end.raise_for_status.return_value = None
        page_end.json.return_value = {"d": {"results": []}}

        from requests.exceptions import ConnectionError as ReqConnErr
        # Sequence: count1, RAISE (mid-stream), count2, page_ok, page_end
        sess.get.side_effect = [
            c1,
            ReqConnErr("connection reset by peer"),
            c2,
            page_ok,
            page_end,
        ]

        cfg = {
            "sap_me_balance_api": (
                "https://sap.example/Bal/Data?$filter=("
                " Companycode ge '{min}' and Companycode le '{max}')"
            ),
            "page_size": 2,
            "rate_limit_rps": 1000,
            "output_format": "csv",
            "group_max_retries": 3,
            "group_retry_backoff": 0,
        }
        result = step._download_group(
            sess, cfg, ["8116"], 0, "2026", "005", str(tmp_path),
        )
        assert result["row_count"] == 2
        assert result["attempts"] == 2

    def test_group_mismatch_bypassed_with_flag(self, tmp_path):
        step = self._step()
        sess = MagicMock()
        # 2 attempts × ($count=5 + 2 partial pages)
        responses = []
        for _ in range(2):
            c = MagicMock(); c.raise_for_status.return_value = None
            c.text = "5"
            responses.append(c)
            for p in [{"results": [{"k": "v1"}, {"k": "v2"}]},
                      {"results": []}]:
                r = MagicMock(); r.raise_for_status.return_value = None
                r.json.return_value = {"d": p}
                responses.append(r)
        sess.get.side_effect = responses

        cfg = {
            "sap_me_balance_api": (
                "https://sap.example/Bal/Data?$filter=("
                " Companycode ge '{min}' and Companycode le '{max}')"
            ),
            "page_size": 2,
            "rate_limit_rps": 1000,
            "output_format": "csv",
            "group_max_retries": 2,
            "group_retry_backoff": 0,
            "allow_count_mismatch": True,
        }
        result = step._download_group(
            sess, cfg, ["8116"], 0, "2026", "005", str(tmp_path),
        )
        assert result["row_count"] == 2
        assert result["expected_count"] == 5

    def test_zero_expected_short_circuits(self, tmp_path):
        step = self._step()
        sess = self._session(count_value=0, pages=[])  # never paged
        cfg = {
            "sap_me_balance_api": (
                "https://sap.example/Bal/Data?$filter=("
                " Companycode ge '{min}' and Companycode le '{max}')"
            ),
            "page_size": 2,
            "rate_limit_rps": 1000,
            "output_format": "csv",
            "group_retry_backoff": 0,
        }
        result = step._download_group(
            sess, cfg, ["8116"], 0, "2026", "005", str(tmp_path),
        )
        assert result["row_count"] == 0
        assert result["expected_count"] == 0
        # Marker file exists but is empty.
        assert os.path.exists(result["file_path"])
        assert os.path.getsize(result["file_path"]) == 0
        # Only the $count GET — no data fetches.
        assert sess.get.call_count == 1


# ── Summation reconcile ────────────────────────────────────────────


class TestSummationReconcile:
    def _step(self):
        from steps.sap_odata_download import SapOdataDownload
        return SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def test_sum_equals_full_passes(self):
        step = self._step()
        step._reconcile_full_vs_sum(
            full_count=100, sum_expected=100, sum_actual=100, config={},
        )

    def test_sum_expected_mismatch_raises(self):
        step = self._step()
        with pytest.raises(ValueError, match="partitioning is incomplete"):
            step._reconcile_full_vs_sum(
                full_count=100, sum_expected=99, sum_actual=99, config={},
            )

    def test_sum_actual_mismatch_raises(self):
        step = self._step()
        with pytest.raises(ValueError, match="downloaded set does not"):
            step._reconcile_full_vs_sum(
                full_count=100, sum_expected=100, sum_actual=98, config={},
            )

    def test_mismatch_bypass_flag(self):
        step = self._step()
        # Should NOT raise.
        step._reconcile_full_vs_sum(
            full_count=100, sum_expected=99, sum_actual=99,
            config={"allow_count_mismatch": True},
        )


# ── Page-size resolution + 50K hard cap ────────────────────────────


class TestPageSizeClamp:
    """Strategic chunk-size policy: small chunks beat big ones on a
    slow SAP API.  MAX_TOP=50000 is the hard ceiling — even if an
    operator sets PAGE_SIZE=100000 on the polling row we clamp down."""

    def _step(self):
        from steps.sap_odata_base import SapOdataBase

        class _Probe(SapOdataBase):
            async def _execute_step(self, *args, **kwargs):
                return 0

        return _Probe(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def test_default_is_50000(self):
        """SQL polling query supplies PAGE_SIZE=50000.  When the row
        leaves it NULL the Python default kicks in — also 50K."""
        step = self._step()
        assert step._resolve_page_size({}) == 50000

    def test_clamps_to_max_top(self):
        step = self._step()
        # Legacy config / typo on the row → clamped to 50000.
        assert step._resolve_page_size({"page_size": 100000}) == 50000

    def test_below_max_unchanged(self):
        step = self._step()
        assert step._resolve_page_size({"page_size": 25000}) == 25000

    def test_zero_falls_back_to_default(self):
        step = self._step()
        assert step._resolve_page_size({"page_size": 0}) == 50000

    def test_string_value_falls_back_to_default(self):
        step = self._step()
        assert step._resolve_page_size({"page_size": "not-an-int"}) == 50000

    def test_polling_row_page_size_overlays(self, tmp_path):
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "SAPU": "u", "SAPP": "p",
            "SAP_COMPANY_API": "x",
            "SAP_ME_BALANCE_API": "y",
            "OUTPUT_DIR": str(tmp_path),
            "PAGE_SIZE": 2000,
        }
        cfg = step._load_and_validate_config(
            task, SapOdataDownload.REQUIRED_FIELDS,
        )
        assert cfg["page_size"] == 2000
        # And the resolver respects it.
        assert step._resolve_page_size(cfg) == 2000


class TestVerifySslOverlay:
    """``'TRUE'`` / ``'FALSE'`` on the polling row (Oracle char column)
    → real Python bool in config['verify_ssl']."""

    def _step(self, tmp_path):
        from steps.sap_odata_download import SapOdataDownload
        return SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def _base_task(self, tmp_path):
        return {
            "SAPU": "u", "SAPP": "p",
            "SAP_COMPANY_API": "x",
            "SAP_ME_BALANCE_API": "y",
            "OUTPUT_DIR": str(tmp_path),
        }

    def test_verify_ssl_false_string_becomes_false(self, tmp_path):
        step = self._step(tmp_path)
        task = self._base_task(tmp_path)
        task["VERIFY_SSL"] = "FALSE"
        cfg = step._load_and_validate_config(task, [])
        assert cfg["verify_ssl"] is False

    def test_verify_ssl_true_string_becomes_true(self, tmp_path):
        step = self._step(tmp_path)
        task = self._base_task(tmp_path)
        task["VERIFY_SSL"] = "TRUE"
        cfg = step._load_and_validate_config(task, [])
        assert cfg["verify_ssl"] is True

    def test_verify_ssl_case_insensitive(self, tmp_path):
        step = self._step(tmp_path)
        task = self._base_task(tmp_path)
        task["VERIFY_SSL"] = "false"  # lowercase
        cfg = step._load_and_validate_config(task, [])
        assert cfg["verify_ssl"] is False

    def test_verify_ssl_unknown_defaults_to_true(self, tmp_path):
        step = self._step(tmp_path)
        task = self._base_task(tmp_path)
        task["VERIFY_SSL"] = "maybe"
        cfg = step._load_and_validate_config(task, [])
        assert cfg["verify_ssl"] is True

    def test_verify_ssl_missing_leaves_default(self, tmp_path):
        step = self._step(tmp_path)
        task = self._base_task(tmp_path)
        # No VERIFY_SSL column on the row at all.
        cfg = step._load_and_validate_config(task, [])
        # Key not set — _build_session falls back to its True default.
        assert "verify_ssl" not in cfg


class TestPollingQueryShipsKnobs:
    """SQL polling query MUST select PAGE_SIZE + VERIFY_SSL so ops
    can tune chunk size + TLS verification without touching Python.
    """

    def test_polling_query_has_page_size_and_verify_ssl(self):
        import yaml
        from pathlib import Path
        cfg = yaml.safe_load(
            (Path(__file__).parent.parent / "configs" /
             "etl_polling_task_query.yaml").read_text(),
        )
        sql = cfg["polling_query_sap"]
        assert "PAGE_SIZE" in sql, (
            "polling_query_sap missing PAGE_SIZE — Python default would "
            "be the only source of truth"
        )
        assert "VERIFY_SSL" in sql, (
            "polling_query_sap missing VERIFY_SSL — TLS verify must come "
            "from the row, not a hardcoded Python config"
        )


# ── SapCheckCompleteness — only the total-vs-full reconcile ────────


class TestCheckCompletenessTotalVsFull:
    """SapCheckCompleteness owns ONE check: consolidated row count
    against the pre-flight full $count.  Per-group reconcile is
    handled with retry inside SapOdataDownload — by the time we get
    here, per-group is already provably correct."""

    def _step(self):
        from steps.sap_check_completeness import SapCheckCompleteness
        return SapCheckCompleteness(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def _run(self, step, task):
        import asyncio
        return asyncio.get_event_loop().run_until_complete(
            step._execute_step(task, "", "", "SapCheckCompleteness"),
        ) if False else _run_async(step, task)

    def test_total_matches_full_passes(self, tmp_path):
        out = tmp_path / "MEBAL.csv.gz"
        out.write_bytes(b"x" * 100)
        step = self._step()
        task = {
            "totalcount": 9_000_000,
            "full_count": 9_000_000,
            "compressed_file": str(out),
        }
        result = _run_async(step, task)
        assert result == 9_000_000

    def test_total_less_than_full_raises(self, tmp_path):
        out = tmp_path / "MEBAL.csv.gz"
        out.write_bytes(b"x" * 100)
        step = self._step()
        task = {
            "totalcount": 8_999_990,
            "full_count": 9_000_000,
            "compressed_file": str(out),
        }
        with pytest.raises(ValueError, match="consolidated rows"):
            _run_async(step, task)

    def test_total_greater_than_full_raises(self, tmp_path):
        out = tmp_path / "MEBAL.csv.gz"
        out.write_bytes(b"x" * 100)
        step = self._step()
        task = {
            "totalcount": 9_000_010,
            "full_count": 9_000_000,
            "compressed_file": str(out),
        }
        with pytest.raises(ValueError, match="consolidated rows"):
            _run_async(step, task)

    def test_full_count_missing_skips_reconcile_with_warn(self, tmp_path):
        out = tmp_path / "MEBAL.csv.gz"
        out.write_bytes(b"x" * 100)
        step = self._step()
        task = {
            "totalcount": 100,
            # NO full_count
            "compressed_file": str(out),
        }
        # Doesn't raise; the WARN log records the skip.
        result = _run_async(step, task)
        assert result == 100

    def test_bypass_flag_in_json_lets_mismatch_pass(self, tmp_path):
        """JSON config carries ``allow_count_mismatch: true`` -- the
        restored JSON-loading path picks it up and bypasses the
        total-vs-full reconcile error."""
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text('{"allow_count_mismatch": true}')
        out = tmp_path / "MEBAL.csv.gz"
        out.write_bytes(b"x" * 100)
        step = self._step()
        task = {
            "totalcount": 8_999_990,
            "full_count": 9_000_000,
            "compressed_file": str(out),
            "sql_query_path": str(cfg_path),
        }
        # WITH JSON bypass -> no raise, returns totalcount
        result = _run_async(step, task)
        assert result == 8_999_990

    def test_no_bypass_still_raises(self, tmp_path):
        """Without bypass flag, mismatch raises."""
        out = tmp_path / "MEBAL.csv.gz"
        out.write_bytes(b"x" * 100)
        step = self._step()
        task = {
            "totalcount": 8_999_990,
            "full_count": 9_000_000,
            "compressed_file": str(out),
        }
        with pytest.raises(ValueError, match="consolidated rows"):
            _run_async(step, task)

    def test_missing_output_file_raises(self, tmp_path):
        step = self._step()
        task = {
            "totalcount": 100,
            "full_count": 100,
            # No compressed_file / consolidated_file
        }
        with pytest.raises(ValueError, match="no compressed_file"):
            _run_async(step, task)

    def test_empty_output_file_raises(self, tmp_path):
        out = tmp_path / "MEBAL.csv.gz"
        out.write_bytes(b"")  # 0 bytes
        step = self._step()
        task = {
            "totalcount": 100,
            "full_count": 100,
            "compressed_file": str(out),
        }
        with pytest.raises(ValueError, match="is empty"):
            _run_async(step, task)


def _run_async(step, task):
    """Helper: run the step's async _execute_step synchronously."""
    import asyncio
    return asyncio.run(
        step._execute_step(task, "", "", "SapCheckCompleteness"),
    )


# ── Grouping policy (codes_per_group) ──────────────────────────────


class TestCodesPerGroupPolicy:
    """Post-2026-06-07 grouping: codes_per_group drives bucket count
    via ``ceil(total_codes / codes_per_group)``.  Contiguous split
    preserves sort order so range ``$filter`` ranges don't overlap."""

    def test_codes_per_group_100_with_950_codes_yields_10_groups(self, tmp_path):
        from managers.company_code_grouper import CompanyCodeGrouper
        codes = [f"{i:04d}" for i in range(950)]
        g = CompanyCodeGrouper(
            history_path=str(tmp_path / "h.json"),
            codes_per_group=100,
        )
        groups = g.group_codes(codes)
        # ceil(950/100) = 10 groups
        assert len(groups) == 10
        # First group has 100 codes, last has 50 (95 codes/group ceiling)
        # Actually with ceil(950/10)=95 chunk size: 950/10=95, so each
        # group ~ 95.
        assert sum(len(grp) for grp in groups) == 950
        # Contiguous: every group's max < next group's min
        for i in range(len(groups) - 1):
            assert max(groups[i]) < min(groups[i + 1]), (
                "groups must not overlap (would break range $filter)"
            )

    def test_codes_per_group_50_with_200_codes(self, tmp_path):
        from managers.company_code_grouper import CompanyCodeGrouper
        codes = [f"{i:04d}" for i in range(200)]
        g = CompanyCodeGrouper(
            history_path=str(tmp_path / "h.json"),
            codes_per_group=50,
        )
        groups = g.group_codes(codes)
        assert len(groups) == 4  # ceil(200/50) = 4
        for grp in groups:
            assert len(grp) <= 50

    def test_legacy_num_groups_still_works_when_codes_per_group_none(self, tmp_path):
        from managers.company_code_grouper import CompanyCodeGrouper
        codes = [f"{i:04d}" for i in range(100)]
        # Explicit None for codes_per_group → fall back to num_groups
        g = CompanyCodeGrouper(
            history_path=str(tmp_path / "h.json"),
            num_groups=5,
            codes_per_group=0,  # 0 = "use num_groups"
        )
        groups = g.group_codes(codes)
        assert len(groups) == 5

    def test_single_code_list_isolates_specific_codes(self, tmp_path):
        """Operator-supplied SINGLE_CODE_LIST forces specific codes
        into their OWN single-code group.  Matches C# 'Eq: 8115' pattern."""
        from managers.company_code_grouper import CompanyCodeGrouper
        codes = [f'{i:04d}' for i in range(1000, 1100)]  # 100 codes
        codes.append('8115')                              # the heavy one
        g = CompanyCodeGrouper(
            history_path=str(tmp_path / 'h.json'),
            codes_per_group=200,                          # would fit all in 1 group
            single_code_list=['8115'],
        )
        groups = g.group_codes(codes)
        # 8115 is in its OWN group
        single_groups = [grp for grp in groups if len(grp) == 1]
        assert ['8115'] in single_groups
        # Other codes packed into a separate group (or groups)
        non_single = [c for grp in groups for c in grp if grp != ['8115']]
        assert '8115' not in non_single
        assert len(non_single) == 100

    def test_rows_per_group_target_splits_by_weight(self, tmp_path):
        """When history has weights, walks sorted codes and starts a
        new group when accumulated weight reaches target."""
        from managers.company_code_grouper import CompanyCodeGrouper
        # Pre-seed history: 5 codes with weights summing to 1000
        hp = tmp_path / 'h.json'
        import json
        hp.write_text(json.dumps({
            "runs": [],
            "code_weights": {
                "1001": 200, "1002": 250, "1003": 200,
                "1004": 250, "1005": 100,
            },
        }))
        g = CompanyCodeGrouper(
            history_path=str(hp),
            rows_per_group_target=500,  # close group at 500 rows
        )
        groups = g.group_codes(["1001", "1002", "1003", "1004", "1005"])
        # First group: 1001 (200) + 1002 (250) = 450 (next would push past 500)
        # Second group: 1003 (200) + 1004 (250) = 450
        # Third group: 1005 (100)
        # Actually depends on walk order; just verify contiguity + sum
        for grp in groups:
            assert grp == sorted(grp)  # contiguous
        # Total codes preserved
        all_codes = [c for grp in groups for c in grp]
        assert sorted(all_codes) == ["1001", "1002", "1003", "1004", "1005"]

    def test_all_zero_weights_falls_back_to_codes_per_group(self, tmp_path):
        """Regression: a non-empty history dict where EVERY weight is
        0.0 used to dump the whole roster into one group (legacy
        ``_bin_pack`` min-index tie always picks 0).  Now treated
        equivalent to "no history" -> contiguous split by
        codes_per_group."""
        from managers.company_code_grouper import CompanyCodeGrouper
        import json
        hp = tmp_path / "h.json"
        codes = [f"{i:04d}" for i in range(2659)]
        hp.write_text(json.dumps({
            "runs": [],
            "code_weights": {c: 0.0 for c in codes},   # corrupt all-zero
            "learned_heavies": [],
        }))
        g = CompanyCodeGrouper(
            history_path=str(hp),
            codes_per_group=100,
            rows_per_group_target=500000,
        )
        groups = g.group_codes(codes)
        assert len(groups) >= 27, (
            f"all-zero history must fall back to codes_per_group split, "
            f"not pile into one group; got {len(groups)} groups"
        )
        assert max(len(g) for g in groups) <= 100

    def test_codes_per_group_cap_overrides_target_with_flat_weights(self, tmp_path):
        """Bug surfaced 2026-06-07: 2659 codes collapsed to 7 groups
        because EMA-averaged weights were all similar (~1500/code)
        and walk-pack closed groups at 500K rows -> ~333 codes/group.
        Fix: walk-pack respects codes_per_group cap even when
        weight-target hasn't been reached.
        """
        from managers.company_code_grouper import CompanyCodeGrouper
        import json

        hp = tmp_path / "h.json"
        # Simulate prior runs: every code averaged to ~1500 weight
        codes = [f"{i:04d}" for i in range(2659)]
        weights = {c: 1500.0 for c in codes}
        hp.write_text(json.dumps({
            "runs": [],
            "code_weights": weights,
            "learned_heavies": [],
        }))
        g = CompanyCodeGrouper(
            history_path=str(hp),
            codes_per_group=100,             # operator cap
            rows_per_group_target=500000,    # weight target
        )
        groups = g.group_codes(codes)
        # Pre-fix: ~7 groups (500K / 1500 = 333 codes/group).
        # Post-fix: codes_per_group=100 caps -> ceil(2659/100) = 27 groups.
        assert len(groups) >= 27, (
            f"codes_per_group cap MUST limit group size; got "
            f"{len(groups)} groups with max size {max(len(x) for x in groups)}"
        )
        # No group should exceed the cap
        for grp in groups:
            assert len(grp) <= 100, (
                f"group exceeds codes_per_group=100: {len(grp)} codes"
            )

    def test_heavy_code_isolated_by_weight_alone(self, tmp_path):
        """A code whose individual weight exceeds target gets its own
        group automatically, no operator config needed."""
        from managers.company_code_grouper import CompanyCodeGrouper
        hp = tmp_path / 'h.json'
        import json
        hp.write_text(json.dumps({
            "runs": [],
            "code_weights": {
                "1001": 100, "1002": 100, "8115": 974441,  # heavy
                "8116": 100, "8117": 100,
            },
        }))
        g = CompanyCodeGrouper(
            history_path=str(hp),
            rows_per_group_target=500000,  # 8115 (974K) > 500K
        )
        groups = g.group_codes(["1001", "1002", "8115", "8116", "8117"])
        # 8115 isolated
        assert ['8115'] in groups
        # Light codes packed together (preserving contiguity)
        for grp in groups:
            if grp != ['8115']:
                for c in grp:
                    assert c != '8115'

    def test_learning_cycle_persists_operator_heavies(self, tmp_path):
        """Run 1 operator sets SINGLE_CODE_LIST -> heavies isolated.
        Run 2 the operator omits SINGLE_CODE_LIST entirely -- those
        codes are STILL isolated because run 1 persisted them into
        history.learned_heavies."""
        from managers.company_code_grouper import CompanyCodeGrouper

        hp = tmp_path / "h.json"
        codes = ["1001", "1002", "1003", "8115", "1004"]

        # -- RUN 1: operator hand-feeds the heavy --
        g1 = CompanyCodeGrouper(
            history_path=str(hp),
            codes_per_group=10,
            single_code_list=["8115"],
        )
        groups1 = g1.group_codes(codes)
        assert ["8115"] in groups1, "operator-forced heavy isolated"

        # Simulate the download recording results
        g1.record_results([
            {"codes": grp, "row_count": 100 if "8115" not in grp else 974000}
            for grp in groups1
        ])

        # -- RUN 2: no SINGLE_CODE_LIST -- history must still isolate --
        g2 = CompanyCodeGrouper(
            history_path=str(hp),
            codes_per_group=10,
            single_code_list=None,   # OPERATOR FORGOT TO SET IT
        )
        groups2 = g2.group_codes(codes)
        assert ["8115"] in groups2, (
            "history.learned_heavies must keep isolating 8115 even "
            "without operator re-passing SINGLE_CODE_LIST"
        )

    def test_auto_detect_heavy_from_oversized_single_group(self, tmp_path):
        """If a SINGLE-code group's actual rows > 1.5x target, the
        code is auto-learned as heavy without operator action."""
        from managers.company_code_grouper import CompanyCodeGrouper

        hp = tmp_path / "h.json"
        g = CompanyCodeGrouper(
            history_path=str(hp),
            rows_per_group_target=500000,
        )
        # Simulate: a run where ONE group happened to have a single
        # code that ran very heavy (>1.5x target).
        g.record_results([
            {"codes": ["1001"], "row_count": 800000},   # > 1.5*500K
            {"codes": ["1002", "1003"], "row_count": 200000},
        ])

        learned = g.history.get("learned_heavies", [])
        assert "1001" in learned, "auto-detected heavy must be learned"
        assert "1002" not in learned, "light codes must NOT be flagged"

    def test_learned_heavy_drops_when_no_longer_in_roster(self, tmp_path):
        """A code learned-heavy in a past run that's no longer in
        SAP_COMPANY_API roster mustn't pull the grouper into an
        empty single-code group."""
        from managers.company_code_grouper import CompanyCodeGrouper
        import json

        hp = tmp_path / "h.json"
        hp.write_text(json.dumps({
            "runs": [],
            "code_weights": {"REMOVED": 1000000.0, "1001": 100.0},
            "learned_heavies": ["REMOVED"],
        }))
        g = CompanyCodeGrouper(
            history_path=str(hp),
            rows_per_group_target=500000,
            codes_per_group=10,
        )
        # Today's roster does NOT include REMOVED
        groups = g.group_codes(["1001", "1002"])
        # REMOVED must not appear anywhere
        for grp in groups:
            assert "REMOVED" not in grp

    def test_single_code_list_overlay_from_polling_row(self, tmp_path):
        """``SINGLE_CODE_LIST='8115,1319,3630'`` on polling row ->
        config['single_code_list'] as a comma string; downstream
        splits to list."""
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "SAPU": "u", "SAPP": "p",
            "SAP_COMPANY_API": "x", "SAP_ME_BALANCE_API": "y",
            "OUTPUT_DIR": str(tmp_path),
            "SINGLE_CODE_LIST": "8115,1319,3630",
            "ROWS_PER_GROUP_TARGET": 500000,
        }
        cfg = step._load_and_validate_config(task, [])
        assert cfg["single_code_list"] == "8115,1319,3630"
        assert cfg["rows_per_group_target"] == 500000

    def test_contiguous_split_preserves_sort_order(self, tmp_path):
        from managers.company_code_grouper import CompanyCodeGrouper
        codes = ["1000", "1010", "8116", "8117", "8128"]
        g = CompanyCodeGrouper(
            history_path=str(tmp_path / "h.json"),
            codes_per_group=2,
        )
        groups = g.group_codes(codes)
        # First chunk = first 3 (ceil(5/3)=2 chunk size... but
        # ceil(5/2) = 3 groups, chunk=ceil(5/3)=2, so groups of 2/2/1)
        assert len(groups) == 3
        assert groups[0] == ["1000", "1010"]
        assert groups[1] == ["8116", "8117"]
        assert groups[2] == ["8128"]


class TestPlanningArtefacts:
    """Codes + groups CSVs MUST land on disk before any per-group
    HTTPS so debug-from-failure works."""

    def _step(self):
        from steps.sap_odata_download import SapOdataDownload
        return SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def test_dump_codes_csv_writes_sorted_unique_list(self, tmp_path):
        step = self._step()
        codes = ["8128", "8116", "8128", "1000"]  # unsorted + dup
        path = step._dump_codes_csv(str(tmp_path), sorted(set(codes)))
        assert os.path.exists(path)
        with open(path) as f:
            lines = f.read().strip().split("\n")
        assert lines[0] == "Companycode"
        assert lines[1:] == ["1000", "8116", "8128"]

    def test_dump_groups_csv_one_row_per_code(self, tmp_path):
        step = self._step()
        groups = [["1000", "1010"], ["8116", "8117"], ["8128"]]
        path = step._dump_groups_csv(str(tmp_path), groups)
        assert os.path.exists(path)
        with open(path) as f:
            lines = f.read().strip().split("\n")
        # Header + 5 code rows
        assert len(lines) == 6
        assert lines[0].startswith("group_idx,code_position,Companycode")
        # Each row has the group_min/max columns populated
        row1 = lines[1].split(",")
        assert row1[3] == "1000"  # group_min
        assert row1[4] == "1010"  # group_max


class TestHttpPoolScaling:
    """HTTPAdapter pool size scales with max_parallel_groups."""

    def test_pool_size_default(self):
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        sess = step._build_session({"sap_username": "u", "sap_password": "p"})
        # Default max_parallel=3 → pool 20 (max of 20 and 3*4=12)
        # Inspect via HTTPS adapter mounted
        adapter = sess.get_adapter("https://example.com")
        # urllib3.PoolManager's pool_kwargs are private; instead check
        # the adapter's _pool_connections / _pool_maxsize hold the values
        assert adapter._pool_connections == 20
        assert adapter._pool_maxsize == 20

    def test_pool_size_scales_with_max_parallel(self):
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        sess = step._build_session({
            "sap_username": "u", "sap_password": "p",
            "max_parallel_groups": 10,
        })
        adapter = sess.get_adapter("https://example.com")
        # 10 * 4 = 40
        assert adapter._pool_connections == 40
        assert adapter._pool_maxsize == 40


# -- Intra-group parallel fetcher (matches C# pattern) -------------


class TestIntraGroupParallelFetch:
    """Mirror of the C# benchmark: 5 groups x 2 intra-group threads =
    10 in-flight HTTP requests, completes 9 M rows in ~9 min."""

    def _step(self):
        from steps.sap_odata_base import SapOdataBase

        class _Probe(SapOdataBase):
            async def _execute_step(self, *args, **kwargs):
                return 0

        return _Probe(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def test_parallel_fetcher_fans_out_n_pages(self):
        """expected_count / top = n pages; fetcher issues exactly n GETs."""
        step = self._step()
        sess = MagicMock()
        responses = []
        for _ in range(5):
            r = MagicMock(); r.raise_for_status.return_value = None
            r.json.return_value = {"d": {"results": [{"k": 1}, {"k": 2}]}}
            responses.append(r)
        sess.get.side_effect = responses
        # 5 pages of 2 rows = 10 expected
        pages = list(step._stream_odata_pages_parallel(
            sess, "https://x", {},
            {"page_size": 2, "rate_limit_rps": 1000},
            expected_count=10, parallel=3,
        ))
        # 5 pages yielded (order may vary)
        assert len(pages) == 5
        assert sess.get.call_count == 5
        # All page indices 0..4 present
        assert sorted(p[0] for p in pages) == [0, 1, 2, 3, 4]

    def test_parallel_fetcher_uses_count_for_termination(self):
        """No ``__next`` chase -- termination is purely by expected_count
        / top.  This is why upstream MUST fetch $count first."""
        step = self._step()
        sess = MagicMock()
        # expected=4, top=2 -> 2 pages.  Provide 2 responses; if it
        # tried a 3rd request we'd get StopIteration.
        r1 = MagicMock(); r1.raise_for_status.return_value = None
        r1.json.return_value = {"d": {"results": [{"k": 1}, {"k": 2}]}}
        r2 = MagicMock(); r2.raise_for_status.return_value = None
        r2.json.return_value = {"d": {"results": [{"k": 3}, {"k": 4}]}}
        sess.get.side_effect = [r1, r2]
        pages = list(step._stream_odata_pages_parallel(
            sess, "https://x", {},
            {"page_size": 2, "rate_limit_rps": 1000},
            expected_count=4, parallel=2,
        ))
        assert len(pages) == 2
        assert sess.get.call_count == 2

    def test_http_adapter_retries_on_read_timeout(self):
        """ReadTimeout at HTTP layer must be retried (not bubble up
        to the group-level handler and force a full group restart)."""
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        sess = step._build_session({
            "sap_username": "u", "sap_password": "p",
            "max_retries": 3,
        })
        adapter = sess.get_adapter("https://example.com")
        retry = adapter.max_retries
        # Must retry on READ errors (ReadTimeoutError), not just status
        assert retry.read == 3, (
            f"Retry strategy must retry on ReadTimeout; got read={retry.read}"
        )
        assert retry.connect == 3
        assert retry.total == 3

    def test_default_timeout_is_600_for_slow_sap(self):
        """120s was too short for SAP rendering 50K-row JSON.
        Confirm 600s default; operators can lower via row column."""
        from steps.sap_odata_base import SapOdataBase
        assert SapOdataBase.DEFAULT_TIMEOUT_SECONDS == 600

    def test_polling_query_carries_page_timeout(self):
        import yaml
        from pathlib import Path
        cfg = yaml.safe_load(
            (Path(__file__).parent.parent / "configs" /
             "etl_polling_task_query.yaml").read_text(encoding="utf-8"),
        )
        assert "PAGE_TIMEOUT_SECONDS" in cfg["polling_query_sap"]

    def test_bounded_inflight_never_exceeds_parallel(self):
        """Bounded fetcher: at no point should MORE than ``parallel``
        futures be alive at once.  We verify by counting concurrent
        active calls inside fetch_one."""
        import threading
        step = self._step()
        sess = MagicMock()

        active = {"current": 0, "peak": 0}
        lock = threading.Lock()

        def make_resp(idx):
            r = MagicMock()
            r.raise_for_status.return_value = None
            r.json.return_value = {
                "d": {"results": [{"k": idx, "v": "x"}]},
            }
            return r

        # Spy on session.get to track concurrency
        import time
        def slow_get(*args, **kwargs):
            with lock:
                active["current"] += 1
                active["peak"] = max(active["peak"], active["current"])
            # Tiny sleep to encourage actual concurrency
            time.sleep(0.01)
            with lock:
                active["current"] -= 1
            # Return one row per call
            idx = active["peak"]
            return make_resp(idx)

        sess.get = MagicMock(side_effect=slow_get)

        # 8 pages, parallel=2 -- peak in-flight should be exactly 2
        # (or 1 -- never more)
        pages = list(step._stream_odata_pages_parallel(
            sess, "https://x", {},
            {"page_size": 1, "rate_limit_rps": 1000},
            expected_count=8, parallel=2,
        ))
        assert len(pages) == 8
        assert active["peak"] <= 2, (
            f"bounded fetcher must cap in-flight at parallel=2, "
            f"saw peak={active['peak']}"
        )

    def test_pool_size_scales_with_intra_group_parallel(self):
        """C# pattern: 5 groups x 2 threads = 10 in-flight; pool must
        hold 2 * (5*2 + 5) = 30 connections."""
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        sess = step._build_session({
            "sap_username": "u", "sap_password": "p",
            "max_parallel_groups": 5,
            "intra_group_parallel": 2,
        })
        adapter = sess.get_adapter("https://example.com")
        # 2 * (5*2 + 5) = 30
        assert adapter._pool_connections == 30
        assert adapter._pool_maxsize == 30


class TestParallelismPollingRowOverlay:
    """SQL polling query supplies MAX_PARALLEL_GROUPS +
    INTRA_GROUP_PARALLEL constants matching the C# pattern."""

    def test_polling_query_has_parallelism_knobs(self):
        import yaml
        from pathlib import Path
        cfg = yaml.safe_load(
            (Path(__file__).parent.parent / "configs" /
             "etl_polling_task_query.yaml").read_text(),
        )
        sql = cfg["polling_query_sap"]
        assert "MAX_PARALLEL_GROUPS" in sql
        assert "INTRA_GROUP_PARALLEL" in sql

    def test_max_parallel_groups_overlay(self, tmp_path):
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "SAPU": "u", "SAPP": "p",
            "SAP_COMPANY_API": "x", "SAP_ME_BALANCE_API": "y",
            "OUTPUT_DIR": str(tmp_path),
            "MAX_PARALLEL_GROUPS": 5,
            "INTRA_GROUP_PARALLEL": 2,
        }
        cfg = step._load_and_validate_config(task, [])
        assert cfg["max_parallel_groups"] == 5
        assert cfg["intra_group_parallel"] == 2


# -- Analytics Parquet emit ----------------------------------------


class TestAnalyticsParquetEmit:
    """SapEmitAnalyticsParquet runs after CheckCompleteness and
    produces ONE Parquet for QueryStudio.  Gated by GENERATE_PARQUET
    flag.  CSV.gz delivery is unaffected."""

    def _step(self):
        from steps.sap_emit_analytics_parquet import SapEmitAnalyticsParquet
        return SapEmitAnalyticsParquet(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def test_always_runs_when_polling_row_present(self, tmp_path):
        """Per DB-as-workflow principle (2026-06-07): if the polling
        row exists, the step MUST produce output -- no flag-based
        skipping.  If you don't want Parquet, REMOVE the polling row
        entirely."""
        import gzip, csv as _csv
        # Pre-build a tiny CSV.gz so the step has something to convert
        csv_gz = tmp_path / "MEBAL_2026_005.csv.gz"
        with gzip.open(csv_gz, "wt", encoding="utf-8", newline="") as f:
            w = _csv.writer(f, delimiter="|")
            w.writerow(["Companycode", "Amount"])
            w.writerow(["1001", "100"])
        step = self._step()
        task = {
            "totalcount": 1, "full_count": 1,
            "compressed_file": str(csv_gz),
            "output_dir": str(tmp_path),
            "p_gjahr": "2026", "p_poper": "005",
            "consolidated_csv_delimiter": "|",
        }
        # Step ALWAYS runs and emits parquet -- no flag check
        result = _run_async(step, task)
        assert result == 1
        assert list(tmp_path.glob("**/*.parquet"))

    def test_csv_to_parquet_roundtrip_row_count(self, tmp_path):
        """End-to-end: write a tiny CSV.gz, run the step, verify the
        Parquet has the same row count."""
        pytest.importorskip("pyarrow")
        pytest.importorskip("pyarrow.parquet")

        import gzip, csv as _csv
        # 1. Build a tiny CSV.gz that mimics consolidate's output.
        csv_gz = tmp_path / "MEBAL_2026_005.csv.gz"
        with gzip.open(csv_gz, "wt", encoding="utf-8", newline="") as f:
            w = _csv.writer(f, delimiter="|")
            w.writerow(["Companycode", "Amount", "Period"])
            for i in range(150):
                w.writerow([f"81{i:02d}", str(i * 100), "005"])

        step = self._step()
        task = {
            "totalcount": 150, "full_count": 150,
            "compressed_file": str(csv_gz),
            "output_dir": str(tmp_path),
            "p_gjahr": "2026", "p_poper": "005",
            "analytics_enabled": True,
            "consolidated_csv_delimiter": "|",
        }
        result = _run_async(step, task)
        assert result == 150
        # Parquet landed in <output_dir>/analytics/
        parquet = tmp_path / "analytics" / "MEBAL_2026_005.parquet"
        assert parquet.exists()
        # Verify row count via pyarrow
        import pyarrow.parquet as pq
        table = pq.read_table(str(parquet))
        assert table.num_rows == 150
        assert "Companycode" in table.column_names

    def test_row_count_mismatch_deletes_parquet_and_raises(self, tmp_path):
        """If the converted Parquet doesn't match totalcount we
        DELETE the bad Parquet and raise -- never let bad data into
        analytics."""
        pytest.importorskip("pyarrow")

        import gzip, csv as _csv
        csv_gz = tmp_path / "MEBAL_2026_005.csv.gz"
        with gzip.open(csv_gz, "wt", encoding="utf-8", newline="") as f:
            w = _csv.writer(f, delimiter="|")
            w.writerow(["Companycode"])
            for i in range(10):
                w.writerow([f"81{i:02d}"])

        step = self._step()
        # Lie about totalcount (CSV has 10, claim 999)
        task = {
            "totalcount": 999, "full_count": 999,
            "compressed_file": str(csv_gz),
            "output_dir": str(tmp_path),
            "p_gjahr": "2026", "p_poper": "005",
            "analytics_enabled": True,
            "consolidated_csv_delimiter": "|",
        }
        with pytest.raises(ValueError, match="Conversion is dropping"):
            _run_async(step, task)
        # The bad Parquet was cleaned up
        assert not list(tmp_path.glob("**/*.parquet"))

    def test_step_registered_in_step_mapping(self):
        import yaml
        from pathlib import Path
        cfg = yaml.safe_load(
            (Path(__file__).parent.parent / "configs" /
             "step_mapping.yaml").read_text(encoding="utf-8"),
        )
        assert "SapEmitAnalyticsParquet" in cfg.get("sap_odata", {}), (
            "step_mapping.yaml > sap_odata must register "
            "SapEmitAnalyticsParquet"
        )
        entry = cfg["sap_odata"]["SapEmitAnalyticsParquet"]
        assert entry["module"] == "steps.sap_emit_analytics_parquet"
        assert entry["class"] == "SapEmitAnalyticsParquet"

    def test_polling_query_has_generate_parquet_flag(self):
        import yaml
        from pathlib import Path
        cfg = yaml.safe_load(
            (Path(__file__).parent.parent / "configs" /
             "etl_polling_task_query.yaml").read_text(encoding="utf-8"),
        )
        sql = cfg["polling_query_sap"]
        assert "GENERATE_PARQUET" in sql, (
            "polling_query_sap must select GENERATE_PARQUET so the "
            "analytics step can be toggled per task"
        )


# -- Restart / resume semantics ------------------------------------


class TestRestartResume:
    """On restart we MUST reuse the previous run_subdir so per-group
    checkpoint can skip completed groups.  Bare-base task['output_dir']
    must NOT be honoured as run_subdir (the bug surfaced 2026-06-07)."""

    def _step(self):
        from steps.sap_odata_download import SapOdataDownload
        return SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def test_sidecar_run_subdir_wins_on_restart(self, tmp_path):
        from steps.sap_odata_state import save_state
        # Pretend a prior run wrote its subdir to the sidecar
        prior_subdir = tmp_path / "2026_005_20260607_120000"
        prior_subdir.mkdir()
        save_state(
            {"run_subdir": str(prior_subdir)}, str(tmp_path), run_id=42,
        )
        step = self._step()
        task = {
            "run_id": 42,
            "output_dir": str(tmp_path),   # base, NOT subdir
        }
        config = {"output_dir": str(tmp_path)}
        result = step._resolve_output_dir(task, config, "2026", "005")
        assert result == str(prior_subdir), (
            "restart must honour sidecar run_subdir not create a new one"
        )

    def test_bare_base_does_not_become_run_subdir(self, tmp_path):
        """Pre-fix bug: polling-row OUTPUT_DIR = base; _resolve_output_dir
        used task['output_dir'] blindly -> returned base -> files
        scattered into base.  Now we require it to be a SUBDIR of base."""
        step = self._step()
        task = {
            "run_id": 99,    # no sidecar for this run_id
            "output_dir": str(tmp_path),  # bare base
        }
        config = {"output_dir": str(tmp_path)}
        result = step._resolve_output_dir(task, config, "2026", "005")
        # Must be a NEW subdir under tmp_path, not tmp_path itself
        assert result != str(tmp_path)
        assert os.path.dirname(result) == str(tmp_path)
        assert "2026_005_" in os.path.basename(result)

    def test_explicit_subdir_in_task_is_honoured(self, tmp_path):
        """Operator-passed subdir (e.g. pointing at a known prior run)
        is respected as long as it's UNDER the base."""
        step = self._step()
        subdir = tmp_path / "manual_resume_subdir"
        subdir.mkdir()
        task = {
            "run_id": 100,
            "output_dir": str(subdir),
        }
        config = {"output_dir": str(tmp_path)}
        result = step._resolve_output_dir(task, config, "2026", "005")
        assert result == str(subdir)

    def test_existing_arg_short_circuits(self, tmp_path):
        step = self._step()
        existing = tmp_path / "re_stamp_call"
        existing.mkdir()
        result = step._resolve_output_dir(
            {}, {"output_dir": str(tmp_path)}, "2026", "005",
            existing=str(existing),
        )
        assert result == str(existing)


# -- Cross-step sidecar state handoff -----------------------------


class TestSidecarStateHandoff:
    """Bug surfaced 2026-06-07: each polling row -> own task dict, so
    Download's task['downloaded_files'] is invisible to Consolidate.
    Fix is a sidecar JSON keyed by run_id that every SAP step
    reads/writes."""

    def test_save_then_load_round_trips(self, tmp_path):
        from steps.sap_odata_state import save_state, load_state
        state = {
            "downloaded_files": ["/x/g0.csv", "/x/g1.csv"],
            "totalcount": 1234,
            "full_count": 1234,
            "run_subdir": str(tmp_path / "subdir"),
        }
        path = save_state(state, str(tmp_path), run_id=42)
        assert path and os.path.exists(path)
        loaded = load_state(str(tmp_path), run_id=42)
        assert loaded == state

    def test_load_missing_returns_none(self, tmp_path):
        from steps.sap_odata_state import load_state
        assert load_state(str(tmp_path), run_id=99999) is None

    def test_load_returns_none_for_corrupt(self, tmp_path):
        from steps.sap_odata_state import state_path, load_state
        path = state_path(str(tmp_path), 42)
        with open(path, 'w') as f:
            f.write("not-valid-json{")
        assert load_state(str(tmp_path), run_id=42) is None

    def test_save_with_no_run_id_is_noop(self, tmp_path):
        from steps.sap_odata_state import save_state
        assert save_state({"x": 1}, str(tmp_path), run_id=None) is None

    def test_hydrate_overrides_polling_default_totalcount(self, tmp_path):
        """Regression 2026-06-07: pre-fix the hydrate guard
        ``task.get(k) in (None, '', [])`` treated polling-row default
        ``totalcount=0`` as 'already set' and refused to overwrite,
        causing Consolidate to compare against 0 instead of the real
        download row count.  Symptom: 'merged 9006150 but download
        recorded 0 rows -- consolidation lost / duplicated rows.'
        """
        from steps.sap_consolidate_files import SapConsolidateFiles
        from steps.sap_odata_state import save_state

        run_subdir = tmp_path / "run"
        run_subdir.mkdir()
        save_state({
            "run_subdir":       str(run_subdir),
            "downloaded_files": [str(run_subdir / "g0.csv")],
            "totalcount":       9_006_150,  # the REAL value
            "full_count":       9_006_150,
            "p_gjahr":          "2026", "p_poper": "005",
            "output_format":    "csv", "output_formats": ["csv"],
        }, str(tmp_path), run_id=42)

        step = SapConsolidateFiles(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        # Consolidate's task dict carries the POLLING-ROW default
        # placeholder ``totalcount=0`` -- the bug was hydrate refusing
        # to overwrite it.
        task = {
            "run_id": 42,
            "totalcount": 0,          # <- polling-row "0 AS totalcount"
        }
        config = {"output_dir": str(tmp_path)}
        hydrated = step._hydrate_from_sidecar(task, config)
        assert hydrated is True
        # Sidecar's real value MUST overwrite the placeholder.
        assert task["totalcount"] == 9_006_150, (
            f"hydrate must overwrite polling-row placeholder 0 with "
            f"sidecar's real totalcount; got {task['totalcount']}"
        )

    def test_hydrate_lifts_state_into_empty_task(self, tmp_path):
        """The downstream-step path: task dict is empty, sidecar exists,
        hydrate populates the task with downloaded_files etc."""
        from steps.sap_consolidate_files import SapConsolidateFiles
        from steps.sap_odata_state import save_state

        # Pre-seed the sidecar (as if download had written it)
        run_subdir = tmp_path / "2026_005_run"
        run_subdir.mkdir()
        save_state({
            "run_subdir":       str(run_subdir),
            "downloaded_files": [str(run_subdir / "g0.csv")],
            "p_gjahr":          "2026",
            "p_poper":          "005",
            "output_format":    "csv",
            "output_formats":   ["csv"],
            "full_count":       100,
            "totalcount":       100,
        }, str(tmp_path), run_id=42)

        step = SapConsolidateFiles(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        # Consolidate's task dict has run_id + output_dir (base) -- but
        # NO downloaded_files (different polling row from download).
        task = {
            "run_id": 42,
            "RUN_ID": 42,
        }
        config = {"output_dir": str(tmp_path)}
        hydrated = step._hydrate_from_sidecar(task, config)
        assert hydrated is True
        # downloaded_files lifted from sidecar
        assert task["downloaded_files"] == [str(run_subdir / "g0.csv")]
        # output_dir overridden to point at the run subdir
        assert task["output_dir"] == str(run_subdir)
        assert task["full_count"] == 100

    def test_hydrate_no_op_when_task_already_has_state(self, tmp_path):
        """Single-pod / single-task path: don't clobber the in-process
        state with the on-disk one."""
        from steps.sap_consolidate_files import SapConsolidateFiles

        step = SapConsolidateFiles(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "run_id": 42,
            "downloaded_files": ["/in-process/g0.csv"],
        }
        result = step._hydrate_from_sidecar(
            task, {"output_dir": str(tmp_path)},
        )
        assert result is False
        # Untouched
        assert task["downloaded_files"] == ["/in-process/g0.csv"]

    def test_hydrate_missing_sidecar_logs_warning(self, tmp_path):
        from steps.sap_consolidate_files import SapConsolidateFiles
        step = SapConsolidateFiles(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {"run_id": 999}
        result = step._hydrate_from_sidecar(
            task, {"output_dir": str(tmp_path)},
        )
        assert result is False
        # Warning logged so an operator sees why downstream will fail
        assert step.logger.warning.called


# -- Auto-discovery probe (Option B) -------------------------------


class TestAutoDiscoveryProbe:
    """Per-code $count probe fires for oversized groups to discover
    hidden heavy codes that EMA averaging hides."""

    def _step(self):
        from steps.sap_odata_download import SapOdataDownload
        return SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def _grouper(self, tmp_path, **kwargs):
        from managers.company_code_grouper import CompanyCodeGrouper
        return CompanyCodeGrouper(
            history_path=str(tmp_path / "h.json"),
            **kwargs,
        )

    def test_probe_skipped_when_no_oversized_groups(self, tmp_path):
        step = self._step()
        grouper = self._grouper(tmp_path, rows_per_group_target=500000)
        sess = MagicMock()
        # All groups within target -- no probe
        group_results = [
            {"codes": ["1001", "1002"], "row_count": 100_000},
            {"codes": ["1003", "1004"], "row_count": 200_000},
        ]
        n = step._probe_oversized_groups_per_code(
            sess, {"rows_per_group_target": 500000, "sap_me_balance_api": "x"},
            group_results, "2026", "005", grouper,
        )
        assert n == 0
        sess.get.assert_not_called()

    def test_probe_skipped_when_flag_off(self, tmp_path):
        step = self._step()
        grouper = self._grouper(tmp_path, rows_per_group_target=500000)
        sess = MagicMock()
        # Oversized group present BUT probe_enabled=False
        group_results = [{"codes": ["A", "B", "C"], "row_count": 2_000_000}]
        n = step._probe_oversized_groups_per_code(
            sess, {
                "rows_per_group_target": 500000,
                "probe_enabled": False,
                "sap_me_balance_api": "x",
            },
            group_results, "2026", "005", grouper,
        )
        assert n == 0
        sess.get.assert_not_called()

    def test_probe_fires_only_for_oversized_multi_code_groups(self, tmp_path):
        step = self._step()
        grouper = self._grouper(tmp_path, rows_per_group_target=500000)
        sess = MagicMock()
        # Mock $count to return 974441 for one code, 100 for others
        def _resp(text):
            r = MagicMock(); r.raise_for_status.return_value = None
            r.text = text
            return r
        # Probe order is non-deterministic (parallel), so map by URL.
        def get_side_effect(url, **kwargs):
            # URL contains 'HEAVY' for the heavy code
            if "HEAVY" in url:
                return _resp("974441")
            return _resp("100")
        sess.get.side_effect = get_side_effect

        group_results = [
            # Oversized multi-code -> PROBED
            {"codes": ["HEAVY", "1001", "1002"], "row_count": 1_000_000},
            # Within target -> NOT probed
            {"codes": ["2001", "2002"], "row_count": 200_000},
            # Single-code (already isolated) -> NOT probed even if oversized
            {"codes": ["3001"], "row_count": 800_000},
        ]
        n = step._probe_oversized_groups_per_code(
            sess, {
                "rows_per_group_target": 500000,
                "probe_parallel": 3,
                "rate_limit_rps": 1000,
                "sap_me_balance_api": (
                    "https://x/Bal(p_gjahr='{YEAR}',p_poper='{MONTH}')/"
                    "Data?$filter=( Companycode ge '{min}' and Companycode le '{max}')"
                ),
            },
            group_results, "2026", "005", grouper,
        )
        # Probed exactly 3 codes (the oversized multi-code group)
        assert n == 3
        assert sess.get.call_count == 3
        # History updated with TRUE counts
        assert grouper.history["code_weights"]["HEAVY"] == 974441.0
        assert grouper.history["code_weights"]["1001"] == 100.0
        # HEAVY auto-added to learned_heavies
        assert "HEAVY" in grouper.history["learned_heavies"]
        # Light codes NOT added
        assert "1001" not in grouper.history["learned_heavies"]

    def test_probe_handles_per_code_failure_gracefully(self, tmp_path):
        """One probe failing must not abort the rest."""
        step = self._step()
        grouper = self._grouper(tmp_path, rows_per_group_target=500000)
        sess = MagicMock()
        def _resp(text):
            r = MagicMock(); r.raise_for_status.return_value = None
            r.text = text
            return r
        call_count = {"n": 0}
        def get_side_effect(url, **kwargs):
            call_count["n"] += 1
            if call_count["n"] == 2:
                raise ConnectionError("simulated probe failure")
            return _resp("700000")
        sess.get.side_effect = get_side_effect
        group_results = [
            {"codes": ["A", "B", "C"], "row_count": 1_000_000},
        ]
        n = step._probe_oversized_groups_per_code(
            sess, {
                "rows_per_group_target": 500000,
                "probe_parallel": 3,
                "rate_limit_rps": 1000,
                "sap_me_balance_api":
                    "https://x/Data?$filter=( Companycode ge '{min}' and Companycode le '{max}')",
            },
            group_results, "2026", "005", grouper,
        )
        # 2 of 3 succeeded; 1 failed gracefully
        assert n == 2

    def test_ingest_accurate_weights_overrides_ema(self, tmp_path):
        """ingest_accurate_weights OVERWRITES existing EMA-averaged
        weights; doesn't blend.  Critical because a hidden heavy
        masked by EMA must surface immediately."""
        from managers.company_code_grouper import CompanyCodeGrouper
        import json
        hp = tmp_path / "h.json"
        hp.write_text(json.dumps({
            "runs": [],
            "code_weights": {"HEAVY": 10000.0},  # EMA-averaged estimate
            "learned_heavies": [],
        }))
        g = CompanyCodeGrouper(
            history_path=str(hp),
            rows_per_group_target=500000,
        )
        g.ingest_accurate_weights({"HEAVY": 974441, "LIGHT": 50})
        assert g.history["code_weights"]["HEAVY"] == 974441.0  # OVERWRITES
        assert g.history["code_weights"]["LIGHT"] == 50.0
        # HEAVY auto-added because 974441 > 500000 target
        assert "HEAVY" in g.history["learned_heavies"]
        assert "LIGHT" not in g.history["learned_heavies"]


# -- HTML run report ------------------------------------------------


class TestRunReport:
    def test_html_starts_status_block(self, tmp_path):
        from steps.sap_odata_report import RunReport
        r = RunReport(output_dir=str(tmp_path))
        r.set_context(period="2026/005", run_id=42)
        r.set_urls(SAP_COMPANY_API="https://x/cc?$format=json")
        r.set_runtime_knobs(page_size_effective=50000)
        r.set_counts(full_count=9_000_000, sum_expected=9_000_000,
                      sum_actual=9_000_000, consolidated_count=9_000_000)
        r.add_group_result({
            "group_idx": 0, "expected_count": 100, "row_count": 100,
            "codes": ["8116", "8117"], "attempts": 1,
            "file_path": str(tmp_path / "g0.csv"),
        })
        r.mark_success()
        paths = r.write()
        assert "html" in paths and "txt" in paths
        html_text = open(paths["html"], encoding="utf-8").read()
        assert "SUCCESS" in html_text
        assert "2026/005" in html_text
        assert "9,000,000" in html_text
        assert "SAP_COMPANY_API" in html_text
        assert "8116 .. 8117" in html_text

    def test_html_written_even_on_failure(self, tmp_path):
        from steps.sap_odata_report import RunReport
        r = RunReport(output_dir=str(tmp_path))
        r.set_context(period="2026/005")
        r.mark_failed("ConnectionError: pool full")
        paths = r.write()
        html_text = open(paths["html"], encoding="utf-8").read()
        assert "FAILED" in html_text
        assert "pool full" in html_text

    def test_send_email_skipped_when_flag_off(self):
        from steps.sap_odata_report import RunReport
        r = RunReport(output_dir="/tmp")
        r.mark_started()
        assert r.send_email({}) is False
        assert r.send_email({"send_email": False}) is False

    def test_html_has_prominent_timing_banner(self, tmp_path):
        """HTML must show start/end/duration as prominent cards in the
        header banner.  User wants it visible without scrolling."""
        from steps.sap_odata_report import RunReport
        from datetime import datetime, timezone, timedelta
        r = RunReport(output_dir=str(tmp_path))
        r.set_context(period="2026/005", run_id=42, report_id=99)
        r.started_at = datetime(2026, 6, 7, 14, 0, 0, tzinfo=timezone.utc)
        r.mark_success()
        r.finished_at = r.started_at + timedelta(hours=1, minutes=23, seconds=45)
        html = r.to_html()
        # Banner present with the timing cards
        assert 'class="timing"' in html
        assert "Started" in html and "Finished" in html and "Total time" in html
        # Human-readable duration "1h 23m 45s" (NOT just HH:MM:SS)
        assert "1h 23m 45s" in html
        # Status banner uses the success colour class
        assert 'banner ok' in html
        assert 'status ok' in html

    def test_html_duration_short_run(self, tmp_path):
        from steps.sap_odata_report import RunReport
        from datetime import datetime, timezone, timedelta
        r = RunReport(output_dir=str(tmp_path))
        r.started_at = datetime(2026, 6, 7, 14, 0, 0, tzinfo=timezone.utc)
        r.mark_success()
        r.finished_at = r.started_at + timedelta(seconds=38)
        html = r.to_html()
        assert "38s" in html

    def test_send_email_skipped_when_smtp_missing(self):
        from steps.sap_odata_report import RunReport
        r = RunReport(output_dir="/tmp")
        assert r.send_email({"send_email": True}) is False
        assert r.send_email({
            "send_email": True,
            "smtp_host": "mail.example.com",
        }) is False


# -- output_format='csv,parquet' (both) -----------------------------


class TestMultiFormatOutput:
    def test_parse_comma_list(self):
        raw = "csv,parquet"
        parts = [p.strip() for p in raw.split(",") if p.strip()]
        assert parts == ["csv", "parquet"]

    def test_rejects_bad_format(self):
        raw = "csv,ndjson"
        parts = [p.strip() for p in raw.split(",") if p.strip()]
        bad = [p for p in parts if p not in ("csv", "parquet")]
        assert bad == ["ndjson"]


# -- Email config overlay ------------------------------------------


class TestEmailCfgOverlay:
    def test_ctl_step_produces_paired_filename_and_user_spec_format(self, tmp_path):
        """User spec 2026-06-07: abc.csv.gz <-> abc.ctl; CTL has 10
        lines in exact order with UPPERCASE 32-char MD5 hex."""
        from steps.sap_create_ctl_file import SapCreateCTLFile
        from steps.sap_compress_files import SapCompressFiles
        import asyncio, os as _os

        # Build CSV + compress to get checksum + .csv.gz
        csv_path = tmp_path / 'MEBAL_2026_005.csv'
        csv_path.write_text('a|b\n1|2\n3|4\n')
        compress = SapCompressFiles(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            'consolidated_file': str(csv_path),
            'output_dir': str(tmp_path),
            'p_gjahr': '2026', 'p_poper': '005',
            'totalcount': 2, 'full_count': 2,
            'business_date': '2025-09-30',
            'run_id': 1, 'run_detail_id': 994665,
        }
        asyncio.run(compress._execute_step(task, '', '', 'SapCompressFiles'))

        ctl = SapCreateCTLFile(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        asyncio.run(ctl._execute_step(task, '', '', 'SapCreateCTLFile'))

        # Paired filenames
        assert _os.path.basename(task['compressed_file']) == 'MEBAL_2026_005.csv.gz'
        assert _os.path.basename(task['ctl_file']) == 'MEBAL_2026_005.ctl'

        # CTL content matches the exact 10-line user spec
        content = open(task['ctl_file']).read()
        lines = content.strip().split('\n')
        assert len(lines) == 10
        assert lines[0].startswith('businessDate:2025-09-30')
        assert lines[1] == 'type:sapbalance'
        # MD5 is UPPERCASE 32-char hex
        md5_line = lines[2]
        assert md5_line.startswith('md5Checksum:')
        md5_val = md5_line.split(':', 1)[1]
        assert len(md5_val) == 32
        assert md5_val == md5_val.upper()
        assert all(c in '0123456789ABCDEF' for c in md5_val)
        assert lines[3] == 'Content-Type:text/csv'
        assert lines[4] == 'dataType:sapbalance'
        assert lines[5] == 'recordCount:2'
        assert lines[6] == 'CloudCompliant:Y'
        assert lines[7] == 'content-encoding:gz'
        assert lines[8] == 'csv-separator:|'
        assert lines[9] == 'TaskID:994665'

    def test_ctl_step_uses_canonical_template_when_config_empty(self, tmp_path):
        """Per DB-as-workflow principle (2026-06-07): if the
        SapCreateCTLFile polling row exists, the step MUST emit a
        CTL file.  When ctl_template isn't in the JSON config, fall
        back to the canonical configs/sap_balance_ctl_template.json
        rather than raise."""
        from steps.sap_create_ctl_file import SapCreateCTLFile
        import asyncio
        step = SapCreateCTLFile(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        src = tmp_path / "MEBAL.csv.gz"
        src.write_bytes(b"x" * 10)
        task = {
            "totalcount": 1, "full_count": 1,
            "compressed_file": str(src),
            "output_dir": str(tmp_path),
            "p_gjahr": "2026", "p_poper": "005",
        }
        # Must NOT raise -- canonical template is used.
        result = asyncio.run(
            step._execute_step(task, "", "", "SapCreateCTLFile")
        )
        assert result == 1
        # CTL file was created (filename may have {{FILENAME}}
        # unresolved if the template's filename pattern depends on
        # a placeholder we didn't fill; just check SOMETHING got written)
        ctl_files = list(tmp_path.glob("*.ctl"))
        assert ctl_files, f"no .ctl file created in {tmp_path}"

    def test_force_fresh_run_overlay(self, tmp_path):
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "SAPU": "u", "SAPP": "p",
            "SAP_COMPANY_API": "x", "SAP_ME_BALANCE_API": "y",
            "OUTPUT_DIR": str(tmp_path),
            "FORCE_FRESH_RUN": "TRUE",
        }
        cfg = step._load_and_validate_config(task, [])
        assert cfg["force_fresh_run"] is True

    def test_force_fresh_cleanup_wipes_prior_state(self, tmp_path):
        """FORCE_FRESH_RUN=true should delete the sidecar AND prior
        run_subdir for this RUN_ID."""
        from steps.sap_odata_download import SapOdataDownload
        from steps.sap_odata_state import save_state, state_path

        # Seed prior run
        prior_subdir = tmp_path / "2026_005_old"
        prior_subdir.mkdir()
        (prior_subdir / "company_codes.csv").write_text("data")
        save_state({
            "run_subdir": str(prior_subdir),
            "downloaded_files": [], "totalcount": 100,
        }, str(tmp_path), run_id=42)
        sidecar = state_path(str(tmp_path), 42)
        assert os.path.exists(sidecar)
        assert prior_subdir.exists()

        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        step._force_fresh_cleanup(
            {"run_id": 42},
            {"output_dir": str(tmp_path), "force_fresh_run": True},
        )
        assert not os.path.exists(sidecar), "sidecar must be deleted"
        assert not prior_subdir.exists(), "prior run_subdir must be deleted"

    def test_force_fresh_cleanup_noop_when_flag_off(self, tmp_path):
        from steps.sap_odata_download import SapOdataDownload
        from steps.sap_odata_state import save_state

        prior = tmp_path / "kept"
        prior.mkdir()
        save_state({"run_subdir": str(prior)}, str(tmp_path), run_id=42)
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        # Flag false -> nothing wiped
        step._force_fresh_cleanup(
            {"run_id": 42},
            {"output_dir": str(tmp_path), "force_fresh_run": False},
        )
        assert prior.exists()

    def test_send_email_true_string_becomes_bool_true(self, tmp_path):
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "SAPU": "u", "SAPP": "p",
            "SAP_COMPANY_API": "x", "SAP_ME_BALANCE_API": "y",
            "OUTPUT_DIR": str(tmp_path),
            "SEND_EMAIL": "TRUE",
            "SMTP_HOST": "mail.example.com",
            "EMAIL_FROM": "etl@example.com",
            "EMAIL_TO": "ops@example.com",
        }
        cfg = step._load_and_validate_config(task, [])
        email_cfg = step._extract_email_cfg(cfg)
        assert email_cfg["send_email"] is True
        assert email_cfg["smtp_host"] == "mail.example.com"
        assert email_cfg["email_to"] == "ops@example.com"

    def test_send_email_false_string_becomes_bool_false(self, tmp_path):
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        task = {
            "SAPU": "u", "SAPP": "p",
            "SAP_COMPANY_API": "x", "SAP_ME_BALANCE_API": "y",
            "OUTPUT_DIR": str(tmp_path),
            "SEND_EMAIL": "FALSE",
        }
        cfg = step._load_and_validate_config(task, [])
        email_cfg = step._extract_email_cfg(cfg)
        assert email_cfg["send_email"] is False


# -- Failure-scenario coverage --------------------------------------


class TestFailureScenarios:
    """Audit of every documented completeness failure path.  One test
    per scenario, mapped to the failure-matrix the user asked about."""

    def _step(self):
        from steps.sap_odata_download import SapOdataDownload
        return SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    # Scenario 7: negative $count → fail loud (no silent acceptance)
    def test_negative_count_raises(self):
        step = self._step()
        sess = MagicMock()
        resp = MagicMock()
        resp.raise_for_status.return_value = None
        resp.text = "-1"
        sess.get.return_value = resp
        with pytest.raises(ValueError, match="negative"):
            step._fetch_odata_count(
                sess, "https://x", {"rate_limit_rps": 1000},
            )

    # Scenario 9: codes-fingerprint mismatch → re-download, not silent reuse
    def test_checkpoint_with_changed_codes_redownloads(self, tmp_path):
        step = self._step()
        # Drop a stale checkpoint that points at a file whose codes
        # DON'T match the current group composition.
        cp_dir = tmp_path
        stale_file = cp_dir / "mebal_group_0_2026_005.csv"
        stale_file.write_text("stale,data\n")
        checkpoint = {
            "completed_groups": {
                "0": {
                    "file_path": str(stale_file),
                    "row_count": 999,
                    "codes": ["1111", "2222"],   # old grouping
                    "expected_count": 999,
                },
            },
        }
        # Mock _download_group so we can detect that pending_indices
        # contains 0 (i.e. it WILL be re-downloaded).
        calls = []
        def _fake(self, session, config, group, group_idx, *a, **k):
            calls.append(group_idx)
            return {
                'group_idx': group_idx, 'codes': group,
                'expected_count': 5, 'row_count': 5,
                'file_path': str(cp_dir / f"g{group_idx}.csv"),
            }
        step._download_group = _fake.__get__(step, type(step))
        # Current group has DIFFERENT codes (8116..8128 vs stale 1111/2222).
        groups = [["8116", "8128"]]
        step._download_all_groups(
            MagicMock(), {"rate_limit_rps": 1000, "max_parallel_groups": 1},
            groups, "2026", "005", str(cp_dir), 1, checkpoint,
        )
        # Group 0 was re-downloaded (not skipped) because codes changed.
        assert calls == [0], "stale-codes checkpoint must trigger re-download"
        # And stale file was deleted.
        assert not stale_file.exists(), "stale file should be wiped"

    # Scenario 9 inverse: codes match → reuse checkpoint (no re-download)
    def test_checkpoint_with_matching_codes_skips_download(self, tmp_path):
        step = self._step()
        cp_file = tmp_path / "mebal_group_0_2026_005.csv"
        cp_file.write_text("cached,data\n")
        checkpoint = {
            "completed_groups": {
                "0": {
                    "file_path": str(cp_file),
                    "row_count": 42,
                    "codes": ["8116", "8128"],
                    "expected_count": 42,
                },
            },
        }
        calls = []
        def _fake(self, session, config, group, group_idx, *a, **k):
            calls.append(group_idx)
            return {}
        step._download_group = _fake.__get__(step, type(step))
        groups = [["8128", "8116"]]  # SAME codes, different order
        results = step._download_all_groups(
            MagicMock(), {"rate_limit_rps": 1000, "max_parallel_groups": 1},
            groups, "2026", "005", str(tmp_path), 1, checkpoint,
        )
        assert calls == [], "matching codes must skip re-download"
        assert results[0]["row_count"] == 42

    # Scenario 9 corner: checkpointed file deleted → re-download
    def test_checkpoint_with_missing_file_redownloads(self, tmp_path):
        step = self._step()
        # File doesn't exist on disk.
        checkpoint = {
            "completed_groups": {
                "0": {
                    "file_path": str(tmp_path / "never_existed.csv"),
                    "row_count": 42,
                    "codes": ["8116", "8128"],
                    "expected_count": 42,
                },
            },
        }
        calls = []
        def _fake(self, session, config, group, group_idx, *a, **k):
            calls.append(group_idx)
            return {
                'group_idx': group_idx, 'codes': group,
                'expected_count': 5, 'row_count': 5,
                'file_path': str(tmp_path / f"g{group_idx}.csv"),
            }
        step._download_group = _fake.__get__(step, type(step))
        step._download_all_groups(
            MagicMock(), {"rate_limit_rps": 1000, "max_parallel_groups": 1},
            [["8116", "8128"]], "2026", "005", str(tmp_path), 1, checkpoint,
        )
        assert calls == [0], "missing file → re-download"

    # Scenario 1 + 2 + 3: completeness ledger logs every gate
    def test_completeness_ledger_logs_every_gate(self):
        step = self._step()
        # Capture all .info calls
        step.logger = MagicMock()
        step._log_completeness_ledger(
            full_count=100,
            sum_expected=100,
            sum_actual=100,
            group_results=[
                {"group_idx": 0, "expected_count": 60, "row_count": 60, "codes": []},
                {"group_idx": 1, "expected_count": 40, "row_count": 40, "codes": []},
            ],
            period="2026/005",
        )
        # All five gates appear in the log
        log_text = " ".join(
            str(c.args[0]) for c in step.logger.info.call_args_list
        )
        for gate in ("G1 full $count", "G2", "G3", "G4", "G5"):
            assert gate in log_text, f"ledger missing {gate}"
        # No FAIL markers when everything matches
        fail_text = " ".join(
            str(c.args) for c in step.logger.info.call_args_list
            if "FAIL" in str(c.args)
        )
        assert "FAIL" not in fail_text or "delta" not in fail_text

    def test_ledger_flags_per_group_mismatch(self):
        step = self._step()
        step.logger = MagicMock()
        step._log_completeness_ledger(
            full_count=100,
            sum_expected=100,
            sum_actual=98,    # mismatch
            group_results=[
                {"group_idx": 0, "expected_count": 60, "row_count": 58, "codes": []},
                {"group_idx": 1, "expected_count": 40, "row_count": 40, "codes": []},
            ],
            period="2026/005",
        )
        # Render every logger.info call as the FINAL formatted message
        # (mirrors what would actually land in the log file) so the
        # assertions match what an operator reads.
        rendered = []
        for c in step.logger.info.call_args_list:
            args = c.args
            if not args:
                continue
            fmt = args[0]
            try:
                rendered.append(fmt % args[1:] if len(args) > 1 else fmt)
            except (TypeError, ValueError):
                rendered.append(str(args))
        all_log = "\n".join(rendered)
        assert "FAIL" in all_log
        # The per-group mismatch line includes "group 0: expected 60, actual 58".
        assert "group 0" in all_log
        assert "expected 60" in all_log
        assert "actual 58" in all_log


# ── URL building: {min}/{max}-only contract ────────────────────────


class TestMinMaxOnlyContract:
    """User-confirmed (2026-06-06): polling row supplies the FULL URL
    with everything bound EXCEPT ``{min}`` and ``{max}``."""

    def test_min_max_substitution_with_db_supplied_full_url(self):
        from steps.sap_odata_download import SapOdataDownload
        step = SapOdataDownload(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
        cfg = {
            "sap_me_balance_api": (
                "https://claude.com/sap/opu/odata/sap/zfi_claude12Bal_srv/"
                "claude12Bal(p_gjahr='2026',p_poper='005',"
                "p_timestamp=datetime'2026-06-05T12:04:21')/Data?"
                "$filter=( Companycode ge '{min}' and Companycode le '{max}')"
                "&$format=json"
            ),
        }
        base, params, cc_min, cc_max = step._build_group_url(
            cfg, ["8116", "8120", "8128"], "2026", "005",
        )
        # {min} / {max} bound; nothing else touched.
        assert "{min}" not in base
        assert "{max}" not in base
        assert "ge '8116'" in base
        assert "le '8128'" in base
        # The DB-supplied URL had period bound, so {YEAR} etc. were
        # never present — confirm they weren't introduced.
        assert "{YEAR}" not in base
        assert "p_gjahr='2026'" in base
        assert params == {}  # filter / format already in the URL
        assert cc_min == "8116"
        assert cc_max == "8128"

    def test_derive_count_url_matches_users_format(self):
        from steps.sap_odata_base import SapOdataBase
        data_url = (
            "https://claude.com/sap/opu/odata/sap/zfi_claude12Bal_srv/"
            "claude12Bal(p_gjahr='2026',p_poper='005',"
            "p_timestamp=datetime'2026-06-05T12:04:21')/Data?"
            "$filter=( Companycode ge '8116' and Companycode le '8128')"
            "&$format=json"
        )
        # Group $count URL: keep $filter, strip $format.
        group_count = SapOdataBase.derive_count_url(data_url)
        assert "/Data/$count" in group_count or "/Data/%24count" in group_count
        # Decoded sanity — filter is preserved.  urlencode produces
        # ``+`` for space in query strings (form-urlencoded); SAP
        # accepts ``+`` and ``%20`` interchangeably.  Use unquote_plus
        # so the assertion reads the canonical form.
        from urllib.parse import unquote_plus
        assert "Companycode ge '8116'" in unquote_plus(group_count)
        assert "$format" not in unquote_plus(group_count)

        # Full $count URL: strip filter entirely.
        full_count = SapOdataBase.derive_count_url(data_url, strip_filter=True)
        decoded = unquote_plus(full_count)
        assert "Companycode" not in decoded
        assert "$filter" not in decoded
        assert decoded.endswith("/Data/$count")
