"""
Base class for SAP OData API steps.
Provides HTTP session management, Basic Auth, rate limiting,
OData pagination ($top/$skip), and shared logging setup.
Does NOT depend on Spark.
"""
import csv
import json
import logging
import os
import sys
import threading
import time
from datetime import datetime, timedelta
from typing import Any, Dict, Iterator, List, Optional, Tuple  # Any used for the polling-row column overlay
from urllib.parse import urlparse, urlencode, parse_qsl, urlunparse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from steps.BaseStep import BaseStep


# Query-string params that belong to a SAP OData ``/Data`` URL but NOT
# to its companion ``/Data/$count`` URL.  Stripped when we derive the
# count URL so SAP doesn't 400 on an irrelevant parameter.
_ODATA_NON_COUNT_PARAMS = (
    "$format", "$top", "$skip", "$select",
    "$orderby", "$expand", "$inlinecount",
)


def _merge_query_params(url: str, updates: Dict[str, str]) -> str:
    """Set / override query-string params on ``url`` without duplicating
    keys that are already present.

    Plain ``session.get(url, params={...})`` MERGES the dict into the
    URL's existing query string -- keys present in both end up duplicated
    (``?a=1&a=2``).  SAP rejects some duplicate-param requests with 401
    or 400.  Use this helper to set + override safely.

    ``safe='$'`` keeps the OData ``$filter`` / ``$top`` / ``$skip`` keys
    literal in the encoded query string instead of becoming
    ``%24filter`` -- some strict SAP gateways reject the percent-encoded
    form, and the OData spec calls for the literal ``$`` anyway.
    """
    parsed = urlparse(url)
    existing = dict(parse_qsl(parsed.query, keep_blank_values=True))
    existing.update({k: str(v) for k, v in updates.items()})
    return urlunparse(
        parsed._replace(query=urlencode(existing, safe="$"))
    )


class SapOdataBase(BaseStep):
    """Base class for SAP OData steps with shared HTTP client and pagination."""

    LOG_PREFIX: str = "sap_odata"

    DEFAULT_RATE_LIMIT_RPS = 5
    DEFAULT_TIMEOUT_SECONDS = 120
    # ``$top`` per page.  SAP OData V2 ships the WHOLE page in one
    # HTTP response -- so this is the chunk size for the count->stream
    # pipeline.
    #
    # Default 5,000 / Hard cap 50,000 -- both deliberate:
    #
    #   * For a 9-million-row extract the LEGACY 100,000/page meant
    #     SAP had to render + serialize a ~50 MB JSON blob per
    #     round-trip.  On a slow SAP service that's where the
    #     "everything hangs" feeling comes from -- the SERVER is
    #     blocked, not us.  We want SAP to ship many SMALL chunks,
    #     not few big ones.
    #   * 5,000/page = ~1,800 round-trips for 9 M rows.  Each one
    #     returns in single-digit seconds, the paginator yields it,
    #     the sink writes it, the JSON list is GC'd, peak memory
    #     stays at one page (~2-5 MB).
    #   * 50,000 is the HARD CEILING -- even if an operator sets
    #     PAGE_SIZE=100000 on the polling row we clamp it down so
    #     we never reintroduce the slow-render symptom.
    #
    # Operators tune via polling-row ``PAGE_SIZE`` (overlay above)
    # or ``page_size`` in the JSON tuning config: LOWER (1 K-2 K)
    # when SAP is timing out mid-page, HIGHER (10 K-50 K) on a fast
    # network.  The clamp logic lives in ``_stream_odata_pages`` so
    # every code path shares the same ceiling.
    # 50,000 is BOTH the default AND the hard ceiling (default == max).
    # Source of truth is the SQL polling query (PAGE_SIZE column);
    # this Python default only kicks in when the row leaves it NULL.
    # Operators can ONLY go DOWN from 50K via the polling row -- there
    # is no path to push it higher.  See class docstring + 2026-06-06
    # comment in etl_polling_task_query.yaml for the reasoning.
    DEFAULT_TOP = 50000
    MAX_TOP = 50000
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_RETRY_BACKOFF = 2

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Audit SERIOUS #12 -- token-bucket rate limit state.
        # Pre-Phase-134-K used a single mutex + min-interval check
        # which SERIALISED every page across every parallel group:
        # ``max_parallel_groups=3`` was theatre, the actual SAP
        # throughput was 1 request at a time.
        #
        # Token bucket lets ``rps`` tokens accumulate concurrently --
        # 3 threads with rps=5 can each fire a request in the same
        # second as long as the total stays under 5 RPS.
        self._rate_limit_lock = threading.Lock()
        self._rate_tokens: float = 0.0           # available token count
        self._rate_last_refill: float = time.time()
        self._rate_rps_observed: float = 0.0     # last-seen rps (refill rate)
        self._rate_capacity: float = 0.0         # bucket size (= rps, 1-second burst)

    def _load_and_validate_config(self, task: Dict, required_fields: List[str]) -> Dict:
        """Build the SAP step's config from polling-row columns + built-in
        defaults.

        SAP is URL-based -- there is no SQL file to load.  Tuning knobs
        come from:

          1. Polling-row columns (SAPU / SAPP / SAP_COMPANY_API /
             SAP_ME_BALANCE_API / NUM_GROUPS / RUN_TIMESTAMP /
             OUTPUT_DIR / CTL_TEMPLATE_PATH / COLUMN_MAPPING_PATH /
             DELIVERY_TYPE).
          2. Built-in defaults (page_size, rate_limit_rps, max_parallel,
             output_dir from ``get_data_root()``, etc.).

        The legacy ``sql_query_path`` column is ignored -- SAP never had
        a SQL file, the name was a misleading hand-me-down from the
        Starburst->Oracle workflow that shared the same polling table.
        Operators who used to put a JSON tuning file there should move
        the needed values to dedicated polling-row columns (or extend
        this method's overlay table below).
        """
        config: Dict[str, Any] = {}

        # -- Overlay SAP polling-row columns onto config ------------
        # The polling query exposes these via the task dict (column name
        # -> dict key).  Task-row values take precedence so DB-managed
        # credentials always win over JSON.  Empty / None values fall
        # through to whatever the JSON config provided.
        #
        # 2026-06-03 -- added NUM_GROUPS + RUN_TIMESTAMP so polling rows
        # can override the parallelism knob + deterministic-replay
        # timestamp without a JSON edit.  P_GJAHR / P_POPER stay
        # task-only reads (they have conditional fall-back logic in
        # ``sap_odata_download._execute_step`` -- `period_mode` derives
        # them when the row leaves them NULL).
        for src_key, cfg_key in (
            ('SAPU',               'sap_username'),
            ('SAPP',               'sap_password'),
            ('SAP_COMPANY_API',    'sap_company_api'),
            ('SAP_ME_BALANCE_API', 'sap_me_balance_api'),
            ('NUM_GROUPS',         'num_groups'),
            ('RUN_TIMESTAMP',      'run_timestamp'),
            ('OUTPUT_DIR',         'output_dir'),
            # 2026-06-06 -- output_format lives on the polling row so
            # operators can flip csv<->parquet per task without a JSON edit.
            # Default falls through to 'csv' in the download step.
            ('OUTPUT_FORMAT',      'output_format'),
            # 2026-06-06 -- PAGE_SIZE on the polling row lets ops dial
            # the SAP $top per task without redeploying JSON config.
            # Critical for slow SAP services where the default 5000
            # still times out mid-page (drop to 1000-2000) OR a fast
            # path where 20k-50k saves round-trips.
            ('PAGE_SIZE',          'page_size'),
            # Per-page HTTP timeout -- relax to 300-600 when SAP is
            # rendering very wide rows or under heavy load.
            ('PAGE_TIMEOUT_SECONDS', 'timeout_seconds'),
            # 2026-06-07 -- codes-per-group ceiling (drives bucket count).
            # Default 100; lower (50) for very wide MEBAL rows; higher
            # (200-500) for tenants where SAP $filter handles big OR
            # clauses comfortably.
            ('CODES_PER_GROUP',    'codes_per_group'),
            # 2026-06-07 -- intra-group page parallelism.  C# pattern
            # uses 5 concurrent page fetches per group; matching it
            # here gives ~5x throughput per group.  Default 1 (back-
            # compat = serial pagination).  Set 5 to match C#.  When
            # combined with max_parallel_groups=3 the total in-flight
            # request budget is 15 -- the HTTP pool auto-scales.
            ('INTRA_GROUP_PARALLEL', 'intra_group_parallel'),
            # 2026-06-07 -- group-level parallelism (number of groups
            # that download concurrently).  C# benchmark uses 5; we
            # match.  Total in-flight = MAX_PARALLEL_GROUPS x
            # INTRA_GROUP_PARALLEL (default 5 x 2 = 10).
            ('MAX_PARALLEL_GROUPS', 'max_parallel_groups'),
            # 2026-06-07 -- analytics Parquet emit (post-CheckCompleteness).
            # When 'TRUE', SapEmitAnalyticsParquet produces a single
            # Parquet file alongside the CSV.gz delivery payload so
            # QueryStudio can query the certified extract.  When 'FALSE',
            # the step short-circuits (CSV.gz delivery unaffected).
            ('GENERATE_PARQUET',    'analytics_enabled'),
            ('ANALYTICS_DIR',       'analytics_dir'),
            ('ANALYTICS_COMPRESSION', 'analytics_compression'),
            # 2026-06-07 -- email notifications (start + finish).
            # Local-dev: leave SEND_EMAIL = 'FALSE' on the row;
            # report still lands as run_report.html in output_dir.
            ('SEND_EMAIL',         'send_email'),
            ('SMTP_HOST',          'smtp_host'),
            ('SMTP_PORT',          'smtp_port'),
            ('SMTP_USER',          'smtp_user'),
            ('SMTP_PASSWORD',      'smtp_password'),
            ('SMTP_USE_TLS',       'smtp_use_tls'),
            ('EMAIL_FROM',         'email_from'),
            ('EMAIL_TO',           'email_to'),
            ('EMAIL_SUBJECT',      'email_subject'),
            # 2026-06-06 -- TLS verify lives on the polling row as
            # 'TRUE'/'FALSE' (Oracle char column).  We coerce via the
            # _VERIFY_SSL_TRUTHY set below.  Default (NULL/empty)
            # -> True (safe) -- only an explicit 'FALSE'/'0'/'NO' on the
            # row disables verification.  Env var SAP_VERIFY_SSL still
            # wins over both (local-dev escape hatch in _build_session).
            ('VERIFY_SSL',         'verify_ssl'),
            ('CA_BUNDLE_PATH',     'ca_bundle_path'),
            ('PROXY_URL',          'proxy_url'),
        ):
            v = task.get(src_key)
            if v is None:
                # Try lower-case key (polling-row normaliser also
                # exposes lower-cased columns).
                v = task.get(src_key.lower())
            # 2026-06-07 -- DON'T treat False/0 as "unset" here.  Pre-fix
            # ``v not in (None, "", 0)`` matched ``False`` because Python
            # equates ``False == 0``, so a polling row carrying
            # ``GENERATE_PARQUET='FALSE'`` would be coerced to bool False
            # then silently skipped on overlay -- analytics_enabled stayed
            # at its default True.  Now: only skip None and empty string.
            if v is None or (isinstance(v, str) and v == ""):
                continue
            if True:  # preserve indentation of the block below
                # Integer-typed columns: coerce defensively so a string
                # value on the row doesn't poison config['page_size']
                # downstream where it's compared against ints.
                if cfg_key in ('num_groups', 'page_size', 'timeout_seconds', 'codes_per_group', 'intra_group_parallel', 'max_parallel_groups'):
                    try:
                        config[cfg_key] = int(v)
                    except (TypeError, ValueError):
                        # Bad value in the row -- log and fall back to
                        # whatever JSON provided.  Hard-fail would
                        # block the run for a typo.
                        self.logger.warning(
                            "%s row value %r is not an int -- "
                            "falling back to default", src_key, v,
                        )
                elif cfg_key in ('verify_ssl', 'analytics_enabled', 'smtp_use_tls'):
                    # 'TRUE'/'FALSE' (Oracle char) -> real bool.  Map
                    # the truthy set + everything else -> False so a
                    # typo defaults to "trust the certificate" only
                    # when explicitly asked.
                    s = str(v).strip().upper()
                    if s in {'TRUE', '1', 'YES', 'Y'}:
                        config[cfg_key] = True
                    elif s in {'FALSE', '0', 'NO', 'N'}:
                        config[cfg_key] = False
                    else:
                        self.logger.warning(
                            "VERIFY_SSL row value %r is neither "
                            "TRUE nor FALSE -- defaulting to True",
                            v,
                        )
                        config[cfg_key] = True
                else:
                    config[cfg_key] = v

        # -- Built-in defaults -- make the JSON config truly optional --
        # output_dir: derive from ETL data root so Windows local +
        # OpenShift both work without any JSON / row config.  Caller
        # can still override via polling-row OUTPUT_DIR or JSON.
        if not config.get('output_dir'):
            try:
                from log_config import get_data_root as _data_root
                config['output_dir'] = os.path.join(
                    _data_root(), 'sap_mebal', 'output',
                )
            except Exception:
                import tempfile
                config['output_dir'] = os.path.join(
                    tempfile.gettempdir(), 'sap_mebal', 'output',
                )

        missing = [f for f in required_fields if not config.get(f)]
        if missing:
            raise ValueError(
                f"Missing required config fields: {missing}. "
                "Set them on the task row (SAPU / SAPP / SAP_COMPANY_API / "
                "SAP_ME_BALANCE_API / OUTPUT_DIR) or in the JSON config at "
                "sql_query_path."
            )
        return config

    def _setup_logging(self, task: Dict) -> None:
        """Configure a named logger for this step.

        Uses the shared pipeline log file from ``task['log_file']`` so all
        5 steps write to a single file.  Falls back to a per-step file if
        the task dict doesn't carry a log path.
        """
        # Use a named logger -- never destroy root handlers
        self.logger = logging.getLogger(f"sap_odata.{self.LOG_PREFIX}")

        # Avoid adding duplicate handlers if _setup_logging is called again
        if self.logger.handlers:
            return

        self.logger.setLevel(logging.INFO)
        self.logger.addHandler(logging.StreamHandler(sys.stdout))

        # Prefer shared pipeline log file; fall back to per-step file.
        # Audit NIT -- log directory used to be hardcoded
        # ``/usr/local/spark/nfs/bcp/batch/logs/``.  Now config-driven
        # via ``log_dir`` (task or JSON config) so non-Spark
        # deployments don't need a Spark NFS layout.
        log_path = task.get('log_file')
        if not log_path:
            run_id = task.get('run_id', 'unknown')
            date_str = datetime.now().strftime('%Y-%m-%d')
            # task['log_dir'] wins over config['log_dir'] wins over the
            # legacy Spark default.  All three live in this file as the
            # single source of truth.
            try:
                from log_config import get_log_dir as _resolve_log_dir
                _shared_log_dir = _resolve_log_dir()
            except Exception:
                # Last-resort fallback: temp dir on whatever OS we're on,
                # so we never crash trying to create a path the platform
                # can't honour.
                import tempfile
                _shared_log_dir = tempfile.gettempdir()
            log_dir = (
                task.get('log_dir')
                or (self.config or {}).get('log_dir')
                or _shared_log_dir
            )
            log_path = os.path.join(
                log_dir, f"sap_odata_{run_id}_{date_str}.log",
            )

        # Create log directory if needed, add file handler.
        # encoding='utf-8' is critical -- without it Windows file handlers
        # default to cp1252 and any non-ASCII char (degree sign, smart
        # quote, accented name in a SAP value) crashes the WHOLE run
        # with UnicodeEncodeError mid-log.  We also wrap the stdout
        # StreamHandler so console output survives.
        try:
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            self.logger.addHandler(
                logging.FileHandler(log_path, encoding='utf-8')
            )
        except OSError as e:
            self.logger.warning(f"Cannot create log file {log_path}: {e} -- console only")

        # Wrap the StreamHandler's stream so non-ASCII chars get
        # transliterated instead of raising on the Windows console.
        # ``errors='replace'`` substitutes '?' for chars the terminal
        # encoding can't handle -- visible but never crashes the run.
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')  # type: ignore[attr-defined]
        except (AttributeError, OSError):
            # Older Python or stream that doesn't support reconfigure --
            # the ASCII-only log messages we emit will work anyway.
            pass

    def _build_session(self, config: Dict) -> requests.Session:
        """Build requests.Session with Basic Auth, retries, and connection pooling."""
        session = requests.Session()

        # Basic Auth -- log the user (NEVER the password) so an operator
        # can confirm creds were threaded from the polling row.
        username = config.get('sap_username', '')
        password = config.get('sap_password', '')
        if username:
            session.auth = (username, password)
            self.logger.info(
                "SAP HTTP session: Basic Auth user=%r (pwd len=%d)",
                username, len(password or ''),
            )
        else:
            self.logger.warning(
                "SAP HTTP session: NO Basic Auth -- SAPU column on the "
                "polling row was empty.  Expect 401 from the SAP endpoint."
            )

        session.headers.update({
            'Accept': 'application/json',
        })

        # Retry strategy with exponential backoff
        retry_strategy = Retry(
            total=config.get('max_retries', self.DEFAULT_MAX_RETRIES),
            backoff_factor=config.get('retry_backoff', self.DEFAULT_RETRY_BACKOFF),
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"],
        )
        # 2026-06-07 -- pool size scales with the COMBINED concurrency
        # budget (max_parallel_groups x intra_group_parallel) + headroom
        # for the $count probes that fire alongside data pages.  Pre-fix
        # the hardcoded 10 was the trigger for "HTTPSConnectionPool full,
        # discarding connection" errors when 20+ groups raced.
        #
        # Example: max_parallel_groups=3 + intra_group_parallel=5 ->
        #   15 in-flight data fetches + 3 in-flight $count probes
        #   = 18 concurrent connections needed.  We size to 2x for
        #   keep-alive + new-connection overlap = pool_size 36.
        groups_parallel = max(1, int(config.get('max_parallel_groups', 3)))
        intra_parallel = max(1, int(config.get('intra_group_parallel', 1)))
        in_flight = groups_parallel * intra_parallel + groups_parallel
        pool_size = max(20, in_flight * 2)
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=pool_size,
            pool_maxsize=pool_size,
            pool_block=False,   # don't block on pool exhaustion
        )
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        self.logger.info(
            "SAP HTTP session: connection pool size=%d "
            "(max_parallel_groups=%d x intra_group_parallel=%d -> "
            "%d in-flight + headroom)",
            pool_size, groups_parallel, intra_parallel, in_flight,
        )

        # -- SSL verification -- verify_ssl=False ALWAYS WINS ------
        #
        # Precedence (highest to lowest, after 2026-06-06 user pushback):
        #
        #   1. ``verify_ssl=False`` (config or polling-row VERIFY_SSL='FALSE'
        #      or env SAP_VERIFY_SSL=false).  Hard skip -- no cert lookup,
        #      no CA bundle load, no env-var consultation, no MITM check.
        #      The operator said "no", we respect it everywhere.
        #   2. ``ca_bundle_path`` (explicit corporate-CA file).  Used only
        #      when verify_ssl is true; if the file is missing we now log a
        #      WARN + fall back to system CA store instead of raising
        #      (raising blocked perfectly fine system-CA runs).
        #   3. ``verify_ssl=True`` (default).  System CA store.
        #
        # Why the rewrite: pre-2026-06-06 ``if ca_bundle:`` came BEFORE the
        # verify-False short-circuit, so a stale ``CA_BUNDLE_PATH`` (env
        # var, legacy config) at a missing path would raise
        # ``FileNotFoundError`` even when the row clearly set
        # ``VERIFY_SSL='FALSE'``.  Operator's intent was "no SSL check";
        # the code instead complained about a CA file.
        #
        # We also clear REQUESTS_CA_BUNDLE / CURL_CA_BUNDLE on the session
        # env when verify is False so a host-level env var can't sneak a
        # cert lookup back in past our explicit ``session.verify=False``.
        ca_bundle = config.get('ca_bundle_path') or ''
        env_verify = os.environ.get('SAP_VERIFY_SSL', '').strip().lower()
        if env_verify in ('false', '0', 'no'):
            verify_ssl = False
            verify_source = "env SAP_VERIFY_SSL=false"
        elif env_verify in ('true', '1', 'yes'):
            verify_ssl = True
            verify_source = "env SAP_VERIFY_SSL=true"
        else:
            verify_ssl_raw = config.get('verify_ssl', True)
            # Explicit NULL -> True (``bool(None)`` is False which would
            # silently disable SSL).
            verify_ssl = True if verify_ssl_raw is None else bool(verify_ssl_raw)
            verify_source = (
                f"config verify_ssl={verify_ssl_raw!r}"
                if 'verify_ssl' in config else "default (True)"
            )

        if verify_ssl is False:
            # Hard skip -- no ca_bundle, no env vars, no surprises.
            session.verify = False
            # Block REQUESTS_CA_BUNDLE / CURL_CA_BUNDLE from re-injecting
            # a cert lookup on this session.  ``Session.trust_env`` is
            # the requests-level switch for env-var trust.
            session.trust_env = False
            # Suppress urllib3 InsecureRequestWarning so the log isn't
            # flooded with 90+ warnings per group (one per page).
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            self.logger.warning(
                "SAP HTTP session: SSL verification DISABLED "
                "(source: %s).  ca_bundle_path=%r ignored.  "
                "session.trust_env=False to block REQUESTS_CA_BUNDLE / "
                "CURL_CA_BUNDLE env-var injection.  Do NOT use in production "
                "unless the corporate-CA bundle is unavailable.",
                verify_source, ca_bundle,
            )
        elif ca_bundle:
            if not os.path.exists(ca_bundle):
                # Don't raise -- fall back to system CA store with a WARN.
                # An explicit verify_ssl=True request with a missing
                # bundle should NOT halt the run; that's a config-mistake
                # that produces a misleading "cert not found" error when
                # the operator never asked for the bundle at all.
                self.logger.warning(
                    "SAP HTTP session: ca_bundle_path %r does not exist "
                    "-- falling back to system CA store.  Either remove "
                    "ca_bundle_path from config or point it at the "
                    "corporate CA file.",
                    ca_bundle,
                )
                session.verify = True
                self.logger.info(
                    "SAP HTTP session: SSL verify=True (system CA store, "
                    "source: %s)", verify_source,
                )
            else:
                session.verify = ca_bundle
                self.logger.info(
                    "SAP HTTP session: SSL verify via CA bundle %s "
                    "(source: %s)", ca_bundle, verify_source,
                )
        else:
            session.verify = True
            self.logger.info(
                "SAP HTTP session: SSL verify=True (system CA store, "
                "source: %s)", verify_source,
            )

        proxy_url = config.get('proxy_url', '')
        if proxy_url:
            session.proxies = {'https': proxy_url, 'http': proxy_url}

        return session

    # ==================================================================
    # Count-driven streaming primitives (Phase 134-N)
    #
    # SAP OData V2 exposes a ``/$count`` sibling for every collection
    # entity.  We use it to drive a count -> stream -> reconcile flow:
    #
    #   1. ``derive_count_url``        -- turn a /Data URL into its
    #                                     /Data/$count companion (with
    #                                     or without the $filter).
    #   2. ``_fetch_odata_count``      -- single GET, returns ``int``.
    #                                     Tolerant of plain-text or
    #                                     ``d`` envelope responses.
    #   3. ``_stream_odata_pages``     -- generator yielding (page_idx,
    #                                     rows) for $top/$skip-paginated
    #                                     reads.  Never aggregates --
    #                                     caller writes each page to its
    #                                     own sink (CSV / Parquet) and
    #                                     the page is released for GC.
    #
    # These are the building blocks the download step composes into the
    # count-then-stream-then-reconcile contract the user requested:
    # per-group expected vs actual MUST match, and the sum of per-group
    # $counts MUST equal the unfiltered /Data/$count.
    # ==================================================================

    @staticmethod
    def derive_count_url(
        base_url: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        strip_filter: bool = False,
    ) -> str:
        """Build the OData ``$count`` URL for a ``/Data`` URL.

        * Path: ensures it ends with ``/$count``.  If the caller passed a
          URL that already targets ``/$count`` we leave it alone.
        * Query: strips ``$format`` / ``$top`` / ``$skip`` / etc -- they're
          irrelevant to a scalar-count GET and some SAP services reject
          unknown query params with HTTP 400.  ``$filter`` is RETAINED
          unless ``strip_filter=True`` (used for the full-period count).
        * ``params`` are merged into the URL first so callers can pass a
          ``params={'$filter': ...}`` dict instead of pre-baking it.
        """
        if params:
            base_url = _merge_query_params(base_url, params)
        parsed = urlparse(base_url)
        path = parsed.path.rstrip("/")
        if not path.endswith("/$count"):
            path = path + "/$count"
        qs = dict(parse_qsl(parsed.query, keep_blank_values=True))
        for k in _ODATA_NON_COUNT_PARAMS:
            qs.pop(k, None)
        if strip_filter:
            qs.pop("$filter", None)
        # safe='$' keeps OData $filter / $count literal -- see
        # ``_merge_query_params`` for the rationale.
        new_qs = urlencode(qs, safe="$") if qs else ""
        return urlunparse(parsed._replace(path=path, query=new_qs))

    def _fetch_odata_count(
        self, session: requests.Session, count_url: str, config: Dict,
    ) -> int:
        """GET a SAP OData ``$count`` URL, return the integer.

        SAP V2 services return $count as **text/plain** by default
        (per the OData spec) -- we force ``Accept: text/plain`` so the
        session's default ``application/json`` header doesn't trigger a
        Not-Acceptable on strict gateways.  As a defensive fallback we
        also parse a JSON ``{"d": N}`` / ``{"d": {"__count": "N"}}``
        envelope when SAP servers wrap the integer.
        """
        timeout = config.get("timeout_seconds", self.DEFAULT_TIMEOUT_SECONDS)
        rate_limit = config.get("rate_limit_rps", self.DEFAULT_RATE_LIMIT_RPS)

        self._rate_limit(rate_limit)
        self.logger.info(f"Fetching $count: {count_url}")
        resp = session.get(
            count_url, timeout=timeout,
            headers={"Accept": "text/plain"},
        )
        resp.raise_for_status()
        text = (resp.text or "").strip()
        # Strip BOM / surrounding quotes some services emit.
        text = text.lstrip("﻿").strip('"').strip()

        parsed_n: Optional[int] = None
        try:
            parsed_n = int(text)
        except ValueError:
            pass

        # JSON-envelope fallback (rare but seen on customised SAP services).
        if parsed_n is None:
            try:
                data = json.loads(text)
            except (ValueError, json.JSONDecodeError):
                raise ValueError(
                    f"SAP $count response is not an integer or JSON envelope "
                    f"(URL: {count_url}, body[:200]={text[:200]!r})"
                )
            if isinstance(data, (int, float)):
                parsed_n = int(data)
            elif isinstance(data, dict):
                inner = data.get("d")
                if isinstance(inner, (int, str)):
                    try:
                        parsed_n = int(inner)
                    except (TypeError, ValueError):
                        pass
                if parsed_n is None and isinstance(inner, dict):
                    for key in ("__count", "count", "value"):
                        val = inner.get(key)
                        if val is not None:
                            try:
                                parsed_n = int(val)
                                break
                            except (TypeError, ValueError):
                                pass
            if parsed_n is None:
                raise ValueError(
                    f"SAP $count response could not be parsed as an integer "
                    f"(URL: {count_url}, body[:200]={text[:200]!r})"
                )

        # Guard against a negative $count.  SAP shouldn't ever return
        # one, but if a future service responds with -1 to signal
        # "unknown" or some bug returns a signed underflow, we'd
        # silently treat it as "expected 0 or fewer rows" and the
        # per-group reconcile would accept any number of streamed
        # rows >= 0.  Fail loud instead.
        if parsed_n < 0:
            raise ValueError(
                f"SAP $count returned a negative value {parsed_n} "
                f"(URL: {count_url}).  Treating as a service bug -- "
                f"halting before we ship unknowable data."
            )
        return parsed_n

    def _stream_odata_pages(
        self, session: requests.Session, base_url: str,
        params: Dict[str, str], config: Dict,
        *, expected_count: Optional[int] = None,
    ) -> Iterator[Tuple[int, List[Dict[str, Any]]]]:
        """Yield ``(page_idx, rows_list)`` for a paginated SAP read.

        Streaming model (the question every operator asks):

          * SAP OData V2 does NOT support sub-page chunked transfer.
            One HTTP GET returns one full page of up to ``$top`` rows
            in a single JSON body.  We can't bypass that.
          * What we CAN do -- and what this generator does -- is bound
            the chunk size with ``$top``, then pipeline:
                fetch page N  --┐
                yield page N  --┴-- sink writes page N to disk
                fetch page N+1
                yield page N+1 -> sink writes page N+1
                ...
            Peak memory = ``$top`` rows at any moment, regardless of
            whether the full extract is 1 K or 90 M rows.
          * For a 9 M-row extract with ``page_size=5000`` that's
            ~1,800 round-trips x ~5 K rows each.  Slow SAP services
            return each page in single-digit seconds; the sink writes
            it; memory frees; next page fires.

        If your SAP API is timing out mid-page, DROP ``page_size`` on
        the polling row (PAGE_SIZE column) -- that shrinks the
        per-request payload size and gives SAP a smaller blob to
        render.  If you have a fast network and SAP is healthy, RAISE
        it (10 K-20 K) to cut round-trips.

        Termination rule mirrors ``_paginated_odata_get`` (audit
        SERIOUS #9): empty page OR (no ``__next`` link AND a partial
        page) ends the stream; otherwise keep paging.

        ``expected_count`` is purely advisory -- when supplied we log
        progress as ``cumulative/expected`` so an operator can spot a
        stall in a large extract.
        """
        top = self._resolve_page_size(config)
        timeout = config.get("timeout_seconds", self.DEFAULT_TIMEOUT_SECONDS)
        rate_limit_rps = config.get("rate_limit_rps", self.DEFAULT_RATE_LIMIT_RPS)

        skip = 0
        page = 0
        cumulative = 0

        while True:
            page_url = _merge_query_params(base_url, {
                **{k: str(v) for k, v in (params or {}).items()},
                "$top": str(top),
                "$skip": str(skip),
                "spnego": "disabled",
            })

            self._rate_limit(rate_limit_rps)

            self.logger.info(
                f"Streaming page {page} ($skip={skip}, $top={top})"
            )
            self.logger.info(f"  URL: {page_url}")
            resp = session.get(page_url, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()

            if page == 0:
                self._validate_d_envelope(data, base_url)

            d_env = (data.get("d") if isinstance(data, dict) else None) or {}
            results = d_env.get("results", []) or []

            if not results:
                self.logger.info(
                    f"End of stream at page {page} (empty page, cumulative={cumulative})"
                )
                break

            cumulative += len(results)
            if expected_count is not None and expected_count > 0:
                pct = cumulative / expected_count * 100.0
                self.logger.info(
                    f"Page {page}: {len(results)} rows "
                    f"(cumulative {cumulative:,}/{expected_count:,}, {pct:.1f}%)"
                )
            else:
                self.logger.info(
                    f"Page {page}: {len(results)} rows (cumulative {cumulative:,})"
                )

            yield page, results

            next_link = d_env.get("__next")
            if next_link is None:
                meta = d_env.get("__metadata") or {}
                if isinstance(meta, dict):
                    next_link = meta.get("__next")

            if next_link is None and len(results) < top:
                self.logger.info(
                    f"End of stream at page {page} "
                    f"(no __next, partial page {len(results)}/{top})"
                )
                break

            skip += top
            page += 1
            if page > 100000:
                self.logger.error(
                    "Streaming pagination cap (100000 pages) hit -- possible truncation"
                )
                break

    # ====================================================================
    # Cross-step state handoff (Phase 134-O, 2026-06-07)
    #
    # Every SAP polling row is a SEPARATE task dict.  Download stashes
    # ``downloaded_files`` / ``full_count`` / etc. on its task dict but
    # the next step (Consolidate / Compress / CTL / Deliver) runs on a
    # DIFFERENT polling row -- task dicts don't share by reference.
    #
    # Sidecar JSON file keyed by RUN_ID bridges the gap.  Every step
    # calls ``_hydrate_from_sidecar`` on entry to populate its task
    # dict from disk; Download calls ``_save_sidecar`` to persist its
    # state for the chain.
    # ====================================================================

    # Keys that downstream SAP steps need lifted from the sidecar.
    # Extending this list when a new shared field appears is the
    # single point of maintenance for cross-step state.
    _SIDECAR_KEYS = (
        "run_subdir",
        "downloaded_files",
        "consolidated_file",
        "consolidated_files",
        "compressed_file",
        "ctl_file",
        "p_gjahr",
        "p_poper",
        "output_format",
        "output_formats",
        "full_count",
        "per_group_counts",
        "completeness_ledger",
        "totalcount",
        "checksum",
        "compressed_size",
        "uncompressed_size",
    )

    def _hydrate_from_sidecar(self, task: Dict, config: Dict) -> bool:
        """Populate ``task`` with state persisted by a prior step's run.

        No-op when the task dict already carries ``downloaded_files``
        (covers the single-pod / single-task path used by tests where
        download + consolidate share a dict).

        Otherwise reads the sidecar at ``<config[output_dir]>/
        _sap_state_<run_id>.json`` and lifts every key in
        ``_SIDECAR_KEYS`` onto the task dict.  Returns True if state
        was hydrated, False if the sidecar was missing / empty.
        """
        if task.get("downloaded_files") or task.get("consolidated_file"):
            return False  # already populated by an in-process predecessor
        from steps.sap_odata_state import load_state
        base = config.get("output_dir") or ""
        run_id = task.get("run_id") or task.get("RUN_ID")
        state = load_state(base, run_id, logger=self.logger)
        if state is None:
            self.logger.warning(
                "_hydrate_from_sidecar: no sidecar at %s for run_id=%s "
                "-- downstream step will likely fail the 'must run first' "
                "check.  Confirm SapOdataDownload ran and points at the "
                "same OUTPUT_DIR.",
                base, run_id,
            )
            return False
        hydrated = []
        for k in self._SIDECAR_KEYS:
            if k in state and task.get(k) in (None, "", []):
                task[k] = state[k]
                hydrated.append(k)
        # output_dir on the row is the BASE; the sidecar stores the
        # RUN SUBDIR -- override so the step sees the actual data
        # files in run_subdir, not the empty base.
        if state.get("run_subdir"):
            task["output_dir"] = state["run_subdir"]
        self.logger.info(
            "_hydrate_from_sidecar: lifted %d keys from sidecar (%s) -- "
            "downloaded_files=%d, totalcount=%s, run_subdir=%s",
            len(hydrated), ",".join(hydrated),
            len(task.get("downloaded_files") or []),
            task.get("totalcount"),
            task.get("output_dir"),
        )
        return True

    def _save_sidecar(self, task: Dict, config: Dict) -> Optional[str]:
        """Persist every shared task-state key to the sidecar.  Returns
        the path written (or None on best-effort failure)."""
        from steps.sap_odata_state import save_state
        base = config.get("output_dir") or ""
        run_id = task.get("run_id") or task.get("RUN_ID")
        state = {k: task[k] for k in self._SIDECAR_KEYS if k in task}
        return save_state(state, base, run_id, logger=self.logger)

    def _resolve_page_size(self, config: Dict) -> int:
        """Centralised ``$top`` resolution + 50 K hard cap.

        Treats anything > ``MAX_TOP`` as a misconfiguration and clamps
        DOWN with a one-shot WARN.  Treats <= 0 as "use the default" --
        a zero would otherwise produce an infinite loop ($skip never
        advances).
        """
        raw = config.get("page_size", self.DEFAULT_TOP)
        try:
            top = int(raw)
        except (TypeError, ValueError):
            self.logger.warning(
                "page_size %r is not an integer -- using default %d",
                raw, self.DEFAULT_TOP,
            )
            top = self.DEFAULT_TOP
        if top <= 0:
            self.logger.warning(
                "page_size %d <= 0 -- using default %d",
                top, self.DEFAULT_TOP,
            )
            top = self.DEFAULT_TOP
        if top > self.MAX_TOP:
            self.logger.warning(
                "page_size %d exceeds MAX_TOP cap %d -- clamping down "
                "(SAP renders big pages slowly; many small chunks beat "
                "few large ones)",
                top, self.MAX_TOP,
            )
            top = self.MAX_TOP
        return top

    def _stream_odata_pages_parallel(
        self, session: requests.Session, base_url: str,
        params: Dict[str, str], config: Dict,
        *, expected_count: int, parallel: int,
    ) -> Iterator[Tuple[int, List[Dict[str, Any]]]]:
        """PARALLEL page fetch -- BOUNDED in-flight, no pile-up.

        Mirrors the C# pattern that streams N pages concurrently per
        group.  Uses ``expected_count`` (from a pre-flight $count) to
        plan all (skip, top) offsets, then drives a sliding window
        of EXACTLY ``parallel`` in-flight futures.  As each completes,
        the next page is submitted -- never more than ``parallel``
        outstanding.

        Why bounded:  the naive ``submit-all-then-as_completed`` form
        lets COMPLETED futures pile up in the executor's result queue
        when the main thread (sink write) is slower than the workers.
        For 9 M rows / 50 K page = 180 pages; pile-up could hold ALL
        180 parsed pages in memory at once (~17 GB worst case).
        Bounded form caps peak at ``parallel + 1`` pages per group --
        2 in flight + 1 currently being written.

        Memory formula per group (typical MEBAL):
            peak_MB ~= (parallel + 1) * (PAGE_SIZE * 1900 bytes / 1e6)

        Defaults (parallel=2, PAGE_SIZE=50_000):
            ~3 * 50_000 * 1900 / 1e6 = ~285 MB per group
            x MAX_PARALLEL_GROUPS=5  = ~1.4 GB peak total

        Yields (page_idx, rows) in COMPLETION ORDER -- callers must
        use an order-agnostic sink (CSV / Parquet both fine).  Sink
        writes happen on the MAIN THREAD, so the sink itself does NOT
        need to be thread-safe.

        Termination is by COUNT (no ``__next`` chase) -- if SAP
        returns fewer rows than ``expected_count`` suggested, the
        per-group reconcile in ``_download_group`` catches it and
        retries the whole group.
        """
        import math
        from concurrent.futures import (
            ThreadPoolExecutor, wait, FIRST_COMPLETED,
        )

        top = self._resolve_page_size(config)
        timeout = config.get("timeout_seconds", self.DEFAULT_TIMEOUT_SECONDS)
        rate_limit_rps = config.get("rate_limit_rps", self.DEFAULT_RATE_LIMIT_RPS)
        n_pages = max(1, math.ceil(expected_count / top))

        # Memory estimate -- logged so the operator can see what they're
        # committing to before the run takes hold of the heap.
        est_mb_per_page = (top * 1900) / 1_000_000
        est_peak_per_group = (parallel + 1) * est_mb_per_page
        self.logger.info(
            "Parallel fetch: %d pages of $top=%d, parallel=%d "
            "(expected_count=%d).  Estimated peak memory per group: "
            "~%.0f MB (parallel+1 pages x ~%.0f MB/page).",
            n_pages, top, parallel, expected_count,
            est_peak_per_group, est_mb_per_page,
        )

        def fetch_one(page_idx: int) -> Tuple[int, List[Dict[str, Any]]]:
            skip = page_idx * top
            page_url = _merge_query_params(base_url, {
                **{k: str(v) for k, v in (params or {}).items()},
                "$top":   str(top),
                "$skip":  str(skip),
                "spnego": "disabled",
            })
            self._rate_limit(rate_limit_rps)
            resp = session.get(page_url, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
            if page_idx == 0:
                self._validate_d_envelope(data, base_url)
            d_env = (data.get("d") if isinstance(data, dict) else None) or {}
            return page_idx, d_env.get("results", []) or []

        cumulative = 0
        next_page = 0
        with ThreadPoolExecutor(
            max_workers=parallel, thread_name_prefix="sap-page-fetch",
        ) as ex:
            # Bootstrap: prime the pool with up to ``parallel`` futures.
            in_flight = set()
            while len(in_flight) < parallel and next_page < n_pages:
                in_flight.add(ex.submit(fetch_one, next_page))
                next_page += 1

            # Sliding window: as each completes, top up with the next
            # page.  Peak in-flight stays at ``parallel`` -- if a
            # completed future hasn't been ``yielded`` yet (slow main
            # thread), we DON'T submit more.  That's the bound.
            while in_flight:
                done, in_flight = wait(
                    in_flight, return_when=FIRST_COMPLETED,
                )
                for fut in done:
                    page_idx, results = fut.result()
                    cumulative += len(results)
                    pct = (
                        (cumulative / expected_count * 100.0)
                        if expected_count else 0
                    )
                    self.logger.info(
                        "Parallel page %d/%d: %d rows "
                        "(cumulative %d/%d, %.1f%%)",
                        page_idx + 1, n_pages, len(results),
                        cumulative, expected_count, pct,
                    )
                    yield page_idx, results
                    # Top up only AFTER yield returns -- this is what
                    # bounds memory.  Main thread back-pressure
                    # naturally throttles fetch throughput.
                    if next_page < n_pages:
                        in_flight.add(ex.submit(fetch_one, next_page))
                        next_page += 1

    def _validate_d_envelope(self, data: Any, url: str) -> None:
        """Raise ValueError if a SAP OData response lacks the ``d`` envelope.

        Some SAP services return HTTP 200 with an ``error`` envelope on
        auth failures or malformed requests -- without this guard the
        paginator silently yields zero rows and the step is marked
        COMPLETED.  Centralised so every code path (in-memory, CSV,
        streaming) shares the same loud-fail behaviour.
        """
        if not isinstance(data, dict):
            raise ValueError(
                f"SAP OData response is not a JSON object "
                f"(type={type(data).__name__}, body={str(data)[:200]!r})"
            )
        if "d" not in data:
            err = data.get("error") or data.get("Error") or {}
            err_msg = (
                (err.get("message") or {}).get("value")
                if isinstance(err, dict) else str(err)
            ) or str(data)[:300]
            raise ValueError(
                f"SAP OData response missing ``d`` envelope on first page "
                f"(URL: {url}).  Likely an auth failure or malformed "
                f"request.  Server said: {err_msg!r}"
            )

    def _paginated_odata_get(
        self, session: requests.Session, base_url: str,
        params: Dict[str, str], config: Dict,
    ) -> List[Dict]:
        """Paginate SAP OData using $top/$skip.  Returns all rows as a
        list of dicts.

        Audit SERIOUS #9 -- termination rule.  Pre-Phase-134-K code
        ended the loop on ``len(results) < top``, but the OData spec
        explicitly allows servers to return partial pages mid-stream
        (server load, paging hints, dynamic batch limits).  A short
        page mid-stream silently dropped the tail.

        New rule:
          * Empty page                  -> DONE (terminal)
          * ``__next`` link present     -> follow it (server is telling
                                           us there's more, regardless
                                           of the page-size we saw)
          * No ``__next`` AND a FULL
            page was returned           -> keep paging via $skip
          * No ``__next`` AND a SHORT
            page was returned           -> DONE (server signalled end
                                           by both lack of next-link
                                           AND under-fill)
        This is the same rule the public OData paging contract
        documents and matches what other clients (Microsoft.OData,
        olingo, SAP SDK) implement.
        """
        top = self._resolve_page_size(config)
        timeout = config.get('timeout_seconds', self.DEFAULT_TIMEOUT_SECONDS)
        rate_limit_rps = config.get('rate_limit_rps', self.DEFAULT_RATE_LIMIT_RPS)

        all_rows = []
        skip = 0
        page = 0

        while True:
            # Merge $top/$skip/spnego into the URL (overriding any value
            # the operator baked in) instead of passing a `params=` dict
            # -- `requests` MERGES the dict with existing URL params,
            # producing duplicates like ``?$top=100000&$top=100000`` that
            # some SAP services reject with 400/401.
            page_url = _merge_query_params(base_url, {
                **{k: str(v) for k, v in (params or {}).items()},
                '$top': str(top),
                '$skip': str(skip),
                'spnego': 'disabled',
            })

            self._rate_limit(rate_limit_rps)

            self.logger.info(f"Fetching page {page} ($skip={skip}, $top={top})")
            self.logger.info(f"  URL: {page_url}")
            resp = session.get(page_url, timeout=timeout)
            resp.raise_for_status()

            data = resp.json()

            # Detect HTTP-200 error responses.  SAP OData services
            # sometimes return a 200 with an ``error`` envelope (the
            # ``d`` envelope missing entirely) on auth failures or
            # malformed requests.  Without this check the paginator
            # silently returns [], the caller sees "0 rows", and the
            # step is marked COMPLETED.
            if page == 0 and not isinstance(data, dict):
                raise ValueError(
                    f"SAP OData response is not a JSON object "
                    f"(type={type(data).__name__}, body={str(data)[:200]!r})"
                )
            if page == 0 and 'd' not in data:
                err = data.get('error') or data.get('Error') or {}
                err_msg = (
                    (err.get('message') or {}).get('value')
                    if isinstance(err, dict) else str(err)
                ) or str(data)[:300]
                raise ValueError(
                    f"SAP OData response missing ``d`` envelope on first "
                    f"page (URL: {base_url}).  Likely an auth failure or "
                    f"malformed request.  Server said: {err_msg!r}"
                )

            d_envelope = data.get('d', {}) or {}
            results = d_envelope.get('results', []) or []

            if not results:
                self.logger.info(
                    f"No more results at page {page}, total: {len(all_rows)}"
                )
                break

            all_rows.extend(results)
            self.logger.info(
                f"Page {page}: {len(results)} rows (cumulative: {len(all_rows)})"
            )

            # OData ``__next`` link wins as a terminal signal -- present
            # ⇒ keep paging, absent + short page ⇒ done.  Some SAP
            # services emit __next as a sibling of results, others
            # inside __metadata; check both.
            next_link = d_envelope.get('__next')
            if next_link is None:
                meta = d_envelope.get('__metadata') or {}
                if isinstance(meta, dict):
                    next_link = meta.get('__next')

            if next_link is None and len(results) < top:
                # Server gave us no next-link AND a partial page --
                # standard end-of-stream signal.
                self.logger.info(
                    f"End of stream at page {page} (no __next, "
                    f"partial page {len(results)}/{top})"
                )
                break

            skip += top
            page += 1

            if page > 10000:
                # Audit NIT -- silently truncating data is dangerous;
                # log at ERROR so it shows up in the operator's review.
                self.logger.error(
                    "Hit pagination safety cap at page 10000 -- "
                    "possible data truncation.  Raise page_size or "
                    "set ``pagination_max_pages`` config explicitly."
                )
                break

        return all_rows

    def _paginated_odata_to_csv(
        self, session: requests.Session, base_url: str,
        params: Dict[str, str], config: Dict, output_path: str,
    ) -> int:
        """Stream OData pages directly to CSV.  Memory-efficient -- one
        page at a time, no full result-set materialisation.

        Generic schema handling (Phase 132.32 -- no SAP-specific column
        hardcoding):

        1. **Header = union of keys across the FIRST page** rather than
           the first row's keys, so sparse rows (some columns missing
           on row 1) don't truncate the header.

        2. **Empty-string keys dropped.**  Some SAP responses end with
           a trailing ``"": ""`` artefact; we don't want a blank-header
           column.

        3. **Nested complex types stringified** rather than silently
           dropped.  When a row has ``{"foo": {"nested": "value"}}`` we
           write the JSON repr instead of losing the column entirely.

        4. **Late-arriving fields**: when a subsequent page introduces
           a new key not in the existing header, we WARN + fall back
           to writing the row with ``extrasaction='ignore'`` (drop the
           unknown columns rather than crash mid-stream).  Header is
           NOT rewritten retroactively -- a stable schema across pages
           is the SAP contract; we just don't crash if it's violated.
        """
        top = self._resolve_page_size(config)
        timeout = config.get('timeout_seconds', self.DEFAULT_TIMEOUT_SECONDS)
        rate_limit_rps = config.get('rate_limit_rps', self.DEFAULT_RATE_LIMIT_RPS)
        exclude_fields = {'__metadata', '__deferred', '__count'}

        total_rows = 0
        skip = 0
        page = 0
        writer = None
        fieldnames: list = []
        fieldnames_set: set = set()

        def _clean_row(row: Dict[str, Any]) -> Dict[str, Any]:
            out: Dict[str, Any] = {}
            for k, v in row.items():
                # Drop OData metadata + empty-string keys
                if k in exclude_fields or k == "" or k is None:
                    continue
                if isinstance(v, dict):
                    # Nested complex types -- preserve as JSON string
                    # instead of silently dropping the column
                    import json as _json
                    try: v = _json.dumps(v, default=str)
                    except Exception: v = str(v)
                elif isinstance(v, list):
                    import json as _json
                    try: v = _json.dumps(v, default=str)
                    except Exception: v = str(v)
                out[k] = v
            return out

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            while True:
                page_url = _merge_query_params(base_url, {
                    **{k: str(v) for k, v in (params or {}).items()},
                    '$top': str(top),
                    '$skip': str(skip),
                    'spnego': 'disabled',
                })

                self._rate_limit(rate_limit_rps)

                self.logger.info(f"Streaming page {page} ($skip={skip})")
                self.logger.info(f"  URL: {page_url}")
                resp = session.get(page_url, timeout=timeout)
                resp.raise_for_status()

                data = resp.json()

                # Same HTTP-200 error-envelope guard as the in-memory
                # paginator above -- first-page response MUST carry a
                # ``d`` envelope; otherwise raise so the step fails
                # instead of writing an empty CSV and reporting success.
                if page == 0 and not isinstance(data, dict):
                    raise ValueError(
                        f"SAP OData response is not a JSON object "
                        f"(type={type(data).__name__}, body={str(data)[:200]!r})"
                    )
                if page == 0 and 'd' not in data:
                    err = data.get('error') or data.get('Error') or {}
                    err_msg = (
                        (err.get('message') or {}).get('value')
                        if isinstance(err, dict) else str(err)
                    ) or str(data)[:300]
                    raise ValueError(
                        f"SAP OData response missing ``d`` envelope on "
                        f"first page (URL: {base_url}).  Likely an auth "
                        f"failure or malformed request.  Server said: "
                        f"{err_msg!r}"
                    )

                results = data.get('d', {}).get('results', [])

                if not results:
                    break

                clean_rows = [_clean_row(r) for r in results]

                if writer is None:
                    # Build header as UNION of keys across the first page
                    # (not just first row).  Preserves insertion order
                    # via dict (Python 3.7+).
                    union: Dict[str, None] = {}
                    for r in clean_rows:
                        for k in r.keys():
                            union.setdefault(k, None)
                    fieldnames = list(union.keys())
                    fieldnames_set = set(fieldnames)
                    # extrasaction='ignore' protects against late-arriving
                    # columns on later pages (rare but happens on some
                    # SAP services that lazy-expand analytics).
                    writer = csv.DictWriter(
                        f, fieldnames=fieldnames, extrasaction='ignore',
                    )
                    writer.writeheader()
                    self.logger.info(
                        "Schema: %d columns from first page (union over %d rows)",
                        len(fieldnames), len(clean_rows),
                    )
                else:
                    # Late-arriving columns?  Warn once per page; row will
                    # be written with extra columns dropped (extrasaction).
                    for r in clean_rows:
                        new_keys = [k for k in r.keys() if k not in fieldnames_set]
                        if new_keys:
                            self.logger.warning(
                                "Page %d introduces unknown columns %s -- "
                                "dropped (header is fixed from page 0).  "
                                "Increase $top or check the SAP service "
                                "for sparse-schema rows.",
                                page, new_keys,
                            )
                            break

                writer.writerows(clean_rows)
                total_rows += len(clean_rows)
                self.logger.info(f"Page {page}: {len(clean_rows)} rows (cumulative: {total_rows})")

                # Audit SERIOUS #9 -- same termination rule as the
                # in-memory paginator: empty page OR (no __next AND
                # partial page).
                d_env = data.get('d', {}) or {}
                next_link = d_env.get('__next')
                if next_link is None:
                    meta = d_env.get('__metadata') or {}
                    if isinstance(meta, dict):
                        next_link = meta.get('__next')
                if next_link is None and len(results) < top:
                    break

                skip += top
                page += 1

                if page > 10000:
                    self.logger.error(
                        "Streaming pagination cap (10000 pages) hit -- "
                        "possible data truncation"
                    )
                    break

        return total_rows

    def _derive_fiscal_period(self, mode: str) -> tuple:
        """Derive fiscal year and period from current date.
        Returns (p_gjahr, p_poper) as strings.

        Modes:
        * ``current``                 -- current_year + current_month
                                          (rare; usually p_poper is closed-period)
        * ``prev_eom``                -- previous-month's year + previous-month
                                          (handles Jan->Dec year rollback)
        * ``current_year_prev_poper`` -- current calendar year + previous month
                                          (Jan returns p_poper='012', no year rollback).
                                          Matches the SAP MEBAL pattern where
                                          p_gjahr is always the current calendar
                                          year and p_poper is the most recently
                                          closed period.
        """
        now = datetime.now()
        if mode == 'current':
            return str(now.year), f"{now.month:03d}"
        if mode == 'current_year_prev_poper':
            poper = now.month - 1
            if poper < 1:
                poper = 12   # Jan -> Dec, no year rollback
            return str(now.year), f"{poper:03d}"
        # default + 'prev_eom' + 'previous' (legacy alias) -- full prev-month
        # with its calendar year (rolls back across year boundary)
        prev = now.replace(day=1) - timedelta(days=1)
        return str(prev.year), f"{prev.month:03d}"

    def _rate_limit(self, rps: float):
        """Thread-safe token-bucket rate limiter.

        Audit SERIOUS #12 -- replaces the pre-Phase-134-K single-mutex
        min-interval limiter which serialised parallel-group requests.
        Now true token-bucket semantics:

        * Bucket capacity = ``rps`` (allows a 1-second burst).
        * Refill rate = ``rps`` tokens per second.
        * Each request takes 1 token; thread sleeps for the minimum
          time needed for 1 token to refill when empty.

        Concurrent threads share the same bucket via the lock so the
        AGGREGATE request rate stays at ``rps`` -- but multiple threads
        can each consume a token within the same window instead of
        serialising on a strict min-interval.

        Re-configuring rps mid-run (e.g. ops bumping it via SystemSetting)
        is honoured on the next call: the refill rate updates, the
        bucket is resized if needed.
        """
        if rps is None or rps <= 0:
            return
        with self._rate_limit_lock:
            now = time.time()
            # Re-init if rps changed since last call OR cold start.
            if rps != self._rate_rps_observed:
                self._rate_rps_observed = float(rps)
                self._rate_capacity = float(rps)
                # Re-seed tokens at the smaller of (existing, new
                # capacity) so a downward rps change reduces burst
                # immediately, an upward one doesn't artificially
                # bonus the next call.
                self._rate_tokens = min(self._rate_tokens, self._rate_capacity)
                if self._rate_tokens <= 0:
                    self._rate_tokens = self._rate_capacity
                self._rate_last_refill = now

            # Refill the bucket based on elapsed time.
            elapsed = now - self._rate_last_refill
            if elapsed > 0:
                self._rate_tokens = min(
                    self._rate_capacity,
                    self._rate_tokens + elapsed * self._rate_rps_observed,
                )
                self._rate_last_refill = now

            # Consume -- sleep for the time needed to accumulate 1
            # token when the bucket is empty.
            if self._rate_tokens < 1.0:
                deficit = 1.0 - self._rate_tokens
                wait = deficit / self._rate_rps_observed
                # Release the lock while sleeping so concurrent callers
                # can refill + consume in parallel for a true
                # max-of-rps aggregate throughput.  Re-acquire after.
                self._rate_limit_lock.release()
                try:
                    time.sleep(wait)
                finally:
                    self._rate_limit_lock.acquire()
                # After sleep, the bucket has accumulated tokens; refill
                # again and consume.
                now2 = time.time()
                elapsed2 = now2 - self._rate_last_refill
                self._rate_tokens = min(
                    self._rate_capacity,
                    self._rate_tokens + elapsed2 * self._rate_rps_observed,
                )
                self._rate_last_refill = now2
            self._rate_tokens -= 1.0
