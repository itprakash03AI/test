"""SAP OData page sinks -- write a stream of OData page rows to disk.

Strategy pattern: each sink implements ``write_page(rows) -> int`` and
``close()``.  No row materialisation between pages -- the caller pulls
one page from SAP, hands it to the sink, the sink flushes to disk and
the page is released for GC.

Two sinks ship:

  * ``CsvPageSink``      -- one CSV file, schema = union of keys from the
                            first page, later pages drop unknown columns.
  * ``ParquetPageSink``  -- one Parquet file, one row-group per page via
                            ``pyarrow.parquet.ParquetWriter`` (truly
                            constant memory regardless of total rows).

Strategy selector ``make_sink(path, output_format)`` picks the right
implementation by name.
"""
from __future__ import annotations

import csv
import json
import os
from typing import Any, Dict, List, Optional, Set


# OData V2 envelope keys we never want in the output file.
_ODATA_META_KEYS = {"__metadata", "__deferred", "__count"}


def _clean_row(row: Dict[str, Any]) -> Dict[str, Any]:
    """Strip OData envelope keys, drop empty headers, JSON-stringify
    nested complex types so they survive a flat-file write instead of
    being silently dropped."""
    out: Dict[str, Any] = {}
    for k, v in row.items():
        if k in _ODATA_META_KEYS or k == "" or k is None:
            continue
        if isinstance(v, (dict, list)):
            try:
                v = json.dumps(v, default=str)
            except Exception:
                v = str(v)
        out[k] = v
    return out


# -- CSV sink ------------------------------------------------------------


class CsvPageSink:
    """Stream OData pages to a CSV file.

    Schema is locked to the **union of keys across the first page**.
    Later pages drop unknown columns via ``extrasaction='ignore'`` and a
    one-shot WARN.  This matches SAP's contract that the schema is
    stable across pages -- we just don't crash if a service violates it.
    """

    def __init__(self, path: str, logger=None, delimiter: str = ","):
        self.path = path
        self.logger = logger
        self.delimiter = delimiter
        self._fh = None
        self._writer: Optional[csv.DictWriter] = None
        self._fieldnames: List[str] = []
        self._fieldnames_set: Set[str] = set()
        self._total_rows = 0
        self._warned_unknown = False

    @property
    def total_rows(self) -> int:
        return self._total_rows

    @property
    def fieldnames(self) -> List[str]:
        return list(self._fieldnames)

    def write_page(self, rows: List[Dict[str, Any]]) -> int:
        clean = [_clean_row(r) for r in rows]
        if not clean:
            return 0

        if self._writer is None:
            self._fh = open(self.path, "w", newline="", encoding="utf-8")
            union: Dict[str, None] = {}
            for r in clean:
                for k in r.keys():
                    union.setdefault(k, None)
            # Preserve insertion order (SAP returns same column order
            # across groups since they hit the same API endpoint).
            self._fieldnames = list(union.keys())
            self._fieldnames_set = set(self._fieldnames)
            self._writer = csv.DictWriter(
                self._fh,
                fieldnames=self._fieldnames,
                extrasaction="ignore",
                delimiter=self.delimiter,
            )
            self._writer.writeheader()
            if self.logger:
                self.logger.info(
                    "CSV sink %s: header locked to %d columns",
                    os.path.basename(self.path), len(self._fieldnames),
                )
        elif not self._warned_unknown:
            for r in clean:
                new_keys = [k for k in r.keys() if k not in self._fieldnames_set]
                if new_keys:
                    if self.logger:
                        self.logger.warning(
                            "CSV sink %s: page introduces unknown columns %s -- "
                            "dropped (header fixed from first page)",
                            os.path.basename(self.path), new_keys,
                        )
                    self._warned_unknown = True
                    break

        self._writer.writerows(clean)
        self._total_rows += len(clean)
        return len(clean)

    def close(self) -> None:
        if self._fh:
            try:
                self._fh.flush()
                os.fsync(self._fh.fileno())
            except (AttributeError, OSError):
                pass
            self._fh.close()
            self._fh = None


# -- Parquet sink --------------------------------------------------------


class ParquetPageSink:
    """Stream OData pages to a Parquet file.

    One row-group per page via ``pyarrow.parquet.ParquetWriter`` --
    memory stays constant regardless of total row count.

    Schema is inferred from the first page (all columns kept as their
    inferred Arrow types).  Later pages are coerced to the fixed schema:
    missing keys fill with NULL, extras dropped with a one-shot WARN.
    """

    def __init__(self, path: str, logger=None, compression: str = "snappy"):
        self.path = path
        self.logger = logger
        self.compression = compression
        self._writer = None
        self._schema = None
        self._fieldnames: List[str] = []
        self._fieldnames_set: Set[str] = set()
        self._total_rows = 0
        self._warned_unknown = False

    @property
    def total_rows(self) -> int:
        return self._total_rows

    @property
    def fieldnames(self) -> List[str]:
        return list(self._fieldnames)

    def write_page(self, rows: List[Dict[str, Any]]) -> int:
        import pyarrow as pa
        import pyarrow.parquet as pq

        clean = [_clean_row(r) for r in rows]
        if not clean:
            return 0

        if self._writer is None:
            union: Dict[str, None] = {}
            for r in clean:
                for k in r.keys():
                    union.setdefault(k, None)
            self._fieldnames = list(union.keys())
            self._fieldnames_set = set(self._fieldnames)
            normalized = [
                {k: r.get(k) for k in self._fieldnames}
                for r in clean
            ]
            table = pa.Table.from_pylist(normalized)
            self._schema = table.schema
            self._writer = pq.ParquetWriter(
                self.path, self._schema, compression=self.compression,
            )
            self._writer.write_table(table)
            if self.logger:
                self.logger.info(
                    "Parquet sink %s: schema locked to %d columns (%s)",
                    os.path.basename(self.path),
                    len(self._fieldnames),
                    self.compression,
                )
        else:
            if not self._warned_unknown:
                for r in clean:
                    new_keys = [k for k in r.keys() if k not in self._fieldnames_set]
                    if new_keys:
                        if self.logger:
                            self.logger.warning(
                                "Parquet sink %s: page introduces unknown columns "
                                "%s -- dropped (schema fixed from first page)",
                                os.path.basename(self.path), new_keys,
                            )
                        self._warned_unknown = True
                        break
            normalized = [
                {k: r.get(k) for k in self._fieldnames}
                for r in clean
            ]
            table = pa.Table.from_pylist(normalized, schema=self._schema)
            self._writer.write_table(table)

        self._total_rows += len(clean)
        return len(clean)

    def close(self) -> None:
        if self._writer:
            self._writer.close()
            self._writer = None


# -- Strategy selector ---------------------------------------------------


def make_sink(path: str, output_format: str, logger=None, **kwargs):
    """Return the right sink for ``output_format`` ('csv' | 'parquet').

    Extra kwargs are forwarded to the sink constructor (so callers can
    override CSV delimiter or Parquet compression without growing this
    factory's signature).
    """
    fmt = (output_format or "csv").strip().lower()
    if fmt == "csv":
        return CsvPageSink(path, logger=logger, **kwargs)
    if fmt in ("parquet", "pq"):
        return ParquetPageSink(path, logger=logger, **kwargs)
    raise ValueError(
        f"Unsupported output_format {output_format!r} -- expected "
        f"'csv' or 'parquet'."
    )


def file_extension_for(output_format: str) -> str:
    fmt = (output_format or "csv").strip().lower()
    if fmt == "csv":
        return "csv"
    if fmt in ("parquet", "pq"):
        return "parquet"
    raise ValueError(
        f"Unsupported output_format {output_format!r} -- expected "
        f"'csv' or 'parquet'."
    )
