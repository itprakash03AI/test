"""SAP-flow analytics Parquet emit step.

Runs AFTER ``SapCheckCompleteness`` has certified the data.  Produces
ONE Parquet file alongside the existing compressed CSV -- the CSV.gz
stays the delivery payload, the Parquet is for QueryStudio analytics.

Why a separate step (not OUTPUT_FORMAT='csv,parquet' in Consolidate):

  * Parquet only emitted for DATA THAT PASSED THE FULL COMPLETENESS
    GATE.  If reconcile fails, no Parquet -- analytics never sees
    half-baked data.
  * Doesn't slow the delivery path (CTL + Deliver still on the
    existing chain; this step is between CheckCompleteness and CTL).
  * Source is the compressed CSV (.csv.gz) -- no need to keep the
    uncompressed file around or re-consolidate.

Memory-bounded streaming via ``pyarrow.csv.open_csv`` reading the gz
in 16 MB blocks; each block becomes one Parquet row group.  9 M-row
CSV converts in ~2-3 minutes with peak memory ~50 MB regardless of
total size.

Tuning knobs (polling-row or JSON config):

  * ``analytics_dir``        -- target dir; default ``<run_subdir>/analytics``
  * ``analytics_filename``   -- target name (no ext); supports
                                 ``{GJAHR}`` / ``{POPER}`` placeholders.
                                 Default ``MEBAL_{GJAHR}_{POPER}``.
  * ``analytics_compression`` -- ``snappy`` (default) | ``zstd`` | ``gzip``
                                 | ``brotli`` | ``none``.  ``zstd`` gives
                                 the smallest file but pyarrow may need
                                 a recent build.
  * ``analytics_block_size`` -- bytes per read block.  Default 16 MB;
                                 lower for memory-tight pods.
  * ``analytics_row_group_size`` -- rows per Parquet row group hint.
                                     PyArrow defaults are fine; override
                                     only for special QueryStudio needs.
  * ``analytics_enabled``    -- set False to skip this step entirely
                                 (the CSV.gz delivery still completes).
"""
from __future__ import annotations

import gzip
import os
from typing import Any, Dict, List, Optional

from steps.sap_odata_base import SapOdataBase


class SapEmitAnalyticsParquet(SapOdataBase):
    """Emit a single Parquet from the certified compressed CSV."""

    LOG_PREFIX = "sap_emit_analytics_parquet"
    REQUIRED_FIELDS: List[str] = []

    DEFAULT_BLOCK_SIZE = 16 * 1024 * 1024   # 16 MB
    DEFAULT_COMPRESSION = "snappy"

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)
        self._hydrate_from_sidecar(task, config)

        # DB is the workflow source of truth: if the polling row
        # exists for this step, the step MUST produce a Parquet.
        # No skip flag.  If you don't want analytics Parquet, remove
        # the SapEmitAnalyticsParquet polling row from the workflow.
        source = self._resolve_source(task)
        target = self._resolve_target(task, config)
        os.makedirs(os.path.dirname(target), exist_ok=True)

        delimiter = config.get("consolidated_csv_delimiter", "|")
        block_size = int(config.get("analytics_block_size", self.DEFAULT_BLOCK_SIZE))
        compression = (
            config.get("analytics_compression") or self.DEFAULT_COMPRESSION
        ).lower()
        if compression == "none":
            compression = None
        row_group_size = config.get("analytics_row_group_size")

        self.logger.info(
            "Analytics Parquet: source=%s -> target=%s "
            "(delimiter=%r, block_size=%d, compression=%s)",
            source, target, delimiter, block_size, compression,
        )

        rows_written = self._csv_to_parquet_stream(
            source=source,
            target=target,
            delimiter=delimiter,
            block_size=block_size,
            compression=compression,
            row_group_size=row_group_size,
        )

        # Validate against the certified totalcount.  Any mismatch is
        # a conversion bug (pyarrow chose wrong dialect, embedded
        # newlines in CSV cells, etc.) and must halt.
        expected = self._certified_total(task)
        if expected is not None and rows_written != expected:
            try:
                os.remove(target)  # don't ship a wrong-row-count Parquet
            except OSError:
                pass
            raise ValueError(
                f"SapEmitAnalyticsParquet: Parquet has {rows_written:,} "
                f"rows but completeness-checked totalcount is "
                f"{expected:,}.  Conversion is dropping or duplicating "
                f"rows -- investigate consolidated_csv_delimiter "
                f"({delimiter!r}) or embedded-newline cells in the CSV."
            )

        size = os.path.getsize(target)
        self.logger.info(
            "Analytics Parquet OK: %s (%d rows, %d bytes, "
            "%.1fx smaller than source CSV.gz)",
            target, rows_written, size,
            os.path.getsize(source) / max(size, 1),
        )

        task["analytics_parquet"] = target
        self._save_sidecar(task, config)
        return rows_written

    # -- Helpers --------------------------------------------------------

    def _resolve_source(self, task: Dict) -> str:
        """Prefer compressed (.csv.gz) -- it's the certified payload.
        Fall back to uncompressed consolidated CSV if Compress was
        skipped or delete_uncompressed=False kept both."""
        compressed = task.get("compressed_file") or ""
        if compressed and os.path.exists(compressed):
            return compressed
        consolidated = task.get("consolidated_file") or ""
        if consolidated and os.path.exists(consolidated):
            return consolidated
        raise ValueError(
            "SapEmitAnalyticsParquet: neither compressed_file nor "
            "consolidated_file exists on disk.  This step must run "
            "AFTER SapCheckCompleteness has certified the data.  "
            f"Sidecar: compressed_file={compressed!r}, "
            f"consolidated_file={consolidated!r}"
        )

    def _resolve_target(self, task: Dict, config: Dict) -> str:
        """Build ``<analytics_dir>/<filename>.parquet``."""
        run_subdir = task.get("output_dir") or "."
        analytics_dir = (
            config.get("analytics_dir")
            or os.path.join(run_subdir, "analytics")
        )
        filename_template = (
            config.get("analytics_filename")
            or "MEBAL_{GJAHR}_{POPER}"
        )
        p_gjahr = str(task.get("p_gjahr") or "")
        p_poper = str(task.get("p_poper") or "")
        filename = (
            filename_template
            .replace("{GJAHR}", p_gjahr)
            .replace("{POPER}", p_poper)
        )
        return os.path.join(analytics_dir, f"{filename}.parquet")

    def _certified_total(self, task: Dict) -> Optional[int]:
        """The total CheckCompleteness signed off on."""
        for key in ("totalcount", "full_count"):
            v = task.get(key)
            if v is None:
                continue
            try:
                return int(v)
            except (TypeError, ValueError):
                continue
        return None

    def _csv_to_parquet_stream(
        self, *, source: str, target: str, delimiter: str,
        block_size: int, compression: Optional[str],
        row_group_size: Optional[Any],
    ) -> int:
        """Read CSV (or CSV.gz) in blocks, write each as a Parquet
        row group via ``pyarrow.csv.open_csv`` + ``ParquetWriter``.

        Peak memory ~= block_size + one Parquet row-group buffer.
        Default ~50 MB for a 16 MB CSV block.
        """
        import pyarrow as pa
        import pyarrow.csv as pa_csv
        import pyarrow.parquet as pq

        is_gz = source.endswith(".gz")
        opener = gzip.open if is_gz else open

        read_opts = pa_csv.ReadOptions(
            block_size=block_size,
            use_threads=True,
        )
        parse_opts = pa_csv.ParseOptions(
            delimiter=delimiter,
            newlines_in_values=True,  # tolerate embedded \n in cells
        )
        # Let pyarrow infer types from the first block; analytics
        # use-cases prefer typed columns over all-string fallback.
        convert_opts = pa_csv.ConvertOptions(
            strings_can_be_null=True,
        )

        writer: Optional[pq.ParquetWriter] = None
        schema: Optional[pa.Schema] = None
        total_rows = 0

        write_kwargs: Dict[str, Any] = {}
        if row_group_size:
            try:
                write_kwargs["row_group_size"] = int(row_group_size)
            except (TypeError, ValueError):
                pass

        try:
            with opener(source, "rb") as f_in:
                reader = pa_csv.open_csv(
                    f_in,
                    read_options=read_opts,
                    parse_options=parse_opts,
                    convert_options=convert_opts,
                )
                for batch in reader:
                    if writer is None:
                        schema = batch.schema
                        writer = pq.ParquetWriter(
                            target, schema,
                            compression=compression or "none",
                        )
                    table = pa.Table.from_batches([batch], schema=schema)
                    writer.write_table(table, **write_kwargs)
                    total_rows += batch.num_rows
        finally:
            if writer is not None:
                writer.close()

        return total_rows
