"""
Smart company code grouping for SAP OData parallel downloads.
First run: even distribution across N groups.
Subsequent runs: greedy bin-packing based on historical per-code row counts.
History persisted to JSON on NFS.
"""
import json
import os
import logging
from typing import Dict, List, Optional
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class CompanyCodeGrouper:
    """Groups SAP company codes into download batches.

    Policy (post-2026-06-07): groups are sized by **codes per group**,
    not by a fixed bucket count.  Operator specifies how many codes
    fit comfortably in ONE OData ``$filter`` (default 100); we then
    compute ``ceil(total_codes / codes_per_group)`` buckets.

    Why: SAP services rate-limit on per-request payload + render time;
    a single group with 1000 codes in the ``$filter`` clause times out,
    a group with 100 codes responds reliably.  Fixing the codes-per-
    group ceiling gives predictable per-request latency regardless of
    how many codes the tenant has.

    Back-compat: ``num_groups`` is still accepted; ``codes_per_group``
    wins when both are set.  A request for ``codes_per_group=0`` falls
    back to ``num_groups`` (legacy bucket-count behaviour).
    """

    DEFAULT_CODES_PER_GROUP = 100

    def __init__(
        self, history_path: str,
        num_groups: Optional[int] = None,
        codes_per_group: Optional[int] = None,
        rows_per_group_target: Optional[int] = None,
        single_code_list: Optional[List[str]] = None,
    ):
        """
        ``rows_per_group_target`` (NEW, 2026-06-07): when set, the
        grouper walks sorted codes and starts a new group whenever the
        accumulated historical weight reaches this target.  Codes with
        weight ABOVE the target are isolated into single-code groups.
        Matches the C# pattern -- some C# tasks have a single code
        (e.g. ``GROUP21_C Eq: 8115`` with 974K rows) while others
        span a range.  Default ``None`` (use codes_per_group instead).

        ``single_code_list`` (NEW, 2026-06-07): explicit operator-
        supplied list of codes to FORCE into single-code groups,
        regardless of history.  Critical for first-run hot codes the
        operator already knows are heavy.  ZERO codes hardcoded in
        Python -- the list is purely operator config.
        Default ``None`` (no forcing).
        """
        self.history_path = history_path
        self.num_groups = num_groups
        self.codes_per_group = (
            codes_per_group
            if codes_per_group is not None
            else self.DEFAULT_CODES_PER_GROUP
        )
        self.rows_per_group_target = rows_per_group_target
        self.single_code_list = [
            str(c).strip() for c in (single_code_list or [])
            if str(c).strip()
        ]
        self.history = self._load_history()

    def _effective_num_groups(self, total_codes: int) -> int:
        """Resolve final bucket count from total + codes_per_group + num_groups.

        Precedence:
          1. ``codes_per_group > 0`` -> ceil(total / codes_per_group)
          2. ``num_groups``         -> that exact count (legacy)
          3. default                -> DEFAULT_CODES_PER_GROUP
        """
        if self.codes_per_group and self.codes_per_group > 0:
            import math
            n = max(1, math.ceil(total_codes / self.codes_per_group))
            logger.info(
                "Grouper: codes_per_group=%d, total_codes=%d -> %d groups",
                self.codes_per_group, total_codes, n,
            )
            return n
        if self.num_groups and self.num_groups > 0:
            logger.info(
                "Grouper: legacy num_groups=%d (codes_per_group not set)",
                self.num_groups,
            )
            return self.num_groups
        import math
        n = max(1, math.ceil(total_codes / self.DEFAULT_CODES_PER_GROUP))
        logger.info(
            "Grouper: defaulting to %d codes/group -> %d groups",
            self.DEFAULT_CODES_PER_GROUP, n,
        )
        return n

    def _load_history(self) -> Dict:
        """Load grouping history from NFS JSON file."""
        if os.path.exists(self.history_path):
            try:
                with open(self.history_path, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                logger.warning(f"Failed to load history from {self.history_path}: {e}")
        return {"runs": [], "code_weights": {}}

    def ingest_accurate_weights(self, per_code: Dict[str, int]) -> None:
        """Replace EMA-approximated weights with EXACT per-code counts.

        Called by SapOdataDownload after probing oversized groups.
        Unlike ``record_results`` (EMA-averaging across group members),
        these are TRUE per-code counts from /$count probes -- they
        OVERRIDE the EMA estimate completely so the next run's walk-
        pack sees accurate weights and can isolate heavies correctly.

        Also feeds auto-detection: any code whose accurate weight
        exceeds ``rows_per_group_target`` gets added to
        ``learned_heavies`` immediately, so the very NEXT call to
        ``group_codes`` isolates it.
        """
        if not per_code:
            return
        weights = self.history.setdefault("code_weights", {})
        learned = set(self.history.get("learned_heavies") or [])
        target = self.rows_per_group_target or 0
        n_new_heavies = 0
        for code, n in per_code.items():
            weights[str(code)] = float(n)
            if target > 0 and n > target:
                if code not in learned:
                    n_new_heavies += 1
                learned.add(str(code))
        self.history["learned_heavies"] = sorted(learned)
        self._save_history()
        logger.info(
            "ingest_accurate_weights: updated %d codes with EXACT "
            "per-code counts (replaces EMA estimates).  %d new "
            "heavies added to learned_heavies (target=%s).",
            len(per_code), n_new_heavies, target or '<none>',
        )

    def _save_history(self):
        """Persist history to NFS."""
        os.makedirs(os.path.dirname(self.history_path), exist_ok=True)
        with open(self.history_path, 'w') as f:
            json.dump(self.history, f, indent=2, default=str)

    def group_codes(self, company_codes: List[str]) -> List[List[str]]:
        """Group company codes into balanced groups.

        ``company_codes`` is the SOURCE OF TRUTH for which codes
        exist this run -- it comes from the live SAP_COMPANY_API call.
        History weights only ENRICH the grouping (decide which codes
        are heavy); they never add or remove codes from the roster.

        Precedence (highest to lowest):
          1. ``single_code_list`` -- force-isolated codes get their
              OWN single-code group regardless of weight.
          2. ``rows_per_group_target`` + SUFFICIENT history -- weight-
              aware contiguous walk that closes a group when
              accumulated weight reaches the target.  Heavy codes
              (weight > target) get isolated automatically.
              "Sufficient" = >= 50% of the API roster has a weight.
              Below that, falls through to path 4 (codes_per_group)
              because sparse weights can't drive accurate target packing.
          3. History bin-pack (legacy num_groups path)
          4. ``codes_per_group`` contiguous split (default,
              also the first-run path when no history exists)
        """
        if not company_codes:
            return []

        sorted_codes = sorted(company_codes)
        weights = self.history.get("code_weights", {}) or {}
        # forced-isolated set: operator-supplied + history-learned.
        # Operator's SINGLE_CODE_LIST is honoured immediately AND
        # persisted into ``learned_heavies`` in record_results so
        # SUBSEQUENT runs auto-isolate even without re-passing the
        # list.  Auto-detection (single-code group running > 1.5x
        # target) also adds to learned_heavies organically.
        forced = set(self.single_code_list or [])
        learned = set(self.history.get("learned_heavies") or [])
        forced.update(learned)
        # Restrict to codes ACTUALLY in this run's API roster -- a
        # code that was learned-heavy but no longer in SAP_COMPANY_API
        # shouldn't pull the grouper into an empty single-code group.
        forced = {c for c in forced if c in set(sorted_codes)}

        # Sparse-weights guard: weight-aware packing needs MOST codes
        # to have a weight, else the walker accumulates 0+0+0... never
        # hits target, and dumps all roster codes into one group.
        # Empirical threshold: 50% coverage.  Below that, fall back
        # to codes_per_group contiguous split -- safe predictable
        # outcome that builds history for the NEXT run.
        weight_coverage = (
            sum(1 for c in sorted_codes if weights.get(c, 0) > 0)
            / max(len(sorted_codes), 1)
        )

        # Path 1+2: weight-aware contiguous walk (covers force-isolated
        # AND target-driven cases in one algorithm).  Force-isolation
        # via single_code_list works regardless of weight coverage --
        # the explicit operator list is its own signal.
        target = self.rows_per_group_target or 0
        if forced or (target and weight_coverage >= 0.5):
            # For the weight-pack path, default unknown codes to the
            # MEAN of known weights so they pack into similar-sized
            # groups instead of treating them as zero.
            known_weights = [w for w in weights.values() if w > 0]
            default_w = (
                sum(known_weights) / len(known_weights)
                if known_weights else 0.0
            )
            enriched = {c: weights.get(c, default_w) for c in sorted_codes}
            groups = self._walk_pack_contiguous(
                sorted_codes, enriched, target, forced,
            )
            n_single = sum(1 for g in groups if len(g) == 1)
            logger.info(
                "Weight-aware grouping: %d codes -> %d groups "
                "(%d single-code isolated, target=%s rows/group, "
                "forced=%s, weight_coverage=%.0f%%, default=%s)",
                len(sorted_codes), len(groups), n_single,
                target or '<no target>',
                sorted(forced) if forced else [],
                weight_coverage * 100,
                int(default_w),
            )
            return groups

        # Sparse history -- log and fall through
        if target and weight_coverage < 0.5:
            logger.warning(
                "rows_per_group_target=%d set but history covers only "
                "%.0f%% of the %d API codes -- falling back to "
                "codes_per_group split (history builds on this run)",
                target, weight_coverage * 100, len(sorted_codes),
            )

        n = min(self._effective_num_groups(len(company_codes)), len(company_codes))

        if not weights:
            logger.info(
                f"First run: {len(company_codes)} codes -> "
                f"{n} groups (~{self.codes_per_group or '?'} codes/group)"
            )
            return self._contiguous_split(company_codes, n)

        weights = self.history["code_weights"]
        logger.info(
            f"Using historical weights for {len(weights)} codes, "
            f"bin-packing {len(company_codes)} codes into {n} groups"
        )
        return self._bin_pack(company_codes, weights, n)

    def record_results(self, group_results: List[Dict]):
        """Record per-group results after a download run.

        group_results: [{"codes": ["1001", "1002"], "row_count": N,
                          "expected_count": N, ...}, ...]

        Three things happen:

          1. ``code_weights`` updated via EMA (alpha=0.3).  Per-code
             weight = group_total / group_size -- approximation when
             a group has multiple codes (we can't know per-code
             distribution without per-code $count probe), but converges
             over time as the grouper splits oversized groups.

          2. ``learned_heavies`` set updated:
               - operator's ``single_code_list`` (the codes they
                 hand-fed this run) gets PERMANENTLY learned -- future
                 runs auto-isolate them even without the operator
                 re-setting the list
               - any SINGLE-CODE group whose actual row count exceeds
                 ``rows_per_group_target * 1.5`` is auto-learned --
                 it's clearly a heavy code that warrants its own group

          3. Top-10 weight ranking logged -- operator sees candidates
             they may want to add to ``SINGLE_CODE_LIST`` manually
             (especially if the auto-detect hasn't caught them yet
             because they're bundled with others).
        """
        alpha = 0.3
        target = self.rows_per_group_target or 0

        for result in group_results:
            codes = result["codes"]
            total_rows = result["row_count"]
            per_code = total_rows / max(len(codes), 1)

            for code in codes:
                old_weight = self.history["code_weights"].get(code, per_code)
                new_weight = alpha * per_code + (1 - alpha) * old_weight
                self.history["code_weights"][code] = round(new_weight, 1)

        # ── Learned heavies ───────────────────────────────────────
        learned = set(self.history.get("learned_heavies") or [])
        # (a) Operator-supplied list -- persist for future runs
        for code in (self.single_code_list or []):
            learned.add(str(code))
        # (b) Auto-detection -- single-code groups that ran heavy
        if target > 0:
            for result in group_results:
                if len(result["codes"]) == 1 and result["row_count"] > target * 1.5:
                    learned.add(str(result["codes"][0]))
        self.history["learned_heavies"] = sorted(learned)

        # ── Run log ────────────────────────────────────────────────
        self.history.setdefault("runs", []).append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "total_groups": len(group_results),
            "total_rows": sum(r["row_count"] for r in group_results),
            "learned_heavies_count": len(learned),
        })
        if len(self.history["runs"]) > 30:
            self.history["runs"] = self.history["runs"][-30:]

        self._save_history()
        logger.info(
            "Recorded results for %d groups (learned_heavies=%d total)",
            len(group_results), len(learned),
        )

        # ── Top-10 heaviest codes by weight (operator visibility) ──
        weights = self.history.get("code_weights", {}) or {}
        top = sorted(weights.items(), key=lambda kv: -kv[1])[:10]
        if top:
            logger.info("Top 10 codes by historical weight (per-code rows):")
            for code, w in top:
                is_isolated = code in learned
                tag = " [isolated]" if is_isolated else ""
                logger.info("  %s -> ~%d rows/run%s", code, int(w), tag)
            if target > 0:
                heavy_candidates = [
                    c for c, w in top
                    if w > target * 0.7 and c not in learned
                ]
                if heavy_candidates:
                    logger.info(
                        "Consider adding to SINGLE_CODE_LIST: %s "
                        "(close to or above %d rows/run target)",
                        ",".join(heavy_candidates), target,
                    )

    @staticmethod
    def _even_split(items: List[str], n: int) -> List[List[str]]:
        """Round-robin split (legacy).  Scatters codes across groups so
        each gets a similar count.  **Unsafe with range $filter** --
        produces overlapping ranges (group 0 = first+third,
        group 1 = second+fourth -> the implied ranges
        overlap).  Kept for back-compat with the old num_groups
        path.  New runs use ``_contiguous_split`` instead.
        """
        groups = [[] for _ in range(n)]
        for i, item in enumerate(items):
            groups[i % n].append(item)
        return [g for g in groups if g]

    @staticmethod
    def _walk_pack_contiguous(
        sorted_codes: List[str],
        weights: Dict[str, float],
        target: float,
        forced_single: set,
    ) -> List[List[str]]:
        """Weight-aware contiguous packing -- the C# pattern.

        Walks ``sorted_codes`` in order, accumulating into the current
        group until either:
          * Adding the next code would push total weight past ``target``
          * The next code is in ``forced_single`` (operator override)
          * The next code's individual weight exceeds ``target`` (heavy)

        At each break, the current group is flushed and (if the
        breaking code is heavy/forced) it becomes its OWN single-
        code group.

        Contiguity is preserved -- every group is a slice of the
        sorted code list, so range ``$filter`` (``ge X and le Y``)
        works without gaps or overlaps between groups.

        Args:
          sorted_codes:  pre-sorted list of company codes
          weights:       historical per-code row counts (may be empty;
                          missing codes default to 0)
          target:        target row count per group.  ``0`` disables
                          the target check (only forced_single drives
                          group breaks).
          forced_single: codes that MUST be isolated regardless of weight

        Returns: list of contiguous code lists.
        """
        groups: List[List[str]] = []
        current: List[str] = []
        current_w: float = 0.0
        # Default weight for codes never seen before -- treat them as
        # "light" (0) so a fresh code doesn't force a new group on
        # first run.  After 1-2 runs the history fills in real weights.
        for code in sorted_codes:
            w = float(weights.get(code, 0))
            is_heavy = (target > 0 and w > target) or (code in forced_single)

            if is_heavy:
                # Flush whatever's in current, then isolate this code
                if current:
                    groups.append(current)
                    current = []
                    current_w = 0.0
                groups.append([code])
                continue

            # Would adding this push past target?
            if target > 0 and current and (current_w + w) > target:
                groups.append(current)
                current = []
                current_w = 0.0

            current.append(code)
            current_w += w

        if current:
            groups.append(current)
        return groups

    @staticmethod
    def _contiguous_split(items: List[str], n: int) -> List[List[str]]:
        """Split items into n contiguous slices preserving sort order.

        With ``items = sorted(codes)`` and ``n = ceil(len/codes_per_group)``,
        adjacent groups never overlap in code space:

            items = [A, B, C, D, E]  (sorted by code)
            n = 3, codes_per_group = 2
            -> group 0: [A, B]    range A..B
              group 1: [C, D]    range C..D
              group 2: [E]       range E..E

        This is the safe partition for range-filter ``$filter=(
        Companycode ge '{min}' and Companycode le '{max}')`` because
        groups never reach into each other's space.  Per-group $count
        responses sum exactly to the full $count IF the
        SAP_COMPANY_API roster includes EVERY code that has MEBAL
        data -- see the gap warning in the class docstring.
        """
        if n <= 0 or not items:
            return []
        # Ceiling chunk size so the LAST group doesn't get
        # disproportionately fewer codes when len(items) % n != 0.
        import math
        chunk = max(1, math.ceil(len(items) / n))
        return [items[i:i + chunk] for i in range(0, len(items), chunk)]

    @staticmethod
    def _bin_pack(
        codes: List[str], weights: Dict[str, float], num_groups: int
    ) -> List[List[str]]:
        """Greedy bin-packing: largest-first-fit-decreasing.
        Assigns heaviest codes first to the lightest group.
        """
        default_weight = sum(weights.values()) / max(len(weights), 1) if weights else 1.0

        weighted_codes = [
            (code, weights.get(code, default_weight))
            for code in codes
        ]
        weighted_codes.sort(key=lambda x: x[1], reverse=True)

        groups = [[] for _ in range(num_groups)]
        group_weights = [0.0] * num_groups

        for code, weight in weighted_codes:
            min_idx = group_weights.index(min(group_weights))
            groups[min_idx].append(code)
            group_weights[min_idx] += weight

        # Log balance quality
        non_empty = [w for w in group_weights if w > 0]
        if non_empty:
            max_w = max(non_empty)
            min_w = min(non_empty)
            imbalance = (max_w - min_w) / max_w * 100 if max_w > 0 else 0
            logger.info(
                f"Bin-packed {len(codes)} codes into {num_groups} groups. "
                f"Weight range: {min_w:.0f} - {max_w:.0f} (imbalance: {imbalance:.1f}%)"
            )

        return [g for g in groups if g]
